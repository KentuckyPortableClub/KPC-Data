"""kpc_save_overwrite.sh on real (local) git repos: the save lands on top of a newer main, a hand edit is kept, and a save that
can never land goes red (exit 1 + ::error). No network: the 'remote' is a bare repo in tmp."""
import os, pathlib, subprocess


def sh(cmd, cwd, env=None, check=True):
    r = subprocess.run(cmd, cwd=cwd, shell=True, capture_output=True, text=True, env={**os.environ, **(env or {})})
    if check and r.returncode: raise AssertionError(f'{cmd}: {r.stdout} {r.stderr}')
    return r


def setup(tmp_path):
    sh('git init -q --bare remote.git && git -C remote.git symbolic-ref HEAD refs/heads/main', tmp_path)
    b = tmp_path / 'bot'; b.mkdir()
    sh('git init -q && git checkout -q -B main && git config user.email t@t && git config user.name t && git remote add origin ../remote.git', b)
    (b / 'data/us-key').mkdir(parents=True)
    (b / 'data/us-key/overrides.json').write_text('{"parks": {}}\n'); (b / 'data/us-key/US-KS.json').write_text('{"v": 1}\n')
    (b / 'data/us-key/answers-states.txt').write_text('KS KY\n')
    sh('git add -A && git commit -qm init && git push -q -u origin main', b)
    sh('git clone -q remote.git person', tmp_path)
    sh('git config user.email p@p && git config user.name p', tmp_path / 'person')
    return b, tmp_path / 'person'


def test_bot_a_save_redoes_the_writer_on_newest_main(tmp_path, links_scripts):
    bot, person = setup(tmp_path)
    # a person edits overrides.json and pushes while the bot runs (the Oct 30 failure: rebase on unstaged files)
    (person / 'data/us-key/overrides.json').write_text('{"parks": {"US-9": {"note": "hand"}}}\n')
    sh('git commit -qam hand; git push -q origin main', person)
    writer = tmp_path / 'writer.py'
    writer.write_text("import json;p='data/us-key/overrides.json';d=json.load(open(p));d['parks'].setdefault('US-1',{})['no']=['111'];json.dump(d,open(p,'w'))\n")
    sh(f'python3 {writer}', bot)
    (bot / 'stray.txt').write_text('unstaged junk')                     # an unstaged file no longer breaks the save
    r = sh(f"bash {links_scripts / 'kpc_save_overwrite.sh'} 'BOT A test' 'python3 {writer}' -- data/us-key/overrides.json", bot)
    assert 'saved (overwrite' in r.stdout
    sh('git pull -q origin main', person)
    import json
    d = json.loads((person / 'data/us-key/overrides.json').read_text())
    assert d['parks']['US-9'] == {'note': 'hand'} and d['parks']['US-1']['no'] == ['111']   # both kept


def test_copy_mode_skips_hand_files(tmp_path, links_scripts):
    bot, person = setup(tmp_path)
    (person / 'data/us-key/overrides.json').write_text('{"parks": {"US-9": 1}}\n'); sh('git commit -qam hand; git push -q origin main', person)
    (bot / 'data/us-key/US-KS.json').write_text('{"v": 2}\n'); (bot / 'data/us-key/overrides.json').write_text('{"parks": {}}\n')
    r = sh(f"bash {links_scripts / 'kpc_save_overwrite.sh'} --copy 'US answer key' - -- data/us-key", bot,
           env={'KPC_SAVE_SKIP': 'data/us-key/overrides.json'})
    assert 'saved' in r.stdout
    sh('git pull -q origin main', person)
    assert (person / 'data/us-key/US-KS.json').read_text() == '{"v": 2}\n'
    assert (person / 'data/us-key/overrides.json').read_text() == '{"parks": {"US-9": 1}}\n'


def test_a_save_that_never_lands_is_red(tmp_path, links_scripts):
    bot, _ = setup(tmp_path)
    (bot / 'data/us-key/US-KS.json').write_text('{"v": 3}\n')
    sh('git remote set-url origin /nonexistent/remote.git', bot)
    r = sh(f"bash {links_scripts / 'kpc_save_overwrite.sh'} --copy 'US answer key' - -- data/us-key", bot,
           env={'KPC_SAVE_TRIES': '1'}, check=False)
    assert r.returncode == 1 and '::error title=Save::US answer key was NOT saved' in r.stdout


def test_rebase_mode_still_works_and_is_loud(tmp_path, links_scripts):
    bot, _ = setup(tmp_path)
    (bot / 'data/us-key/US-KS.json').write_text('{"v": 4}\n')
    r = sh(f"bash {links_scripts / 'kpc_save_overwrite.sh'} 'old way' - -- data/us-key", bot, env={'KPC_SAVE_MODE': 'rebase'})
    assert 'saved (rebase' in r.stdout
