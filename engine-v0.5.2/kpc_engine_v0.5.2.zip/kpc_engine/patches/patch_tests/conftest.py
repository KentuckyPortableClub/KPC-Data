"""Patch tests (v0.5.0). The six patches are applied to the bundled originals (patches/orig) in a tmp folder; the tests run on
that copy. Nothing here touches a club checkout. Run:  python3 -m pytest -q patches/patch_tests   (the engine's own 'python3 -m pytest -q' runs them too)"""
import os, pathlib
import pytest
from .patch_helpers import apply_all


@pytest.fixture(scope='session')
def patched(tmp_path_factory):
    root = os.environ.get('KPC_PATCHED')
    return pathlib.Path(root) if root else apply_all(tmp_path_factory.mktemp('patched'))


@pytest.fixture(scope='session')
def links_scripts(patched):
    return patched / 'KPC-Links/.github/scripts'


@pytest.fixture(scope='session')
def data_scripts(patched):
    return patched / 'KPC-Data/.github/scripts'
