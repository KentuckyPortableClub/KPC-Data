"""BOT A (kpc_key_answers.py) after the patch: a YES clears a SOLE NO (line 129), a NO keeps its name + acres, a stop is loud."""
import json, os, pathlib, subprocess, sys


def run(tmp, scripts, rows, ovr, env=None):
    (tmp / 'data/us-key').mkdir(parents=True, exist_ok=True)
    (tmp / 'kpcdata/data/waiting/questions').mkdir(parents=True, exist_ok=True)
    (tmp / 'data/us-key/overrides.json').write_text(json.dumps(ovr))
    (tmp / 'kpcdata/data/waiting/questions/key-pieces.json').write_text(json.dumps({'questions': rows}))
    r = subprocess.run([sys.executable, str(scripts / 'kpc_key_answers.py')], cwd=tmp, capture_output=True, text=True,
                       env={**os.environ, 'DATA': 'kpcdata', **(env or {})})
    return r, json.loads((tmp / 'data/us-key/overrides.json').read_text())


def test_yes_clears_sole_no(tmp_path, links_scripts):
    r, o = run(tmp_path, links_scripts, [{'ref': 'US-1', 'record': '7', 'record_name': 'Good SP', 'answer': 'YES', 'acres': 10}],
               {'parks': {'US-1': {'no': ['7'], 'nofp': {'7': ['Good SP', 10]}}}})
    assert r.returncode == 0, r.stdout + r.stderr
    v = o['parks']['US-1']
    assert 'no' not in v and 'nofp' not in v and v['join'] == ['7'] and v['fp']['7'] == ['Good SP', 10]


def test_no_is_stored_with_its_name(tmp_path, links_scripts):
    r, o = run(tmp_path, links_scripts, [{'ref': 'US-2', 'record': '222', 'record_name': 'Capital Park', 'answer': 'NO', 'acres': 12}],
               {'parks': {'US-2': {'join': ['222'], 'fp': {'222': ['Capital Park', 12]}}}})
    v = o['parks']['US-2']
    assert v['no'] == ['222'] and v['nofp'] == {'222': ['Capital Park', 12]} and 'join' not in v and 'fp' not in v


def test_stop_is_loud(tmp_path, links_scripts):
    (tmp_path / 'data/us-key').mkdir(parents=True); (tmp_path / 'kpcdata/data/waiting/questions').mkdir(parents=True)
    (tmp_path / 'data/us-key/overrides.json').write_text('{"parks": []}')          # wrong shape -> the script stops
    (tmp_path / 'kpcdata/data/waiting/questions/q.json').write_text(json.dumps({'questions': [{'ref': 'US-1', 'record': '1', 'answer': 'NO'}]}))
    base = dict(cwd=tmp_path, capture_output=True, text=True)
    r = subprocess.run([sys.executable, str(links_scripts / 'kpc_key_answers.py')], env={**os.environ, 'DATA': 'kpcdata'}, **base)
    assert r.returncode == 0 and '::error title=Key answers::stopped' in r.stdout   # default: today's exit code, but red text
    r = subprocess.run([sys.executable, str(links_scripts / 'kpc_key_answers.py')], env={**os.environ, 'DATA': 'kpcdata', 'KPC_LOUD_FAIL': '1'}, **base)
    assert r.returncode == 1
