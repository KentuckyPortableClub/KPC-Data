"""kpc_waiting_room.py: wrong-shape parts HOLD in plain words (never a crash) and the tidy switch (default off)."""
import json, os, pathlib
import pytest
from .patch_helpers import import_from


@pytest.fixture
def WR(data_scripts, tmp_path, monkeypatch):
    monkeypatch.setenv('DATA', str(tmp_path)); monkeypatch.setenv('LINKS', str(tmp_path / 'links'))
    m = import_from(data_scripts / 'kpc_waiting_room.py', 'kpc_waiting_room_t')
    monkeypatch.setattr(m, 'DATA', tmp_path); monkeypatch.setattr(m, 'W', tmp_path / 'data/waiting')
    return m


@pytest.mark.parametrize('path,new', [
    ('data/us-key/US-KY.json', {'parks': [1, 2]}),
    ('data/fers/US-KY.json', {'spots': {'a': 1}}),
    ('data/fers/US-KY.json', {'spots': [{'refs': ['US-1', 'US-2']}], 'pass1': '2026-11-01', 'pass2': '2026-11-01', 'pass3': '2026-11-01'}),
])
def test_wrong_shapes_hold_in_plain_words(WR, path, new):
    r = WR.judge(path, new, None)
    assert r['verdict'] == 'HOLD' and r['why'][0].startswith('F-4 unsure'), r
    assert 'checker error' not in ' '.join(r['why'])


def test_intake_and_pota_guards(WR):
    with pytest.raises(WR.Unsure): WR.c_intake('x', {'rows': ['a']}, None, {})
    with pytest.raises(WR.Unsure): WR.c_pota('x', {'parks': True}, None, {})
    assert WR.c_pota('x', {'parks': {'a': 1}}, {'parks': 1}, {}) == ([], [])


def test_closures_drop_non_rows(WR):
    out, gone = WR.closures_filter('data/closures/US-KY.json', {'items': ['junk', 7]}, None)
    assert out is None and 'none an object' in gone[0]


def test_tidy_is_off_by_default_and_removes_only_copies_same_as_live(WR, tmp_path, monkeypatch):
    held = tmp_path / 'data/waiting/in/data/docs'; held.mkdir(parents=True); (tmp_path / 'data/docs').mkdir(parents=True)
    (held / 'same.json').write_text('{"a": 1}'); (tmp_path / 'data/docs/same.json').write_text('{ "a" : 1 }')   # same data, other spacing
    (held / 'new.json').write_text('{"a": 2}'); (tmp_path / 'data/docs/new.json').write_text('{"a": 1}')
    monkeypatch.delenv('WAITING_TIDY', raising=False)
    assert WR.mode_tidy() == [] and (held / 'same.json').exists()
    monkeypatch.setenv('WAITING_TIDY', '1')
    monkeypatch.setattr(WR, 'log_action', lambda *a, **k: None)
    assert WR.mode_tidy() == ['data/docs/same.json']
    assert not (held / 'same.json').exists() and (held / 'new.json').exists()


def test_tidy_keep_generations(WR, tmp_path, monkeypatch):
    for g in (1, 2, 3, 4): (tmp_path / f'data/waiting/previous-{g}').mkdir(parents=True)
    monkeypatch.setenv('WAITING_TIDY', '1'); monkeypatch.setenv('WAITING_KEEP_GENS', '2')
    monkeypatch.setattr(WR, 'log_action', lambda *a, **k: None)
    assert sorted(WR.mode_tidy()) == ['previous-3/', 'previous-4/']


def test_key_names_only_switch(data_scripts):
    t = (data_scripts / 'kpc_waiting_room.py').read_text()
    assert "os.environ.get('WAITING_KEY_NAMES_ONLY') == '1'" in t
