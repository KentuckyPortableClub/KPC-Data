"""kpc_key_rules.py (new) + the call sites in kpc_us_key.py: a person's NO is honoured on every join path."""
import ast, re
import pytest
from .patch_helpers import import_from


@pytest.fixture(scope='module')
def KR(links_scripts):
    return import_from(links_scripts / 'kpc_key_rules.py', 'kpc_key_rules')


def test_defaults_match_today(KR):
    env = {}
    assert KR.on('KPC_NO_ALL_PATHS', env)                      # bug fix: on
    for k in ('KPC_NO_BY_NAME', 'KPC_ID_JOIN_NAME', 'KPC_REFOUND_NEAR', 'KPC_SELF_CHECKS', 'KPC_CONF_SORT'):
        assert not KR.on(k, env), k                            # new behaviour: off until Brandon says
    assert KR.on('KPC_NO_BY_NAME', {'KPC_NO_BY_NAME': '1'})


def test_no_by_id_and_by_saved_name(KR):
    ov = {'no': ['111', 'Old Mill Pond'], 'nofp': {'222': ['Capital Park', 12]}}
    assert KR.is_no(ov, 111) and KR.is_no(ov, 'x', 'old mill pond')            # today: id or a typed name
    assert not KR.is_no(ov, 999, 'Capital Park', 12, by_name=False)             # renumbered record: today it comes back
    assert KR.is_no(ov, 999, 'Capital Park', 14, by_name=True)                  # with the switch: same name + acres = still NO
    assert not KR.is_no(ov, 999, 'Capital Park', 900, by_name=True)             # same name, very different size: not the same piece
    rows = [[111, 'A', 1, 'name'], [999, 'Capital Park', 12, 'name'], [5, 'Good SP', 40, 'name']]
    assert [r[0] for r in KR.drop_no(rows, ov, by_name=True)] == [5]


def test_id_join_name_check(KR):
    assert KR.id_join_name_ok('Elk Creek State Park', 'Elk Creek SP')[0]
    assert KR.id_join_name_ok('Elk Creek State Park', 'Unit 4', fp_name='Unit 4')[0]
    ok, why = KR.id_join_name_ok('Elk Creek State Park', 'Bluegrass Army Depot')
    assert not ok and 'Bluegrass Army Depot' in why


def test_self_checks_and_confidence(KR):
    good = {'n': 'Fine SP', 't': 'State Park', 'm': [[5, 'Fine State Park', 300, 'reviewed']], 'c': [], 'la': 37.5, 'lo': -85.0}
    assert KR.self_checks('US-1', good, (36.5, -89.6, 39.2, -81.9), 310) == []
    assert KR.confidence(good) == ('sure', 'a person approved this land')
    bad = {'n': 'Tiny SP', 't': 'State Park', 'm': [[5, 'Huge WMA', 90000, 'words']], 'c': [], 'la': 45.0, 'lo': -85.0}
    p = KR.self_checks('US-2', bad, (36.5, -89.6, 39.2, -81.9), 50, kind_ok=lambda t, n: 'WMA' not in n)
    assert any(x.startswith('acres:') for x in p) and any(x.startswith('layer kind') for x in p) and any('outside the state' in x for x in p)
    lvl, why = KR.confidence(bad, p)
    assert lvl == 'unsure' and why.startswith('self-check: ') and '\n' not in why
    cand = {'n': 'X', 'm': [], 'c': [[7, 'X Area', 10, 'pin inside']]}
    assert KR.unsure_list({'US-3': cand, 'US-1': good})[0]['ref'] == 'US-3'


def test_us_key_checks_no_on_every_join_path(links_scripts):
    t = (links_scripts / 'kpc_us_key.py').read_text()
    ast.parse(t)
    assert 'import kpc_key_rules as KR' in t
    n = len(re.findall(r'_no_all\(|KR\.is_no\(|KR\.drop_no\(', t))
    assert n >= 9, n      # def, main join, id loop, alias_all, RIDB, alias, name join, keep-last-good (kept + found again)
    keep = t[t.index('KR.drop_no(om'):][:2000]
    assert '_no_all(OVR.get(ref)' in keep
    for flag in ('KPC_ID_JOIN_NAME', 'KPC_SELF_CHECKS', 'KPC_CONF_SORT', 'KPC_REFOUND_NEAR'):
        assert flag in t or flag in (links_scripts / 'kpc_key_rules.py').read_text(), flag


def test_fers_algo_is_the_reuse_key_option(links_scripts):
    t = (links_scripts / 'kpc_fers.py').read_text()
    assert re.search(r"^FERS_ALGO = 'fers-\d{4}-\d\d-\d\d\.\d+'", t, re.M)
    assert "REUSE_KEY = FERS_ALGO if" in t and "'algo'" in t
    assert 'CODE_HASH' in t                                        # today's key stays the default
    body = t[t.index('def pair_fp'):][:1500]
    assert 'REUSE_KEY' in body
