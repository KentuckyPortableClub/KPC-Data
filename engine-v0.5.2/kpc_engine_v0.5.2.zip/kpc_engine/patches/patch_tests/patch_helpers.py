"""Helpers for the patch tests (apply the six patches to the bundled originals; import a script by path)."""
import os, pathlib, shutil, subprocess, sys

HERE = pathlib.Path(__file__).resolve().parent
PATCHES = HERE.parent
REPOS = {'KPC-Links': sorted(PATCHES.glob('KPC-Links-*.patch')), 'KPC-Data': sorted(PATCHES.glob('KPC-Data-*.patch'))}


def apply_all(dst):
    dst = pathlib.Path(dst)
    for repo, pats in REPOS.items():
        shutil.copytree(PATCHES / 'orig' / repo, dst / repo, dirs_exist_ok=True)
        for p in pats:
            r = subprocess.run(['patch', '-p1', '-s', '--no-backup-if-mismatch', '-i', str(p)], cwd=dst / repo, capture_output=True, text=True)
            if r.returncode: raise RuntimeError(f'{p.name} did not apply: {r.stdout} {r.stderr}')
    return dst


def import_from(path, name):
    import importlib.util
    spec = importlib.util.spec_from_file_location(name, path); mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod; spec.loader.exec_module(mod); return mod
