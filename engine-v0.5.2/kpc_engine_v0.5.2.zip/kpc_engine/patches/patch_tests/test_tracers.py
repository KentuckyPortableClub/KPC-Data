"""Tracer limits (kpc_trace_limits.py, new) and their use in the picture + parcel tracers."""
import ast, pathlib, re, types
import pytest
from .patch_helpers import import_from


@pytest.fixture(scope='module')
def TL(data_scripts):
    return import_from(data_scripts / 'draft/kpc_trace_limits.py', 'kpc_trace_limits')


def test_defaults_are_todays_values(TL):
    assert TL.num('KPC_PARCEL_ADJ_M', {}) == 200 and TL.num('KPC_PARCEL_GROW_CAP', {}) == 0 and not TL.on('KPC_PARCEL_SUBTRACT', {})
    assert TL.num('KPC_TRACE_CHANCE_RATIO', {}) == 1.5 and TL.num('KPC_TRACE_CHANCE_MARGIN', {}) == 2.0
    assert TL.on('KPC_TRACE_HONOR_IMAGE', {})                     # bug fix: on
    assert TL.num('KPC_PARCEL_ADJ_M', {'KPC_PARCEL_ADJ_M': '30'}) == 30


def test_chosen_image_and_acres(TL, tmp_path):
    assert TL.chosen_image({'map_file': 'a.jpg', 'image': 'maps/b.jpg'}) == 'a.jpg'
    assert TL.chosen_image({'image': 'maps/b.jpg'}) == 'b.jpg' and TL.chosen_image({}) is None
    f = tmp_path / 'acres.json'; f.write_text('{"parks": {"US-1": {"acres": 120}, "US-2": "x", "US-3": 0}}')
    a = TL.load_acres(f); assert a == {'US-1': 120.0}
    idx = {'US-1': [{'acres': None}, {'acres': 5}], 'US-2': [{}]}
    assert TL.fill_acres(idx, a) == 1 and idx['US-1'][0]['acres_src'] == 'official acres list' and idx['US-1'][1]['acres'] == 5


def test_better_than_chance(TL):
    assert TL.better_than_chance(10, 4) and not TL.better_than_chance(5, 4) and not TL.better_than_chance(3, 1.5)
    assert TL.better_than_chance(5, 4, ratio=1.2, margin=1)


def test_capped_growth(TL):
    c = [('far', 50, 10), ('near', 5, 30), ('mid', 20, 20)]
    assert TL.capped_growth(c, 100, 0) == (['far', 'near', 'mid'], False)        # no cap = today
    keys, capped = TL.capped_growth(c, 100, 125)       # 1.25 x 100: near (+30) would make 130, mid (+20) fits, far (+10) then would not
    assert keys == ['mid'] and capped


def test_subtract_others(TL):
    from shapely.geometry import box
    g, cut = TL.subtract_others(box(0, 0, 10, 10), [('US-2', box(5, 0, 15, 10))])
    assert abs(g.area - 50) < 1e-9 and abs(cut - 50) < 1e-9
    assert TL.subtract_others(box(0, 0, 1, 1), [])[1] == 0.0


def _find_map(data_scripts, honor):
    src = (data_scripts / 'draft/kpc_trace_picture.py').read_text()
    fn = next(n for n in ast.parse(src).body if isinstance(n, ast.FunctionDef) and n.name == 'find_map')
    ns = {'Path': pathlib.Path, 'glob': __import__('glob'), 'HONOR_IMAGE': honor,
          'TL': import_from(data_scripts / 'draft/kpc_trace_limits.py', 'kpc_trace_limits'),
          'source_type': lambda r: str((r or {}).get('source_type') or 'official')}
    exec(compile(ast.Module([fn], []), 'find_map', 'exec'), ns)
    return ns['find_map']


def test_picture_tracer_honours_the_chosen_image(data_scripts, tmp_path):
    (tmp_path / 'maps').mkdir()
    for n in ('US-1_a.jpg', 'US-1_z.jpg'): (tmp_path / 'maps' / n).write_bytes(b'x')
    row = {'image': 'maps/US-1_z.jpg'}
    assert _find_map(data_scripts, True)(tmp_path, 'US-1', row).name == 'US-1_z.jpg'
    assert _find_map(data_scripts, False)(tmp_path, 'US-1', row).name == 'US-1_a.jpg'      # the old first-jpg pick


def test_picture_tracer_flags(data_scripts):
    t = (data_scripts / 'draft/kpc_trace_picture.py').read_text()
    for f in ('--acres-file', '--chance-ratio', '--chance-margin', '--no-honor-image'): assert f in t, f
    assert 'fill_acres' in t and 'CHANCE_RATIO' in t


def test_parcel_tracer_uses_the_limits(data_scripts):
    t = (data_scripts / 'draft/tools/kpc_parcel_trace/kpc_parcel_trace.py').read_text()
    assert "ADJ_M = TL.num('KPC_PARCEL_ADJ_M')" in t or re.search(r"ADJ_M\s*=.*KPC_PARCEL_ADJ_M", t)
    assert 'capped_growth' in t and 'subtract_others' in t and 'KPC_PARCEL_GROW_CAP' in t + (data_scripts / 'draft/kpc_trace_limits.py').read_text()
