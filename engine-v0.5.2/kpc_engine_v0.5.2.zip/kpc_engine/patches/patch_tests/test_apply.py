"""Each patch applies on its own to the originals, and every patched file compiles / parses."""
import pathlib, re, shutil, subprocess, sys
import yaml
from .patch_helpers import PATCHES, REPOS


def test_each_patch_applies_alone(tmp_path):
    for repo, pats in REPOS.items():
        for p in pats:
            d = tmp_path / p.stem; shutil.copytree(PATCHES / 'orig' / repo, d)
            r = subprocess.run(['patch', '-p1', '--dry-run', '-i', str(p)], cwd=d, capture_output=True, text=True)
            assert r.returncode == 0, (p.name, r.stdout, r.stderr)
            assert 'FAILED' not in r.stdout and 'fuzz' not in r.stdout.lower(), (p.name, r.stdout)


def test_python_compiles(patched):
    for f in patched.rglob('*.py'):
        r = subprocess.run([sys.executable, '-m', 'py_compile', str(f)], capture_output=True, text=True)
        assert r.returncode == 0, (f, r.stderr)


def test_workflow_parses_and_run_blocks_are_bash(patched, tmp_path):
    wf = patched / 'KPC-Links/.github/workflows/kpc-us-key.yml'
    d = yaml.safe_load(wf.read_text())
    n = 0
    for job in d['jobs'].values():
        for st in job.get('steps') or []:
            if 'run' not in st: continue
            body = re.sub(r'\$\{\{[^}]*\}\}', 'X', st['run'])
            f = tmp_path / f'run{n}.sh'; f.write_text(body); n += 1
            r = subprocess.run(['bash', '-n', str(f)], capture_output=True, text=True)
            assert r.returncode == 0, (st.get('name'), r.stderr)
    assert n >= 5
    r = subprocess.run(['bash', '-n', str(patched / 'KPC-Links/.github/scripts/kpc_save_overwrite.sh')], capture_output=True, text=True)
    assert r.returncode == 0, r.stderr


def test_workflow_has_ref_main_and_no_hidden_save(patched):
    t = (patched / 'KPC-Links/.github/workflows/kpc-us-key.yml').read_text()
    assert t.count('ref: main') >= 2
    assert 'kpc_save_overwrite.sh "Key: chat 11' in t and "kpc_save_overwrite.sh --copy 'US answer key'" in t
    bota = t.split('BOT A, the answers writer')[1].split('- id: p')[0]
    nocomment = lambda x: '\n'.join(l.split('#')[0] for l in x.splitlines())
    assert '|| true' not in nocomment(bota.split("cat > /tmp/bota.sh")[1])          # nothing after the clone is hidden any more
    assert 'git pull' not in nocomment(bota)                                         # save by overwrite, never a rebase pull
