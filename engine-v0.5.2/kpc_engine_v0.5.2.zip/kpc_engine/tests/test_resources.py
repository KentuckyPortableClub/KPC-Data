"""v0.5.1 key doctor 'resources' task (report only): the "when X changes, rebuild Y" map and the staleness check."""
import datetime as dt, json, pathlib, subprocess, sys, pytest
from core import key_doctor as KD, rules

NOW = dt.date(2026, 11, 2)


@pytest.fixture(autouse=True)
def _clean():
    rules.reset(); yield; rules.reset()


def put(p, obj):
    p = pathlib.Path(p); p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(obj if isinstance(obj, str) else json.dumps(obj)); return p


def pdf(p, ymd):
    p = pathlib.Path(p); p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(b'%PDF-1.4\n1 0 obj << /Producer (x) /CreationDate (D:' + ymd.encode() + b'061000-05\'00\') >> endobj\n%%EOF'); return p


@pytest.fixture
def club(tmp_path):
    L, D = tmp_path / 'links', tmp_path / 'data'
    put(L / 'kpc-ky-data.json', {'updated': '2026-10-28', 'parks': []})
    put(L / 'data/ky-answer-key.json', {'updated': '2026-10-20'})          # older than its source -> BEHIND
    put(L / 'kpc-top25.json', {'updated': '2026-11-02'})
    pdf(L / 'KPC_Top_25_Nov.pdf', '20261102')
    pdf(L / 'KPC_2fer_Guide.pdf', '20261018')                               # no builder
    put(L / 'ky-overlaps.geojson', {'type': 'FeatureCollection', 'built': '2026-10-10', 'features': []})
    put(L / 'kpc-ky-hours.json', {'updated': '2026-10-25'})
    put(D / 'data/fers/US-KY.json', {'pass1': '2026-10-31', 'st': 'US-KY'})   # no 'updated': newest top-level date counts
    put(D / 'data/hours/state.json', {'areas': {'US-KY': {'updated': '2026-10-30'}}})
    put(D / 'data/alerts/eu.json', {'updated': '2026-10-20T10:00+00:00'})     # past its 2-day limit -> OLD
    put(L / 'nostamp.json', {'a': 1})
    put(L / 'data/world-key/MX.json', {'x': 1}); put(L / 'data/world-key/FR.json', {'x': 1}); put(D / 'data/world-key/FR.json', {'x': 1})
    put(L / 'data/us-key/US-KY.json', {'v': 2}); put(D / 'data/us-key/US-KY.json', {'v': 1})
    cfg = {'grace_days': 1, 'resources': [
        {'id': 'answer-key', 'file': 'links:data/ky-answer-key.json', 'sources': ['links:kpc-ky-data.json'], 'builder': 'kpc-ky-key.yml', 'max_age_days': 30},
        {'id': 'top25-pdf', 'file': 'links:KPC_Top_25_*.pdf', 'sources': ['links:kpc-top25.json'], 'builder': 'kpc-guide-pdf.yml', 'max_age_days': 8, 'stamp_kind': 'pdf'},
        {'id': '2fer-pdf', 'file': 'links:KPC_2fer_Guide.pdf', 'sources': ['data:data/fers/US-KY.json'], 'builder': '', 'max_age_days': 35},
        {'id': 'overlaps', 'file': 'links:ky-overlaps.geojson', 'sources': ['data:data/fers/US-KY.json'], 'builder': 'by hand', 'by_hand': True},
        {'id': 'hours-site', 'file': 'links:kpc-ky-hours.json', 'sources': ['data:data/hours/state.json'], 'builder': '', 'stamp_keys': ['updated']},
        {'id': 'hours-bot', 'file': 'data:data/hours/state.json', 'builder': 'workshop', 'stamp_path': 'areas.US-KY.updated', 'max_age_days': 10},
        {'id': 'eu', 'file': 'data:data/alerts/eu.json', 'builder': 'eu-alerts', 'max_age_days': 2},
        {'id': 'nostamp', 'file': 'links:nostamp.json', 'builder': 'x'},
        {'id': 'gone', 'file': 'links:nothing-*.json', 'builder': 'x'}],
        'twins': [{'a': 'links:kpc-ky-hours.json', 'b': 'data:data/hours/state.json', 'why': 'two hours lists'}],
        'fallback_kinds': ['us-key', 'world-key', 'ca-key']}
    return L, D, cfg


def verdicts(res): return {r['id']: r['verdict'] for r in res['resources']}


def test_verdicts(club, tmp_path):
    L, D, cfg = club
    res = KD.task_resources(L, D, tmp_path / 'out', cfg=cfg, now=NOW)
    assert verdicts(res) == {'answer-key': 'BEHIND', 'top25-pdf': 'OK', '2fer-pdf': 'NO-BUILDER', 'overlaps': 'BEHIND',
                             'hours-site': 'NO-BUILDER', 'hours-bot': 'OK', 'eu': 'OLD', 'nostamp': 'UNKNOWN', 'gone': 'MISSING'}
    assert res['verdict'] == 'WARN'


def test_dates_come_from_the_files_own_stamps(club, tmp_path):
    L, D, cfg = club
    rows = {r['id']: r for r in KD.task_resources(L, D, tmp_path / 'o', cfg=cfg, now=NOW)['resources']}
    assert rows['top25-pdf']['date'] == '2026-11-02'          # PDF CreationDate
    assert rows['hours-bot']['date'] == '2026-10-30'          # stamp_path into a nested dict
    assert rows['overlaps']['date'] == '2026-10-10'           # 'built'
    assert rows['2fer-pdf']['sources'][0]['date'] == '2026-10-31'   # newest top-level date when no stamp field
    assert rows['eu']['age_days'] == 13


def test_grace_day_keeps_same_day_sources_ok(club, tmp_path):
    L, D, cfg = club
    put(L / 'data/ky-answer-key.json', {'updated': '2026-10-27'})   # source 10-28 is within 1 grace day
    assert verdicts(KD.task_resources(L, D, tmp_path / 'o', cfg=cfg, now=NOW))['answer-key'] == 'OK'


def test_twins_and_fallback(club, tmp_path):
    L, D, cfg = club
    res = KD.task_resources(L, D, tmp_path / 'o', cfg=cfg, now=NOW)
    assert res['twins'][0]['a_date'] == '2026-10-25' and res['twins'][0]['both_exist']
    assert res['fallback']['world-key']['only_in_links'] == ['MX.json']
    assert res['fallback']['us-key']['differs'] == ['US-KY.json']
    assert 'ca-key' not in res['fallback']                     # no folder = not listed


def test_writes_only_to_out_and_markdown(club, tmp_path):
    L, D, cfg = club
    before = sorted(str(p) for p in tmp_path.rglob('*') if 'out' not in p.parts)
    KD.task_resources(L, D, tmp_path / 'out', cfg=cfg, now=NOW)
    after = sorted(str(p) for p in tmp_path.rglob('*') if 'out' not in p.parts)
    assert before == after
    md = (tmp_path / 'out/resources.md').read_text()
    assert '| 2fer-pdf |' in md and 'Two copies of one truth' in md and 'world-key: 1 only in KPC-Links' in md


def test_never_red(club, tmp_path):
    L, D, cfg = club
    res = {'resources': KD.task_resources(L, D, tmp_path / 'o', cfg=cfg, now=NOW)}
    assert KD.exit_code(res) == 0
    lines = KD.lines(res)
    assert any('title=Key doctor resources::9 checked' in l for l in lines)
    assert not any(l.startswith('::error') for l in lines)
    assert any('only in KPC-Links' in l for l in lines)


def test_switch_off_skips_task(club, tmp_path):
    L, D, cfg = club
    d, k = rules._node('key_doctor.resources_check'); d[k] = False
    res = KD.run(str(L), str(D), tmp_path / 'o', tasks=['resources'])
    assert 'resources' not in res


def test_task_is_in_the_default_list_and_bundled_map_is_valid():
    assert 'resources' in KD.TASKS
    cfg = json.loads(KD.RES_CFG.read_text())
    ids = [r['id'] for r in cfg['resources']]
    assert len(ids) == len(set(ids)) and len(ids) >= 10
    for r in cfg['resources']:
        assert r['file'].split(':')[0] in ('links', 'data')
        for s in r.get('sources') or []: assert s.split(':')[0] in ('links', 'data')


def test_cli_runs_resources_only(club, tmp_path):
    L, D, cfg = club
    root = pathlib.Path(KD.__file__).resolve().parent.parent
    r = subprocess.run([sys.executable, str(root / 'kpc_engine.py'), 'doctor', '--links', str(L), '--data', str(D),
                        '--out', str(tmp_path / 'cli'), '--tasks', 'resources'], capture_output=True, text=True, cwd=root)
    assert r.returncode == 0, r.stdout + r.stderr
    assert (tmp_path / 'cli/key-doctor/resources.json').exists() and 'engine 0.5.2' in r.stdout
