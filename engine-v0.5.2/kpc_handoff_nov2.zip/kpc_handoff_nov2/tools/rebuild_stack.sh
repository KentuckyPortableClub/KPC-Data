#!/bin/bash
# Rebuild G8 (first pass + review pass), G9, G10, G11 in the local stack trees and write the patches. Local only, no network.
set -e
cd "$(dirname "$0")/../stack"
g(){ git -C "$1" log pre-review --format=%h --grep="^$2\$"; }
for r in KPC-Data KPC-Links; do git -C $r checkout -q -B work "$(g $r G8)"; done
python3 ../tools/make_g8_review.py KPC-Data KPC-Links
for r in KPC-Data KPC-Links; do git -C $r add -A; git -C $r commit -q --amend -m G8; done
python3 ../tools/make_g9_crons.py KPC-Data KPC-Links ../reports/G9-schedule-collisions.md
for r in KPC-Data KPC-Links; do git -C $r add -A; git -C $r commit -qm G9; done
git -C KPC-Links cherry-pick "$(g KPC-Links G10)" >/dev/null
for r in KPC-Data KPC-Links; do git -C $r cherry-pick "$(g $r G11)" >/dev/null; done
d(){ c=$(git -C $1 log --format=%h --grep="^$2\$"); git -C $1 diff --binary $c~1 $c > "../patches/$3"; }
d KPC-Links G7 G7-KPC-Links-save-by-overwrite-everywhere.patch
d KPC-Data G8 G8-KPC-Data-loud-hidden-failures.patch; d KPC-Links G8 G8-KPC-Links-loud-hidden-failures.patch
d KPC-Data G9 G9-KPC-Data-spread-schedules.patch; d KPC-Links G9 G9-KPC-Links-spread-schedules.patch
d KPC-Links G10 G10-KPC-Links-NEEDS-OK-publish-2fers-hours-off-by-default.patch
d KPC-Data G11 G11-KPC-Data-restart-as-the-missed-schedule.patch; d KPC-Links G11 G11-KPC-Links-restart-as-the-missed-schedule.patch
echo rebuilt
