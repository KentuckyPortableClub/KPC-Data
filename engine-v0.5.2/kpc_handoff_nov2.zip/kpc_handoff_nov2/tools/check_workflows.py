#!/usr/bin/env python3
"""Checks a patched workflow tree against the one before it: every file still parses, the jobs and steps are the same (apart
from the G8 ids and report steps), and every 'run:' still passes 'bash -n'.  check_workflows.py <before dir> <after dir>"""
import pathlib, re, subprocess, sys, tempfile

import yaml

GH = re.compile(r'\$\{\{.*?\}\}', re.S)


def bash_ok(script):
    s = GH.sub('X', script)
    with tempfile.NamedTemporaryFile('w', suffix='.sh', delete=False) as f: f.write(s)
    r = subprocess.run(['bash', '-n', f.name], capture_output=True, text=True)
    return r.returncode == 0, r.stderr


def runs(doc):
    for jn, j in (doc.get('jobs') or {}).items():
        for i, st in enumerate(j.get('steps') or []):
            if isinstance(st, dict) and isinstance(st.get('run'), str) and (st.get('shell') in (None, 'bash')):
                yield jn, i, st['run']


def compare(before, after, allow_steps=True):
    probs = []
    b, a = pathlib.Path(before), pathlib.Path(after)
    for pa in sorted(a.glob('.github/workflows/*.yml')):
        pb = b / pa.relative_to(a)
        try: da = yaml.safe_load(pa.read_text())
        except Exception as e: probs.append(f'{pa.name}: YAML {e}'); continue  # noqa: BLE001
        for jn, i, r in runs(da):
            ok, err = bash_ok(r)
            if not ok:
                if pb.exists():
                    db = yaml.safe_load(pb.read_text())
                    rb = ((db.get('jobs') or {}).get(jn) or {}).get('steps') or []
                    if i < len(rb) and isinstance(rb[i], dict) and not bash_ok(rb[i].get('run') or '')[0]: continue  # was already so
                probs.append(f'{pa.name} {jn} step {i}: bash -n {err.strip()[:200]}')
        if not pb.exists(): continue
        db = yaml.safe_load(pb.read_text())
        if set((db.get('jobs') or {})) != set((da.get('jobs') or {})): probs.append(f'{pa.name}: jobs changed')
        for jn, jb in (db.get('jobs') or {}).items():
            ja = da['jobs'][jn]
            sb, sa = jb.get('steps') or [], ja.get('steps') or []
            extra = [s for s in sa if isinstance(s, dict) and str(s.get('name', '')).startswith('Report hidden failures')]
            if len(sa) - len(extra) != len(sb): probs.append(f'{pa.name} {jn}: step count {len(sb)} -> {len(sa)}'); continue
            for x, y in zip(sb, [s for s in sa if s not in extra]):
                if not isinstance(x, dict): continue
                kx, ky = set(x), set(y) - ({'id'} if 'id' not in x else set())
                if kx != ky: probs.append(f'{pa.name} {jn}: step keys {sorted(kx ^ ky)}')
                for k in kx - {'run'}:
                    if x[k] != y.get(k): probs.append(f'{pa.name} {jn} {x.get("name")}: {k} changed')
            for k in set(jb) | set(ja):
                if k != 'steps' and jb.get(k) != ja.get(k): probs.append(f'{pa.name} {jn}: job key {k} changed')
        for k in set(db) | set(da):
            if k != 'jobs' and db.get(k) != da.get(k) and k is not True and k != 'on': probs.append(f'{pa.name}: top key {k} changed')
    return probs


if __name__ == '__main__':
    p = compare(sys.argv[1], sys.argv[2])
    print('\n'.join(p) or 'ok'); sys.exit(1 if p else 0)
