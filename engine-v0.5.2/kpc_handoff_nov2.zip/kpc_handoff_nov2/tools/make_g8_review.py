#!/usr/bin/env python3
"""G8 second pass (Nov 2 review, folded into the G8 patch). After make_g8_loud.py, a line-by-line review found three gaps:
  A. '|| true' lines the first pass did not mark (multi-line python, lines that already had a note, pipelines, case arms),
  B. the first pass's catch-all 'ok: not a failure signal' was wrong for saves, pushes and chain restarts (they ARE failures),
  C. save loops with no '|| true' at all ('for i ...; do pull && push && exit 0/break; sleep; done') end green when every try
     fails, because the last command was 'sleep'.
Every save that never lands now prints ::error (loud, but not red: the Oct 22 'no failure emails for a lost race' rule).
Status-board lines and optional tidy steps keep '|| true' with a '# ok:' reason.   python3 make_g8_review.py <repo dir>..."""
import pathlib, re, sys

OK = '   # ok: '
SAVE = re.compile(r'git push|kpc_push_data\.sh|git -c http\S* push')


def err(title, what):
    return f'|| echo "::error title={title}::{what} (exit $?)"'


def warn(title, what):
    return f'|| echo "::warning title={title}::{what} (exit $?)"'


def loud_for(line):
    """-> the loud replacement for a '|| true' on this line, or None if it is a legit ignore."""
    s = line
    if re.search(r'git rebase --abort 2>/dev/null \|\| true', s): return None, 'there may be no rebase to stop'
    if 'kpc_status.py' in s and not SAVE.search(s): return None, 'a status-board line (reporting only)'
    if re.search(r'gh release create', s): return warn('Release', 'the saved-shapes release could not be made'), None
    if SAVE.search(s) and 'saved=1' in s: return None, 'nothing new to commit; a lost save is reported by the loop itself'
    if SAVE.search(s) and 'git commit' in s:
        return warn('Save', 'nothing new to save, or the push failed: if this run had new files they are NOT saved'), None
    if SAVE.search(s): return err('Save', 'a save or push failed; this run is NOT saved, the next run tries again'), None
    if re.search(r'gh workflow run|/dispatches', s): return err('Next run', 'could not start the next run; the chain stops here'), None
    if re.search(r'gh api -X POST [^|]*/cancel', s): return None, 'the run may have finished already'
    if re.search(r'gh api -X DELETE|gh release', s): return warn('Release', 'a release step failed'), None
    if re.search(r'apt-get install|pip install', s): return warn('install', 'an install step failed; the next steps may not work'), None
    if re.search(r'git (fetch|archive)', s) and 'tar -x' in s: return warn('download', 'a branch could not be read; this run uses what it has'), None
    if re.search(r'squash|--orphan', s): return err('Storage', 'the squash step failed'), None
    if re.search(r'python3? -c "|"\s*\|\|\s*true\s*$|\bjson\.dump\(', s): return warn('inline python', 'a small python step failed'), None
    if re.search(r'timeout \d+m python3|python3? \$[A-Z]+ |python3? \S+\.py', s): return warn('step', 'a script stopped with an error'), None
    if re.search(r'kpc_map_pictures|export --out', s): return warn('step', 'a script stopped with an error'), None
    if re.search(r'find .*-delete|tar xzf|cp (-f )?\S|git (-C \S+ )?rm .*--ignore-unmatch|git branch -f|git checkout -- |git add |mkdir|git config --get|jq |\$\(', s):
        return None, 'an optional file or tidy step'
    if re.search(r'git rebase --abort', s): return None, 'there may be no rebase to stop'
    return None, None


def fix_loop(line):
    """C: a retry loop that pushes. After the loop, say loudly when no try landed. The loop is wrapped in { ...; } so it stays
    one command inside an && chain (it still runs only when the commit before it was made)."""
    if not re.search(r'for i in [^;]*; do [^\n]*' + SAVE.pattern, line) or 'saved=' in line: return line
    msg = 'echo "::error title=Save::not saved after every try; the next run tries again"'
    m = re.search(r'for i in [^;]*; do .*?; done', line)
    if not m: return line
    loop = m.group(0)
    if '&& exit 0;' in loop:
        new = '{ ' + loop + '; ' + msg + '; }'
    elif '&& break;' in loop or re.search(r'&& \{ echo [^}]*; break; \};', loop):
        body = loop.replace('&& break;', '&& { saved=1; break; };', 1) if '&& break;' in loop else re.sub(r'(&& \{ echo [^}]*; )break; \};', r'\1saved=1; break; };', loop, count=1)
        new = '{ saved=0; ' + body + '; [ "$saved" = 1 ] || ' + msg + '; }'
    else:
        return line
    return line[:m.start()] + new + line[m.end():]


PIPE = re.compile(r'^(?P<code>.*?\b(?:python3?|bash)\s+(?P<script>\S+)[^|]*\|(?!\|)[^|]*?)\s*\|\|\s*true\s*$')


def pipeline(code):
    """'python3 x.py | tee log || true' hid x.py failing (a pipeline's status is tee's). Keep the log, report x.py's own status."""
    m = PIPE.match(code)
    if not m or 'kpc_status.py' in code or code.lstrip().startswith('run:') and ' #' in code: return None
    first_pipe = re.search(r'(?<!\|)\|(?!\|)', code).start()
    if '$(' in code[:first_pipe] or code[:first_pipe].count('"') % 2 or code[:first_pipe].count("'") % 2: return None
    name = pathlib.Path(m.group('script').strip('"')).name if m.group('script').endswith('.py') else 'step'
    return (m.group('code') + '; rc=${PIPESTATUS[0]}; [ "$rc" = 0 ] || echo "::warning title=' + name +
            '::stopped with an error (exit $rc), see the log above"')


def multiline_loop(lines, k):
    """'done || true' closing a multi-line push loop (us-key BOT C note): add the saved flag."""
    ind = len(lines[k]) - len(lines[k].lstrip())
    for j in range(k - 1, max(k - 30, -1), -1):
        if re.match(r'\s{%d}(for|while) .*;\s*do\s*$' % ind, lines[j]):
            body = lines[j:k]
            if not any(re.search(r'git (-c \S+ )?push .*&& break\s*$', b) for b in body): return False
            lines[j] = ' ' * ind + 'saved=0; ' + lines[j].lstrip()
            for b in range(j, k):
                lines[b] = re.sub(r'&& break\s*$', '&& { saved=1; break; }', lines[b])
            lines[k] = ' ' * ind + 'done; [ "$saved" = 1 ] || echo "::warning title=Save::the line for the inbox was not saved after every try"'
            return True
    return False


def review(text):
    out, n = [], {'A': 0, 'B': 0, 'C': 0, 'kept': 0}
    src = text.split('\n')
    for k, line in enumerate(src):
        if re.match(r'\s*done \|\| true\s+# ok: not a failure signal', line) and multiline_loop(src, k):
            n['C'] += 1
    for k, line in enumerate(src):
        if line.lstrip().startswith('--') and re.search(r'\|\|\s*true', line):
            j = k
            while j > 0 and src[j - 1].rstrip().endswith('\\'): j -= 1
            ctx = ' '.join(x.strip() for x in src[j:k + 1])
            if 'gh release create' in ctx:
                code, _, note = line.partition('   # ')
                src[k] = re.sub(r'\|\|\s*true\s*$', warn('Release', 'the saved-shapes release could not be made'), code.rstrip()); n['B'] += 1
    for line in src:
        if line.lstrip().startswith('#'):
            out.append(line); continue
        new = fix_loop(line)
        if new != line:
            n['C'] += 1; line = new.replace('saved=1; break; }; ', 'saved=1; break; }; ', 1)
        code, _, note = line.partition('   # ')
        if re.match(r'\s*\{ (saved=0; )?for i in .*next run tries again"; \} \|\| true\s*$', code):
            line = code.rstrip()[:-len('|| true')].rstrip(); n['B'] += 1; out.append(line); continue   # the group always ends 0 now
        if re.search(r'\|\|\s*true\b', code) and (not note.startswith('ok:') or 'ok: a pipeline' in note):
            p = pipeline(code)
            if p:
                line = p; n['A'] += 1; out.append(line); continue
        if re.search(r'\|\|\s*true\b', code):
            m = list(re.finditer(r'\|\|\s*true\b', code))
            loud, reason = loud_for(code)
            if 'ok: not a failure signal' in note or not note.startswith('ok:'):
                tag = 'B' if 'ok: not a failure signal' in note else 'A'
                if loud:
                    i = m[-1]; code = code[:i.start()] + loud + code[i.end():]
                    keep = '' if note.startswith('ok:') or not note else '   # ' + note
                    line = code + keep; n[tag] += 1
                elif reason:
                    keep = '' if note.startswith('ok:') or not note else ' (' + note.strip() + ')'
                    line = code.rstrip() + OK + reason + keep; n['kept'] += 1
        out.append(line)
    return '\n'.join(out), n


def main(roots):
    for root in roots:
        tot = {'A': 0, 'B': 0, 'C': 0, 'kept': 0}
        for p in sorted(pathlib.Path(root, '.github/workflows').glob('*.yml')):
            t = p.read_text(encoding='utf-8'); new, n = review(t)
            if new != t: p.write_text(new, encoding='utf-8')
            for k in tot: tot[k] += n[k]
        print(root, tot)


if __name__ == '__main__':
    main(sys.argv[1:])
