#!/usr/bin/env python3
"""G9: spread the schedules (Nov 2 review). GitHub starts scheduled runs late or skips them when many start in the same minute;
KPC-Data and KPC-Links have ~600 scheduled runs a day and many share a minute. This moves the MINUTE of a cron by at most 7
minutes (never the hour or the day) so fewer workflows start together. It never moves:
  - a cron another line or script compares against (github.event.schedule == '...', SCHED in a script, the watchdog table),
  A minute list (7,27,47) or step (*/15) is moved as a whole (every minute by the same amount, written out as a list).
  python3 make_g9_crons.py <KPC-Data dir> <KPC-Links dir> [report.md]       (edits both trees, writes the before/after table)"""
import datetime as dt, pathlib, re, sys
from collections import defaultdict

CRON_LINE = re.compile(r"^(?P<pre>\s*-\s*cron:\s*)(?P<q>['\"])(?P<c>[^'\"]+)(?P=q)(?P<post>.*)$", re.M)
WEEK0 = dt.datetime(2026, 11, 2, 0, 0)   # Mon Nov 2 2026 00:00 UTC, one week counted
MAXSHIFT = 7
CST = dt.timedelta(hours=-6)


def field(spec, lo, hi):
    out = set()
    for part in spec.split(','):
        step = 1
        if '/' in part: part, s = part.split('/'); step = int(s)
        if part == '*': a, b = lo, hi
        elif '-' in part: a, b = map(int, part.split('-'))
        else: a = b = int(part)
        out |= set(range(a, b + 1, step)) if step > 1 or a != b else {a}
        if step > 1 and part != '*' and '-' not in part: out |= set(range(a, hi + 1, step))
    return out


def fires(cron):
    m, h, dom, mon, dow = cron.split()[:5]
    M, H, D, MO = field(m, 0, 59), field(h, 0, 23), field(dom, 1, 31), field(mon, 1, 12)
    W = {x % 7 for x in field(dow, 0, 7)}
    out = []
    for d in range(7):
        day = WEEK0 + dt.timedelta(days=d)
        wd = (day.weekday() + 1) % 7
        dok = (day.day in D) if dom != '*' and dow == '*' else (wd in W) if dom == '*' else (day.day in D or wd in W)
        if day.month not in MO or not dok: continue
        for hh in H:
            for mm in M: out.append(d * 1440 + hh * 60 + mm)
    return out


def load(root):
    rows = []
    for p in sorted(pathlib.Path(root, '.github/workflows').glob('*.yml')):
        for m in CRON_LINE.finditer(p.read_text(encoding='utf-8')): rows.append([p.name, m['c'], m['c']])
    return rows


def pinned_strings(root):
    """cron strings used anywhere other than a '- cron:' line (expressions, scripts, the watchdog table)."""
    txt = []
    for p in pathlib.Path(root, '.github').rglob('*'):
        if p.is_file() and p.suffix in ('.yml', '.py', '.js', '.sh'):
            for line in p.read_text(encoding='utf-8', errors='replace').splitlines():
                if not CRON_LINE.match(line): txt.append(line)
    return '\n'.join(txt)


def collisions(rows):
    slot = defaultdict(set)
    for name, _, c in rows:
        for t in fires(c): slot[t].add(name)
    bad = {t: s for t, s in slot.items() if len(s) > 1}
    pairs = sum(len(s) * (len(s) - 1) // 2 for s in bad.values())
    return bad, pairs


def plan(rows, other_rows, pins):
    movable = [r for r in rows if re.fullmatch(r'\d+(,\d+)*|\*/\d+', r[1].split()[0])
               and not re.search(r"['\"]@?" + re.escape(r[1]) + r"['\"]", pins)]
    fixed = [r for r in rows if r not in movable]
    occ = defaultdict(set)
    for name, _, c in fixed:
        for t in fires(c): occ[t].add(name)
    other = defaultdict(int)
    for name, _, c in other_rows:
        for t in fires(c): other[t] += 1
    movable.sort(key=lambda r: (-len(fires(r[1])), r[0], r[1]))
    for r in movable:
        f = r[1].split(); ms = sorted(field(f[0], 0, 59)); best = None
        for d in sorted(range(-MAXSHIFT, MAXSHIFT + 1), key=abs):
            nm = [m + d for m in ms]
            if d and any(not 1 <= m <= 58 or m in (15, 30, 45) for m in nm): continue   # stay off the busy quarter hours
            c = ' '.join([','.join(map(str, nm))] + f[1:])
            ts = fires(c)
            same = {t for o in rows if o is not r and o[0] == r[0] for t in fires(o[2])}   # two crons of one workflow must not meet
            cost = sum(t in same for t in ts) * 1000 + sum(len(occ[t] - {r[0]}) for t in ts) * 10 + sum(other[t] for t in ts) + abs(d) * 0.01
            if best is None or cost < best[0]: best = (cost, c)
        if best is None: continue
        r[2] = best[1] if best[1].split()[0] != ','.join(map(str, ms)) or len(ms) > 1 and best[1] != r[1] else r[1]
        if r[2].split()[0] == ','.join(map(str, ms)): r[2] = r[1]   # not moved: keep the original text (e.g. '*/15')
        for t in fires(r[2]): occ[t].add(r[0])
    return rows


def apply(root, rows):
    by = defaultdict(list)
    for name, old, new in rows:
        if old != new: by[name].append((old, new))
    for name, ch in by.items():
        p = pathlib.Path(root, '.github/workflows', name); t = p.read_text(encoding='utf-8')
        for old, new in ch:
            t = CRON_LINE.sub(lambda m: (f"{m['pre']}{m['q']}{new}{m['q']}{m['post']}   # G9 Nov 2: was '{old}' (spread the start times; {shift(old, new)})"
                                         if m['c'] == old else m[0]), t, count=0)
        p.write_text(t, encoding='utf-8')


def shift(old, new):
    d = int(new.split()[0].split(',')[0]) - min(field(old.split()[0], 0, 59))
    return f"now {abs(d)} min {'later' if d > 0 else 'earlier'}"

def cst(t):
    d = WEEK0 + dt.timedelta(minutes=t) + CST
    return d.strftime('%a %-I:%M %p')


def main(data, links, report=None):
    R = {'KPC-Data': (data, load(data)), 'KPC-Links': (links, load(links))}
    before = {k: collisions([list(r) for r in v[1]]) for k, v in R.items()}
    for k, (root, rows) in R.items():
        other = R['KPC-Links' if k == 'KPC-Data' else 'KPC-Data'][1]
        plan(rows, other, pinned_strings(root))
    after = {k: collisions([[r[0], r[1], r[2]] for r in v[1]]) for k, v in R.items()}
    # 'after' must count the NEW crons
    after = {k: collisions([[r[0], r[2], r[2]] for r in v[1]]) for k, v in R.items()}
    before = {k: collisions([[r[0], r[1], r[1]] for r in v[1]]) for k, v in R.items()}
    for k, (root, rows) in R.items(): apply(root, rows)
    out = ['# G9: spreading the schedules (one week, Mon Nov 2 - Sun Nov 8 2026; times in CST)', '',
           'A "shared minute" is a minute in which two or more workflows of the same repo are due to start. "Pairs" counts every two '
           'workflows that share a minute. Crons another line or script compares against are never moved.', '',
           '| Repo | Crons | Moved | Shared minutes before | after | Pairs before | after |', '|---|---|---|---|---|---|---|']
    for k, (root, rows) in R.items():
        mv = sum(1 for r in rows if r[1] != r[2])
        out.append(f'| {k} | {len(rows)} | {mv} | {len(before[k][0])} | {len(after[k][0])} | {before[k][1]} | {after[k][1]} |')
    for k, (root, rows) in R.items():
        out += ['', f'## {k}: moved crons', '', '| Workflow | Before (UTC cron) | After |', '|---|---|---|']
        out += [f'| {n} | `{o}` | `{w}` |' for n, o, w in rows if o != w]
        for label, (bad, _) in (('before', before[k]), ('after', after[k])):
            out += ['', f'### {k}: shared minutes {label} (first 40)', '', '| When (CST) | Workflows |', '|---|---|']
            out += [f'| {cst(t)} | {", ".join(sorted(s))} |' for t, s in sorted(bad.items())[:40]]
    txt = '\n'.join(out) + '\n'
    if report: pathlib.Path(report).write_text(txt)
    for k in R: print(k, 'shared minutes', len(before[k][0]), '->', len(after[k][0]), 'pairs', before[k][1], '->', after[k][1])
    return before, after


if __name__ == '__main__':
    main(*sys.argv[1:4])
