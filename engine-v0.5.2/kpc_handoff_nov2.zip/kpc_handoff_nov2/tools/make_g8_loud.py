#!/usr/bin/env python3
"""G8: hidden failures become loud (Nov 2 review). Run on a repo tree:  python3 make_g8_loud.py <repo dir> [report.md]

1. Every '|| true' in .github/workflows/*.yml is sorted into one of two kinds:
   LOUD  it hid a real failure (a bot script stopped, a save/push, a chain restart, an install, a cache download). It becomes
         '|| echo "::error title=...::... (exit N)"' (or ::warning for installs/downloads). The job STAYS GREEN (the Oct 22
         'never red, no failure emails' rule) but the run page and the summary show a red error line.
   KEPT  a normal 'nothing to do' case (an optional 'git add', nothing to delete, no rebase to stop, no grep match, a pipeline,
         anything inside $( ) or a status-board line). It stays, with a short '# ok: ...' comment when it ends the line.
2. Every step with 'continue-on-error: true' gets an id (if it has none), and each job that has one gets a last step
   'Report hidden failures' (if: always()) that prints ::error for every step that failed but was kept green.
The report lists every occurrence (file, line, kind, why). Nothing else changes; the tests compare the YAML before and after."""
import pathlib, re, sys

import yaml

REPORT_STEP = '''- name: Report hidden failures (Nov 2 review, G8)
  if: always()
  env:
    KPC_STEPS: ${{ toJSON(steps) }}
  run: |
    python3 - <<'PY'
    import json, os
    s = json.loads(os.environ.get('KPC_STEPS') or '{}')
    bad = [k for k, v in s.items() if v.get('outcome') == 'failure' and v.get('conclusion') == 'success']
    for k in bad: print(f'::error title=Step failed (kept green)::step {k} failed; continue-on-error kept the job green. See its log.')
    print(f'{len(bad)} hidden step failure(s)')
    if bad and os.environ.get('GITHUB_STEP_SUMMARY'):
        open(os.environ['GITHUB_STEP_SUMMARY'], 'a').write('**Steps that failed but were kept green:** ' + ', '.join(bad) + '\\n')
    PY
'''

KEPT_WHY = [
    (r'kpc_status\.py', 'a status-board line (reporting only)'),
    (r'^git add\b|\bgit add\b', 'an optional path may not exist'),
    (r'\bgit rebase --abort', 'there may be no rebase to stop'),
    (r'\bgit (checkout|reset|rm)\b', 'nothing to put back is fine'),
    (r'\bgit commit\b', 'nothing to commit is fine'),
    (r'\bgit (worktree|config|show|archive|-C)\b', 'optional git step; the next step reports'),
    (r'^\s*(rm|find|mkdir|cp|mv|rsync|tar|zip|cat|ls|grep|tail|head|cut|sed|jq|echo|kill|wait|test|\[)\b', 'nothing to do is fine'),
]
LOUD = [
    (r'(?:^|[\s(;])(?:python3|node|bash)\s+(?:-u\s+)?(?:\S*/)?(?P<s>[\w.-]+\.(?:py|js|sh))\b', 'error', None),
    (r'(?:^|[\s(;])python3\s+(?:-c\b|-\s)', 'error', 'inline Python'),
    (r'\bpip3? install\b|\bnpm (install|ci)\b|playwright install', 'warning', 'install'),
    (r'\bgh release (download|create|upload)\b|\bcurl\b|\bwget\b', 'warning', 'download'),
    (r'\bgh workflow run\b|/dispatches\b|\bgh run\b', 'error', 'start the next run'),
    (r'\bgit push\b', 'error', 'git push'),
    (r'\bgit (pull|fetch)\b', 'warning', 'git fetch'),
]


def scan(line):
    """-> list of (start, end) of '|| true' outside quotes and before a comment; plus the comment start (or None)."""
    out, q, i, depth, comment = [], None, 0, 0, None
    while i < len(line):
        c = line[i]
        if q:
            if c == '\\' and q == '"': i += 2; continue
            if c == q: q = None
            i += 1; continue
        if c in '\'"': q = c; i += 1; continue
        if line.startswith('$(', i): depth += 1; i += 2; continue
        if c == ')' and depth: depth -= 1; i += 1; continue
        if c == '#' and (i == 0 or line[i - 1] in ' \t'): comment = i; break
        m = re.match(r'\|\|\s*true\b', line[i:])
        if m:
            out.append((i, i + m.end(), depth > 0)); i += m.end(); continue
        i += 1
    return out, comment


def segment(line, pos):
    s = line[:pos]
    s = re.sub(r'^\s*(-\s+)?(run:\s*)?', '', s)
    parts = re.split(r';|&&|\bthen\b|\bdo\b|\belse\b|\|\|', s)
    seg = parts[-1].strip() if parts else s
    return seg, s


def classify(line, pos, in_sub):
    seg, whole = segment(line, pos)
    if in_sub: return 'KEPT', 'inside $( ): the value is used, so the text must not change', None
    if re.search(r'(?<!\|)\|(?!\|)', seg): return 'KEPT', 'a pipeline (its exit status is the last command; follow-up: pipefail)', None
    for rx, why in KEPT_WHY[:1]:
        if re.search(rx, seg): return 'KEPT', why, None
    for rx, lvl, what in LOUD:
        m = re.search(rx, seg)
        if m:
            name = what or m.group('s')
            return 'LOUD', lvl, name
    for rx, why in KEPT_WHY[1:]:
        if re.search(rx, seg): return 'KEPT', why, None
    return 'KEPT', 'not a failure signal', None


def loud_text(lvl, name):
    if name == 'install': msg = 'an install step failed (exit $?); the next steps may not work'
    elif name == 'download': msg = 'a download failed (exit $?); results may use old or missing files'
    elif name == 'start the next run': msg = 'could not start the next run (exit $?); the chain stops here'
    elif name == 'git push': msg = 'a push failed (exit $?); this run is NOT saved'
    elif name == 'git fetch': msg = 'git could not fetch or merge the newest main (exit $?)'
    else: msg = 'stopped with an error (exit $?), see the log above'
    title = name.replace(':', ' ')
    return f'|| echo "::{lvl} title={title}::{msg}"'


def fix_true(txt, fname, rows):
    out = []
    for n, line in enumerate(txt.split('\n'), 1):
        hits, comment = scan(line)
        if not hits or re.match(r'\s*#', line): out.append(line); continue
        new, last = '', 0; kept_reasons = []
        for a, b, sub in hits:
            kind, why, name = classify(line, a, sub)
            new += line[last:a]
            if kind == 'LOUD':
                new += loud_text(why, name); rows.append((fname, n, 'LOUD', f'{why}: {name}', line.strip()[:120]))
            else:
                new += line[a:b]; kept_reasons.append(why); rows.append((fname, n, 'KEPT', why, line.strip()[:120]))
            last = b
        new += line[last:]
        tail = line[hits[-1][1]:]
        if kept_reasons and comment is None and not tail.strip() and classify(line, hits[-1][0], hits[-1][2])[0] == 'KEPT':
            new = new.rstrip() + f'   # ok: {kept_reasons[-1]}'
        out.append(new)
    return '\n'.join(out)


def step_nodes(root):
    """yield (job_name, steps_seq_node) from a composed workflow."""
    if not isinstance(root, yaml.MappingNode): return
    for k, v in root.value:
        if k.value == 'jobs' and isinstance(v, yaml.MappingNode):
            for jk, jv in v.value:
                if not isinstance(jv, yaml.MappingNode): continue
                for sk, sv in jv.value:
                    if sk.value == 'steps' and isinstance(sv, yaml.SequenceNode): yield jk.value, sv


def fix_coe(txt, fname, rows):
    lines = txt.split('\n')
    root = yaml.compose(txt)
    inserts = []   # (line index, text) inserted BEFORE that index
    n_id = 0
    for job, seq in step_nodes(root):
        has = False
        ids = set()
        for st in seq.value:
            if not isinstance(st, yaml.MappingNode): continue
            keys = {k.value: (k, v) for k, v in st.value}
            if 'id' in keys: ids.add(keys['id'][1].value)
        for st in seq.value:
            if not isinstance(st, yaml.MappingNode): continue
            keys = {k.value: (k, v) for k, v in st.value}
            if 'continue-on-error' not in keys or str(keys['continue-on-error'][1].value).lower() != 'true': continue
            has = True
            k = keys['continue-on-error'][0]
            if 'id' not in keys:
                n_id += 1; sid = f'kept_green_{n_id}'
                while sid in ids: n_id += 1; sid = f'kept_green_{n_id}'
                ids.add(sid)
                ln = k.start_mark.line; col = k.start_mark.column
                if lines[ln][:col].strip() in ('', '-'):
                    if lines[ln][:col].strip() == '-':
                        inserts.append((ln + 1, ' ' * col + f'id: {sid}'))
                    else:
                        inserts.append((ln, ' ' * col + f'id: {sid}'))
                    nm = keys.get('name', (None, None))[1]
                    rows.append((fname, ln + 1, 'KEPT-GREEN', f'step gets id {sid}; reported at the end of job {job}', (nm.value if nm is not None else '')[:120]))
            else:
                nm = keys.get('name', (None, None))[1]
                rows.append((fname, k.start_mark.line + 1, 'KEPT-GREEN', f'step id {keys["id"][1].value}; reported at the end of job {job}', (nm.value if nm is not None else '')[:120]))
        if has:
            first = seq.value[0]
            col = first.start_mark.column
            dash_col = col - 2 if lines[first.start_mark.line][col - 2:col] == '- ' else col
            end = seq.end_mark.line
            # the sequence ends at the first line that is not part of it; back up over blank / comment lines
            while end > 0 and (end >= len(lines) or not lines[end - 1].strip() or lines[end - 1].strip().startswith('#')) and end - 1 > seq.value[-1].start_mark.line:
                end -= 1
            if end > len(lines): end = len(lines)
            block = '\n'.join(' ' * dash_col + l if l else l for l in REPORT_STEP.rstrip('\n').split('\n'))
            inserts.append((end, block))
    for idx, text in sorted(inserts, key=lambda x: -x[0]):
        lines[idx:idx] = [text]
    return '\n'.join(lines)


def main(root, report=None):
    rows = []
    for p in sorted(pathlib.Path(root, '.github/workflows').glob('*.yml')):
        t = p.read_text(encoding='utf-8')
        n = fix_true(t, p.name, rows)
        n = fix_coe(n, p.name, rows)
        if n != t: p.write_text(n, encoding='utf-8')
    if report:
        from collections import Counter
        c = Counter((r[2], r[3].split(':')[0] if r[2] == 'LOUD' else r[3]) for r in rows)
        with open(report, 'w') as f:
            f.write(f'# G8 hidden-failure review: {pathlib.Path(root).name}\n\n')
            f.write('| kind | why | count |\n|---|---|---|\n')
            for (k, w), v in sorted(c.items(), key=lambda x: (x[0][0], -x[1])): f.write(f'| {k} | {w} | {v} |\n')
            f.write('\n| file | line | kind | why | line text |\n|---|---|---|---|---|\n')
            for r in rows: f.write('| ' + ' | '.join(str(x).replace('|', '\\|') for x in r) + ' |\n')
    return rows


if __name__ == '__main__':
    rows = main(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else None)
    from collections import Counter
    print(Counter(r[2] for r in rows))
