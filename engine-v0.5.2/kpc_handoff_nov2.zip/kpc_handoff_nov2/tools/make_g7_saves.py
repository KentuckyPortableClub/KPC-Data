#!/usr/bin/env python3
"""G7: the KPC-Links workflows still on the old save ('git pull --rebase --autostash || true' then push) move to the
save-by-overwrite helper (.github/scripts/kpc_save_overwrite.sh). Run on a KPC-Links tree (default: the stack copy):
  python3 make_g7_saves.py <KPC-Links dir>
Rules:
  copy    files only this bot writes: this run's files are copied on top of the newest main (--copy)
  rebase  a file another workflow also writes (shared): the old merge way, but loud and with the retry fix (KPC_SAVE_MODE=rebase)
  words / lines: hand lists and the chat-11 inbox are MERGED (kpc_save_merge.py), never copied over
  oneshot finished one-time jobs (go-live Oct 21, the PDF move): the hidden '|| true' becomes a loud stop
  sync    'git pull' before posting: becomes a loud fetch of the newest main; if it fails, nothing is posted (no double post)"""
import pathlib, re, sys

LINES_INBOX = '.claude/inbox/chat-11.md'
KEY_HAND = ('data/us-key/overrides.json data/us-key/answers-applied.json data/us-key/answers-states.txt '
            'data/ca-key/overrides.json data/ca-key/answers-applied.json data/ca-key/answers-provinces.txt '
            'data/world-key/overrides.json data/world-key/answers-applied.json data/world-key/extra-layers.json')
SPEC = {
    'kpc-approvals.yml': dict(paths='data/kpc-checks-approvals.json'),
    'kpc-band-alerts.yml': dict(paths='kpc-social-state.json'),
    'kpc-boards.yml': dict(paths='kpc-activations.json kpc-guestbook.json kpc-cw-board.json data/kpc-form-checks.json'),
    'kpc-boundary-check.yml': dict(paths='data/us-key data/boundary-report.json data/boundary-score.json data/status', skip=KEY_HAND),
    'kpc-campground-notes.yml': dict(paths='kpc-campground-notes.json photos/campgrounds data/kpc-checks-campgrounds.json', lines=LINES_INBOX),
    'kpc-club-posts.yml': dict(paths='data/kpc-club-posts-state.json'),
    'kpc-community.yml': dict(paths='kpc-community.json photos/community data/kpc-checks-community.json'),
    'kpc-discord-relay.yml': dict(paths='kpc-announcements.json kpc-relay-state.json kpc-conditions.json kpc-events-submitted.json kpc-events-auto.json data/discord-ask-state.json data/discord-mod-state.json photos/announce', tries=6),
    'kpc-discord-watch.yml': dict(paths='data/discord-watch-state.json'),
    'kpc-events.yml': dict(paths='kpc-events-auto.json', lines=LINES_INBOX, sync=True),
    'kpc-fb-comments.yml': dict(paths='data/fb-comments-state.json'),
    'kpc-go-live.yml': dict(oneshot=True),
    'kpc-guide-pdf.yml': dict(paths='$PDFS', pdfs=True),
    'kpc-key-measure.yml': dict(paths='"$KEYDIR"', skip=KEY_HAND),
    'kpc-ky-key.yml': dict(paths='data/ky-answer-key.json'),
    'kpc-ky-maps.yml': dict(paths='data/ky-official-maps.json'),
    'kpc-new-lands.yml': dict(paths='data/ky-lands-seen.json data/ky-wma-owners.json'),
    'kpc-new-refs.yml': dict(paths='data/us-key/answers-states.txt data/ca-key/answers-provinces.txt .claude/build/research/fable data/new-refs kpc-new-refs.json kpc-announcements.json locations.json locations-ky.json data/retired-refs.json data/status kpc-ky-data.json wwff-unmapped.json app/packs kpc-top25.json data/ky-retired.json $(ls kpc-guide-*-data.json ky-*.geojson KPC_Kentucky_*.kml KPC_Kentucky_*.gpx 2>/dev/null)'),
    'kpc-nwr.yml': dict(paths='kpc-nwr.json data/nwr'),
    'kpc-park-alerts.yml': dict(paths='data/park-alerts-state.json kpc-conditions.json'),
    'kpc-park-notes.yml': dict(paths='kpc-park-notes.json kpc-park-notes-form.json photos/notes kpc-park-notes-us.json data/kpc-checks-notes.json', lines=LINES_INBOX),
    'kpc-pdf-release.yml': dict(oneshot=True),
    'kpc-reports.yml': dict(paths='kpc-conditions.json kpc-member-photos.json kpc-events-submitted.json kpc-events-auto.json kpc-comments.json data/kpc-checks-reports.json photos/members'),
    'kpc-ses.yml': dict(paths='kpc-special-events.json kpc-contests.json', lines=LINES_INBOX),
    'kpc-social.yml': dict(paths='kpc-social-state.json'),
    'kpc-state-camps-probe.yml': dict(paths='data/campstate/probe.json'),
    'kpc-state-gis.yml': dict(paths='data/state-gis-found.json data/state-gis-proposed.json data/state-gis.json data/status'),
    'kpc-top25.yml': dict(paths='kpc-top25.json'),
    'kpc-whats-new.yml': dict(paths='data/kpc-whats-new.json'),
    'kpc-world-key.yml': dict(paths='data/world-key data/status', skip=KEY_HAND.replace('data/world-key/answers-countries.txt', ''), words='data/world-key/answers-countries.txt'),
    'kpc-world-probe.yml': dict(paths='data/world-probe.json'),
    'kpc-youtube.yml': dict(paths='kpc-youtube.json', sync=True, multi={'Remember videos shared on Facebook': 'kpc-fb-posted.json', 'Remember videos shared on Discord': 'kpc-discord-videos.json'}),
}
# Files written by more than one workflow (found by shared_files() below and checked by the tests). Overwriting them could drop the
# other bot's change, so their workflows keep the merge (rebase) way, now loud. Follow-up for chat 10: give each one ONE writer.
SHARED = {'kpc-social-state.json', 'kpc-announcements.json', 'kpc-conditions.json', 'kpc-events-auto.json', 'kpc-events-submitted.json',
          'kpc-ky-data.json', 'kpc-top25.json', 'data/state-gis.json', 'locations.json', 'locations-ky.json'}

OLD = re.compile(r'git pull --rebase --autostash')
BLOCK = re.compile(r"(?P<ind>[ ]*)if ! git diff --cached --quiet; then\n(?P=ind)  git commit -m (?P<msg>'[^'\n]*'|\"[^\"\n]*\")\n"
                   r"(?P<body>(?:(?P=ind)  .*\n|\n)*?)(?P=ind)fi\n")
ONELINE = re.compile(r"(?P<ind>[ ]*)if ! git diff --cached --quiet; then git commit -m (?P<msg>'[^'\n]*'|\"[^\"\n]*\"); for i in [0-9 ]+; do git pull --rebase --autostash && git push && break; sleep \$\(\(i\*7\)\); done; fi\n")


def is_shared(paths):
    return sorted(p for p in paths.split() if p in SHARED)


def call(spec, msg, ind, paths=None):
    paths = paths or spec['paths']
    sh = is_shared(paths)
    env = []
    if sh:
        env.append('KPC_SAVE_MODE=rebase')
    else:
        env.append("KPC_SAVE_MODE=\"${{ vars.KPC_SAVE_MODE || 'overwrite' }}\"")
    env.append("KPC_SAVE_RED=\"${{ vars.KPC_SAVE_RED || 'no' }}\"")   # Oct 22 rule: a lost save is loud (::error), not a red job / email
    if spec.get('tries'): env.append(f"KPC_SAVE_TRIES={spec['tries']}")
    if spec.get('skip') and not sh: env.append(f"KPC_SAVE_SKIP=\"{' '.join(spec['skip'].split())}\"")
    if spec.get('words') and not sh: env.append(f"KPC_SAVE_WORDS=\"{spec['words']}\"")
    if spec.get('lines') and not sh: env.append(f"KPC_SAVE_LINES=\"{spec['lines']}\"")
    allp = paths + (' ' + spec['lines'] if spec.get('lines') else '')
    why = (f"shared with another workflow ({', '.join(sh)}): merged the old way, but loud" if sh else
           "this run's files copied on top of the newest main" + ('; the chat-11 inbox and hand lists are merged, not copied' if spec.get('lines') or spec.get('words') else ''))
    out = [f"{ind}# Nov 2 review (G7): save with the shared helper ({why}). A save that never lands prints ::error (no more '|| true'); red only if the repo variable KPC_SAVE_RED=yes.",
           f"{ind}{' '.join(env)} \\",
           f"{ind}  bash .github/scripts/kpc_save_overwrite.sh {'' if sh else '--copy '}{msg} - -- {allp}"]
    return '\n'.join(out) + '\n'


def convert(name, txt):
    spec = SPEC[name]
    if spec.get('oneshot'):
        txt = txt.replace("git pull --rebase --autostash || true\n",
                          "git pull --rebase --autostash || { echo '::error title=Save::could not merge with the newest main; nothing pushed'; exit 1; }   # G7: one-time job, was hidden by '|| true'\n")
        txt = re.sub(r"( *)for i in 1 2 3; do\n\1  git pull --rebase --autostash && git push && break\n\1  sleep \$\(\(i \* 15\)\)\n\1done\n",
                     lambda m: (f"{m[1]}ok=0; for i in 1 2 3; do\n{m[1]}  if git pull --rebase --autostash && git push; then ok=1; break; fi\n{m[1]}  git rebase --abort 2>/dev/null || true; sleep $((i * 15))   # ok: there may be no rebase to stop\n{m[1]}done\n"
                                f"{m[1]}[ $ok = 1 ] || {{ echo '::error title=PDF move::the move was NOT saved after 3 tries'; exit 1; }}   # G7: was silent\n"), txt)
        return txt
    if spec.get('sync'):
        txt = re.sub(r"(?m)^( *)git pull --rebase --autostash \|\| true\n(?=\1(?:node|python3) )",
                     lambda m: f"{m[1]}# G7: post from the newest main; if it cannot be fetched, do not post (a stale state file could post twice)\n"
                               f"{m[1]}git fetch -q origin main && git reset -q --hard origin/main || {{ echo '::error title=Posting::could not fetch the newest main, so nothing was posted this time'; exit 0; }}\n", txt)
    if spec.get('pdfs'):
        m = re.search(r"( *)git commit -m '(Guide PDFs: reprint from the web guides)'\n\1for i in 1 2 3; do\n\1  git pull --rebase --autostash && git push && exit 0\n\1  sleep \$\(\(i \* 15\)\)\n\1done\n\1echo '::notice title=Push skipped::[^\n]*\n", txt)
        ind = m[1]
        new = (f"{ind}PDFS=$(git diff --cached --name-only -- '*.pdf' | tr '\\n' ' ')\n" + call(spec, "'Guide PDFs: reprint from the web guides'", ind))
        return txt[:m.start()] + new + txt[m.end():]
    if name == 'kpc-top25.yml':
        m = re.search(r"( *)git commit -m '(Update Top 25 low-activity parks)'\n\1for i in 1 2 3; do\n\1  git pull --rebase --autostash && git push && exit 0\n\1  sleep \$\(\(i \* 15\)\)\n\1done\n\1echo '::notice title=Push skipped::[^\n]*\n", txt)
        return txt[:m.start()] + call(spec, "'Update Top 25 low-activity parks'", m[1]) + txt[m.end():]
    def blk(m):
        msg = m['msg']; body = m['body']
        if 'pull --rebase' not in body: return m[0]
        paths = None
        if spec.get('multi'):
            for k, v in spec['multi'].items():
                if k in msg: paths = v
        return call(spec, msg, m['ind'], paths)
    txt = BLOCK.sub(blk, txt)
    txt = ONELINE.sub(lambda m: call(spec, m['msg'], m['ind']), txt)
    return txt


def main(root):
    wf = pathlib.Path(root) / '.github/workflows'
    left = []
    for name in sorted(SPEC):
        p = wf / name; t = p.read_text(encoding='utf-8'); n = convert(name, t)
        if n != t: p.write_text(n, encoding='utf-8')
        if OLD.search(n) and not SPEC[name].get('oneshot'): left.append(name)
    others = sorted(p.name for p in wf.glob('*.yml') if p.name not in SPEC and OLD.search(p.read_text()))
    print('converted', len(SPEC), 'still on the old save:', left, 'not in the list:', others)
    return 1 if left or others else 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1] if len(sys.argv) > 1 else '/workspace/kpc_review/general/stack/KPC-Links'))
