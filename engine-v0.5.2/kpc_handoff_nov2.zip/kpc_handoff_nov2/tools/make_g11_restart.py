#!/usr/bin/env python3
"""G11: a watchdog restart does what the MISSED SCHEDULED run would have done (Nov 2 review).
A restart is a by-hand start (workflow_dispatch), so every 'is this the scheduled run?' test in a workflow used to read 'no':
the nightly-only steps were skipped, test defaults were used, keyed calls Brandon limited to by-hand runs were made, and
github.event.schedule was empty. This tool:
  1. adds an optional input 'as_schedule' (the missed cron) to each workflow that has a schedule, a by-hand start and such a test
     (not the ones the watchdog never restarts), and
  2. rewrites those tests so a run started with as_schedule counts as that scheduled run:
       github.event.schedule                 -> (github.event.schedule || inputs.as_schedule)
       github.event_name == 'schedule'       -> (github.event_name == 'schedule' || inputs.as_schedule)
       github.event_name != 'schedule'       -> (github.event_name != 'schedule' && !inputs.as_schedule)
       github.event_name == 'workflow_dispatch' -> (github.event_name == 'workflow_dispatch' && !inputs.as_schedule)
       ${{ github.event_name }} (in a script) -> ${{ (inputs.as_schedule && 'schedule') || github.event_name }}
  3. the watchdog sends as_schedule=<the missed cron> to workflows that declare that input (kpc_watchdog.py, both repos).
  python3 make_g11_restart.py <repo dir> [<repo dir> ...]"""
import pathlib, re, sys
import yaml

SKIP = {'kpc-youtube-comments.yml', 'kpc-social.yml', 'kpc-club-posts.yml', 'kpc-whats-new.yml', 'kpc-park-alerts.yml',
        'kpc-fb-comments.yml', 'kpc-discord-relay.yml', 'kpc-research-helpers.yml'}   # = WATCHDOG_SKIP: never restarted
INPUT = ("      as_schedule:\n"
         "        description: 'Set by the watchdog only: run as the missed scheduled run of this cron (empty = a normal by-hand run)'\n"
         "        required: false\n"
         "        default: ''\n")
TEST = re.compile(r"github\.event\.schedule|github\.event_name")


def rewrite_expr(e):
    e = re.sub(r"github\.event_name\s*==\s*'schedule'", "(github.event_name == 'schedule' || inputs.as_schedule)", e)
    e = re.sub(r"github\.event_name\s*!=\s*'schedule'", "(github.event_name != 'schedule' \0 !inputs.as_schedule)", e)
    e = re.sub(r"github\.event_name\s*==\s*'workflow_dispatch'", "(github.event_name == 'workflow_dispatch' \0 !inputs.as_schedule)", e)
    e = re.sub(r"github\.event\.schedule", "(github.event.schedule || inputs.as_schedule)", e)
    if e.strip() == 'github.event_name':
        e = e.replace('github.event_name', "(inputs.as_schedule && 'schedule') || github.event_name")
    return e.replace('\0', '&&')


def rewrite_line(line):
    if line.lstrip().startswith('#'): return line
    out = re.sub(r"\$\{\{(.*?)\}\}", lambda m: '${{' + rewrite_expr(m.group(1)).rstrip() + ' }}' if TEST.search(m.group(1)) else m.group(0), line)
    m = re.match(r"^(\s*(?:-\s*)?if:\s*)(?![ \t]|\$\{\{)(.+?)(\s+#.*)?$", out)
    if m and TEST.search(m.group(2)):
        out = m.group(1) + rewrite_expr(m.group(2)) + (m.group(3) or '')
    return out


def add_input(t):
    m = re.search(r"^  workflow_dispatch:[ \t]*(\{\})?[ \t]*\n", t, re.M)
    if not m: raise SystemExit('no workflow_dispatch line')
    rest = t[m.end():]
    if re.match(r"    inputs:[ \t]*\n", rest):
        k = m.end() + len(re.match(r"    inputs:[ \t]*\n", rest).group(0))
        return t[:k] + INPUT + t[k:]
    return t[:m.start()] + "  workflow_dispatch:\n    inputs:\n" + INPUT + t[m.end():]


def main(roots):
    done = []
    for root in roots:
        for p in sorted(pathlib.Path(root, '.github/workflows').glob('*.yml')):
            t = p.read_text(encoding='utf-8')
            if p.name in SKIP or not TEST.search(t): continue
            on = yaml.safe_load(t); on = on.get(True) or on.get('on')
            if not isinstance(on, dict) or 'schedule' not in on or 'workflow_dispatch' not in on: continue
            if 'as_schedule' in t: continue
            new = '\n'.join(rewrite_line(l) for l in t.split('\n'))
            new = add_input(new)
            new = new.replace("\non:\n", "\non:\n  # Nov 2 review (G11): a watchdog restart passes as_schedule=<the missed cron>, so it runs exactly like that scheduled run.\n", 1)
            yaml.safe_load(new)
            p.write_text(new, encoding='utf-8')
            done.append(f'{pathlib.Path(root).name}/{p.name}')
    print(len(done), 'workflows:', ' '.join(done))


if __name__ == '__main__':
    main(sys.argv[1:])
