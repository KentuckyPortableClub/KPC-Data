#!/usr/bin/env python3
"""One-time clean-up for G3: replace Google API keys / URL tokens already saved in data/docs/*.json with REMOVED.
Same rules as the patched kpc_docs_bot.scrub(). Usage: scrub_docs_keys.py <KPC-Data dir> [--write]. Dry run by default.
The result is checked to still be valid JSON before anything is written. Never touches git."""
import json, pathlib, re, sys

KEY_RX = re.compile(r'AIza[0-9A-Za-z_\-]{3,}')
TOKEN_RX = re.compile(r'((?:[?&]|%26|%3F)(?:access_token|api_key|apikey|token)(?:=|%3D))(?!REMOVED)[^&"\s\\%]+', re.I)


def scrub(text):
    return TOKEN_RX.sub(lambda m: m.group(1) + 'REMOVED', KEY_RX.sub('REMOVED', text))


def main():
    root = pathlib.Path(sys.argv[1]); write = '--write' in sys.argv
    for f in sorted((root / 'data' / 'docs').glob('*.json')):
        t = f.read_text(encoding='utf-8'); n = scrub(t)
        if n != t:
            json.loads(n)   # still valid JSON or stop
            hits = len(KEY_RX.findall(t)) + len(TOKEN_RX.findall(t))
            print(f'{f.name}: {hits} key/token(s)' + (' removed' if write else ' (dry run)'))
            if write: f.write_text(n, encoding='utf-8')


if __name__ == '__main__': main()
