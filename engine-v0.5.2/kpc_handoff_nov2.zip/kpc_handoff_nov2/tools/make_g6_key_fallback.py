#!/usr/bin/env python3
"""G6 (NEEDS BRANDON'S OK): the site's KPC.dataUrl shim falls back to KPC-Links' own copy when KPC-Data has no file.
For answer-key folders that fallback shows HELD (unreleased) outlines. This rewrites the shim so data/us-key/, data/ca-key/
and data/world-key/ never fall back (a 404 answer instead). Usage: make_g6_key_fallback.py <KPC-Links dir> [--write]
Without --write it only counts. Never touches git."""
import pathlib, sys
OLD = ".catch(function(){return fetch(p,o)})"
NEW = (".catch(function(){return /^data\\/(us|ca|world)-key\\//.test(p)?"
       "Promise.resolve(new Response('',{status:404})):fetch(p,o)})")
SHIM = "fetch('https://kentuckyportableclub.github.io/KPC-Data/'+p,o)"


def rewrite(text):
    if SHIM not in text or OLD not in text: return text, 0
    n = text.count(OLD)
    return text.replace(OLD, NEW), n


def main():
    root = pathlib.Path(sys.argv[1]); write = '--write' in sys.argv
    files = total = 0
    for f in sorted(list(root.glob('*.html')) + list(root.glob('*.js'))):
        t = f.read_text(encoding='utf-8'); new, n = rewrite(t)
        if n:
            files += 1; total += n
            if write: f.write_text(new, encoding='utf-8')
    print(f'{files} files, {total} shims' + (' rewritten' if write else ' (dry run)'))


if __name__ == '__main__': main()
