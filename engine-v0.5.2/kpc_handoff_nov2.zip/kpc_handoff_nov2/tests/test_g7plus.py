"""Tests for the Nov 2 review patches G7-G11. A tree is made from the FRESH copies (/workspace/fresh_nov2, read only) and the
patches are applied in order (G1-G5, G7, G8, G9, G10, G11). Nothing here touches a real repo or the network."""
import collections, importlib.util, json, os, pathlib, re, shutil, subprocess, sys

import pytest
import yaml

HERE = pathlib.Path(__file__).resolve().parent.parent
PATCHES, TOOLS = HERE / 'patches', HERE / 'tools'
FRESH = pathlib.Path('/workspace/fresh_nov2')
ORDER = {'KPC-Data': ['G1', 'G3', 'G4', 'G5', 'G8', 'G9', 'G11'],
         'KPC-Links': ['G1', 'G2', 'G7', 'G8', 'G9', 'G10', 'G11']}
EXTRA = {'KPC-Links': ['kpc-fers-reviewed.json', 'ky-overlaps.geojson', 'KPC_KY_POTA_2fers_3fers.gpx', 'kpc-ky-hours.json',
                       '.claude/build/fers', 'KPC-logo.png']}


def patch(repo, g):
    got = sorted(PATCHES.glob(f'{g}-{repo}-*.patch'))
    assert len(got) == 1, (g, repo, got); return got[0]


def fresh_copy(dst, repo):
    dst.mkdir(parents=True)
    for p in ['.github'] + EXTRA.get(repo, []):
        s = FRESH / repo / p
        (shutil.copytree if s.is_dir() else shutil.copy)(s, dst / p)
    subprocess.run(['git', 'init', '-q'], cwd=dst, check=True)
    return dst


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path); m = importlib.util.module_from_spec(spec)
    sys.modules[name] = m; spec.loader.exec_module(m); return m


@pytest.fixture(scope='session')
def tree(tmp_path_factory):
    out = {}
    for repo, gs in ORDER.items():
        d = fresh_copy(tmp_path_factory.mktemp('stack') / repo, repo)
        for g in gs:
            r = subprocess.run(['git', 'apply', str(patch(repo, g))], cwd=d, capture_output=True, text=True)
            assert r.returncode == 0, (repo, g, r.stderr)
        out[repo] = d
    return out


def workflows(d):
    return {p.name: p.read_text(encoding='utf-8') for p in sorted((d / '.github/workflows').glob('*.yml'))}


# ---------- all ----------
def test_full_stack_applies_in_order_and_yaml_loads(tree):
    for repo, d in tree.items():
        for n, t in workflows(d).items():
            yaml.safe_load(t)


@pytest.mark.parametrize('repo,g', [('KPC-Links', 'G7'), ('KPC-Data', 'G9'), ('KPC-Links', 'G9'), ('KPC-Links', 'G10')])
def test_independent_patches_apply_alone_to_fresh(tmp_path, repo, g):
    d = fresh_copy(tmp_path / repo, repo)
    r = subprocess.run(['git', 'apply', '--check', str(patch(repo, g))], cwd=d, capture_output=True, text=True)
    assert r.returncode == 0, r.stderr


def test_g6_still_applies_on_top_of_everything(tree, tmp_path):
    d = tmp_path / 'L'; shutil.copytree(tree['KPC-Links'], d)
    for f in (FRESH / 'KPC-Links').glob('*.html'): shutil.copy(f, d / f.name)
    for f in (FRESH / 'KPC-Links').glob('*.js'): shutil.copy(f, d / f.name)
    r = subprocess.run(['git', 'apply', '--check', '--include=*.js', '--include=*.html', str(patch('KPC-Links', 'G6'))],
                       cwd=d, capture_output=True, text=True)
    assert r.returncode == 0, r.stderr


# ---------- G7 save by overwrite ----------
@pytest.fixture
def merge(tree):
    return load(tree['KPC-Links'] / '.github/scripts/kpc_save_merge.py', 'kpc_save_merge_t')


def test_g7_words_merge_keeps_both_sides(merge):
    assert merge.merge_words('A B C', 'A C D', 'A B C E') == 'A C D E\n'
    assert merge.merge_words('A', '', 'A') == ''


def test_g7_lines_merge_puts_new_lines_after_the_same_line(merge):
    base = 'h\nq1\nq2\n'; ours = 'h\nq1\nA1\nq2\n'; main = 'h\nq1\nq2\nq3 (new from chat 11)\n'
    out = merge.merge_lines(base, ours, main)
    assert out.splitlines() == ['h', 'q1', 'A1', 'q2', 'q3 (new from chat 11)']
    assert merge.merge_lines(base, ours, out) == out   # never added twice


def code_only(line):
    """The shell part of a line: no '#' note, no text inside '...' (so a note that QUOTES the old save is not a hit)."""
    line = re.split(r'\s+#\s', line, 1)[0]
    return re.sub(r"'[^']*'", "''", line)


def test_g7_no_workflow_left_on_the_old_hidden_save(tree):
    for n, t in workflows(tree['KPC-Links']).items():
        for i, l in enumerate(t.splitlines(), 1):
            c = code_only(l).replace('git rebase --abort 2>/dev/null || true', '')   # stopping a half-done rebase is fine
            assert not re.search(r'git (pull|push)[^\n]*\|\|\s*true', c), f'{n}:{i}'


def sh(cwd, *a, env=None, check=True):
    return subprocess.run(list(a), cwd=cwd, capture_output=True, text=True, check=check, env={**os.environ, **(env or {})})


@pytest.fixture
def remote(tmp_path, tree):
    bare = tmp_path / 'origin.git'; sh(tmp_path, 'git', 'init', '-q', '--bare', '-b', 'main', str(bare))
    seed = tmp_path / 'seed'; sh(tmp_path, 'git', 'clone', '-q', str(bare), str(seed))
    g = ['git', '-c', 'user.name=t', '-c', 'user.email=t@x']
    (seed / 'gen.txt').write_text('v1\n'); (seed / 'other.txt').write_text('o1\n'); (seed / 'answers.txt').write_text('A B C\n')
    (seed / 'inbox.md').write_text('h\nq1\nq2\n')
    sh(seed, 'git', 'checkout', '-q', '-b', 'main'); sh(seed, 'git', 'add', '-A'); sh(seed, *g, 'commit', '-qm', 'seed'); sh(seed, 'git', 'push', '-q', 'origin', 'main')
    def clone(name):
        d = tmp_path / name; sh(tmp_path, 'git', 'clone', '-q', str(bare), str(d))
        sh(d, 'git', 'config', 'user.name', 't'); sh(d, 'git', 'config', 'user.email', 't@x'); return d
    helper = tree['KPC-Links'] / '.github/scripts/kpc_save_overwrite.sh'
    return bare, clone, helper


def show(bare, f):
    return subprocess.run(['git', '--git-dir', str(bare), 'show', f'main:{f}'], capture_output=True, text=True).stdout


def test_g7_overwrite_lands_on_top_of_a_newer_main(remote):
    bare, clone, helper = remote
    run, other = clone('run'), clone('other')
    (run / 'gen.txt').write_text('v2 from this run\n')
    (other / 'other.txt').write_text('o2 by a person\n'); sh(other, 'git', 'commit', '-qam', 'hand'); sh(other, 'git', 'push', '-q')
    r = sh(run, 'bash', str(helper), '--copy', 'gen', '-', '--', 'gen.txt', env={'KPC_SAVE_TRIES': '2'})
    assert 'saved (overwrite' in r.stdout
    assert show(bare, 'gen.txt') == 'v2 from this run\n' and show(bare, 'other.txt') == 'o2 by a person\n'


def test_g7_words_and_lines_are_merged_not_overwritten(remote):
    bare, clone, helper = remote
    run, other = clone('run'), clone('other')
    (run / 'answers.txt').write_text('A C D\n'); (run / 'inbox.md').write_text('h\nq1\nA1\nq2\n')
    (other / 'answers.txt').write_text('A B C E\n'); (other / 'inbox.md').write_text('h\nq1\nq2\nq3\n')
    sh(other, 'git', 'commit', '-qam', 'hand'); sh(other, 'git', 'push', '-q')
    r = sh(run, 'bash', str(helper), '--copy', 'm', '-', '--', 'answers.txt', 'inbox.md',
           env={'KPC_SAVE_WORDS': 'answers.txt', 'KPC_SAVE_LINES': 'inbox.md', 'KPC_SAVE_TRIES': '2'})
    assert 'saved' in r.stdout, r.stdout + r.stderr
    assert show(bare, 'answers.txt') == 'A C D E\n'
    assert show(bare, 'inbox.md') == 'h\nq1\nA1\nq2\nq3\n'


def test_g7_rebase_retry_does_not_call_an_unpushed_commit_nothing(remote):
    bare, clone, helper = remote
    run = clone('run')
    (run / 'gen.txt').write_text('v3\n'); sh(run, 'git', 'commit', '-qam', 'made on an earlier try')
    r = sh(run, 'bash', str(helper), 'gen', '-', '--', 'gen.txt', env={'KPC_SAVE_MODE': 'rebase', 'KPC_SAVE_TRIES': '1'})
    assert 'nothing changed' not in r.stdout and show(bare, 'gen.txt') == 'v3\n'


@pytest.mark.parametrize('red,code', [('yes', 1), ('no', 0)])
def test_g7_a_lost_save_is_loud_and_red_only_when_asked(remote, tmp_path, red, code):
    bare, clone, helper = remote
    run = clone('run'); sh(run, 'git', 'remote', 'set-url', 'origin', str(tmp_path / 'gone.git'))
    (run / 'gen.txt').write_text('v4\n')
    r = sh(run, 'bash', str(helper), '--copy', 'gen', '-', '--', 'gen.txt', env={'KPC_SAVE_TRIES': '1', 'KPC_SAVE_RED': red}, check=False)
    assert '::error title=Save::gen was NOT saved' in r.stdout and r.returncode == code


# ---------- G8 loud failures ----------
@pytest.mark.parametrize('repo', ['KPC-Data', 'KPC-Links'])
def test_g8_every_remaining_or_true_says_why(tree, repo):
    bad = []
    for n, t in workflows(tree[repo]).items():
        for i, l in enumerate(t.splitlines(), 1):
            if re.search(r'\|\|\s*true\b', code_only(l)) and '# ok:' not in l and not l.lstrip().startswith('#'):
                bad.append(f'{n}:{i}')
    assert not bad, bad[:10]


@pytest.mark.parametrize('repo', ['KPC-Data', 'KPC-Links'])
def test_g8_no_save_or_next_run_is_called_not_a_failure(tree, repo):
    """The first pass called saves and chain restarts 'not a failure signal'. The review pass fixed that."""
    bad = []
    for n, t in workflows(tree[repo]).items():
        for i, l in enumerate(t.splitlines(), 1):
            if 'ok: not a failure signal' in l: bad.append(f'{n}:{i}')
            if re.search(r'gh workflow run|/dispatches|kpc_push_data\.sh', code_only(l)) and re.search(r'\|\|\s*true', code_only(l)):
                bad.append(f'{n}:{i}')
    assert not bad, bad[:10]


@pytest.mark.parametrize('repo', ['KPC-Data', 'KPC-Links'])
def test_g8_no_save_loop_ends_silently(tree, repo):
    bad = []
    for n, t in workflows(tree[repo]).items():
        for i, l in enumerate(t.splitlines(), 1):
            if re.search(r'for i in [^;]*; do .*git (-c \S+ )?push', l) and 'not saved after every try' not in l:
                bad.append(f'{n}:{i}')
    assert not bad, bad[:10]


@pytest.mark.parametrize('ok', [True, False])
def test_g8_wrapped_save_loop_says_so_only_when_every_try_failed(tmp_path, ok):
    rv = load(TOOLS / 'make_g8_review.py', 'g8r')
    line = "git commit -qm x && for i in 1 2 3; do PUSH && break; sleep 0; done"
    new = rv.fix_loop(line.replace('PUSH', 'git push -q'))
    assert new.startswith('git commit -qm x && { saved=0; for i in')
    script = 'git() { [ "$1" = commit ] && return 0; ' + ('return 0' if ok else 'return 1') + '; }\n' + new
    out = subprocess.run(['bash', '-c', script], capture_output=True, text=True).stdout
    assert ('not saved after every try' in out) is (not ok)
    # nothing to commit -> the loop does not run, no false alarm
    script = 'git() { return 1; }\n' + new
    assert 'not saved' not in subprocess.run(['bash', '-c', script], capture_output=True, text=True).stdout


@pytest.mark.parametrize('ok', [0, 4])
def test_g8_pipeline_reports_the_script_not_tee(tmp_path, ok):
    rv = load(TOOLS / 'make_g8_review.py', 'g8r2')
    new = rv.pipeline(f'python3 x.py | tee {tmp_path}/log || true')
    assert new and '|| true' not in new
    script = f'python3() {{ echo hi; return {ok}; }}\n' + new
    r = subprocess.run(['bash', '-e', '-c', script], capture_output=True, text=True)
    assert r.returncode == 0 and ('stopped with an error (exit 4)' in r.stdout) is bool(ok)
    assert rv.pipeline('python3 .github/scripts/kpc_status.py board x green "$(grep a f | head -1)" || true') is None


@pytest.mark.parametrize('repo', ['KPC-Data', 'KPC-Links'])
def test_g8_kept_green_steps_are_reported_last(tree, repo):
    for n, t in workflows(tree[repo]).items():
        for j, job in (yaml.safe_load(t).get('jobs') or {}).items():
            steps = job.get('steps') or []
            if any(s.get('continue-on-error') for s in steps):
                assert steps[-1].get('name', '').startswith('Report hidden failures'), (n, j)
                assert all(s.get('id') for s in steps if s.get('continue-on-error')), (n, j)


def test_g8_report_step_finds_a_hidden_failure():
    code = re.search(r"python3 - <<'PY'\n(.*?)\n\s*PY", (PATCHES / patch('KPC-Links', 'G8').name).read_text().replace('\n+', '\n'), re.S)
    assert code
    src = '\n'.join(l.strip() if not l.startswith(' ' * 12) else l[10:] for l in code.group(1).splitlines())
    env = {**os.environ, 'KPC_STEPS': json.dumps({'kept_green_1': {'outcome': 'failure', 'conclusion': 'success'}, 'b': {'outcome': 'success', 'conclusion': 'success'}})}
    env.pop('GITHUB_STEP_SUMMARY', None)
    r = subprocess.run([sys.executable, '-c', 'import textwrap,sys;exec(textwrap.dedent(sys.stdin.read()))'], input=src, text=True, capture_output=True, env=env)
    assert '::error title=Step failed (kept green)::step kept_green_1' in r.stdout, r.stdout + r.stderr


# ---------- G9 schedules ----------
@pytest.fixture(scope='module')
def g9():
    return load(TOOLS / 'make_g9_crons.py', 'make_g9_t')


@pytest.mark.parametrize('repo', ['KPC-Data', 'KPC-Links'])
def test_g9_fewer_shared_minutes(tree, g9, repo):
    before = g9.collisions([[a, b, b] for a, b, _ in g9.load(FRESH / repo)])
    after = g9.collisions([[a, b, b] for a, b, _ in g9.load(tree[repo])])
    assert len(after[0]) < len(before[0]) / 2 and after[1] < before[1]


@pytest.mark.parametrize('repo', ['KPC-Data', 'KPC-Links'])
def test_g9_only_minutes_move_and_at_most_7(tree, g9, repo):
    old = collections.defaultdict(list); new = collections.defaultdict(list)
    for n, c, _ in g9.load(FRESH / repo): old[n].append(c)
    for n, c, _ in g9.load(tree[repo]): new[n].append(c)
    assert old.keys() == new.keys()
    for n in old:
        for a, b in zip(old[n], new[n]):
            assert a.split()[1:] == b.split()[1:], (n, a, b)
            ma, mb = sorted(g9.field(a.split()[0], 0, 59)), sorted(g9.field(b.split()[0], 0, 59))
            assert len(ma) == len(mb) and len({y - x for x, y in zip(ma, mb)}) == 1 and abs(mb[0] - ma[0]) <= 7, (n, a, b)


@pytest.mark.parametrize('repo', ['KPC-Data', 'KPC-Links'])
def test_g9_crons_named_elsewhere_never_move(tree, g9, repo):
    pins = g9.pinned_strings(FRESH / repo)
    now = {c for _, c, _ in g9.load(tree[repo])}
    for n, c, _ in g9.load(FRESH / repo):
        if re.search(r"['\"]@?" + re.escape(c) + r"['\"]", pins):
            assert c in now, (n, c)
    for c in ('23 10 * * *', '37 5 * * 0', '37 */3 * * *', '33 13 * * 5', '49 9 * * *', '7 10 * * *', '37 9 1 * *'):
        if any(c == x for _, x, _ in g9.load(FRESH / repo)): assert c in now


def test_g9_no_workflow_fires_twice_in_one_minute(tree, g9):
    for repo in tree:
        by = collections.defaultdict(list)
        for n, c, _ in g9.load(tree[repo]): by[n] += g9.fires(c)
        assert all(len(v) == len(set(v)) for v in by.values())


# ---------- G10 publish paths ----------
@pytest.fixture
def pub(tree, tmp_path):
    d = tmp_path / 'L'; shutil.copytree(tree['KPC-Links'], d)
    kd = tmp_path / 'kd'
    for f in ('data/fers/US-KY.json', 'data/hours/US-KY.json'):
        (kd / f).parent.mkdir(parents=True, exist_ok=True); shutil.copy(FRESH / 'KPC-Data' / f, kd / f)
    def run(part, **env):
        e = {k: v for k, v in os.environ.items() if not k.startswith(('KPC_FERS', 'KPC_HOURS'))}
        return subprocess.run([sys.executable, str(d / '.github/scripts/kpc_fers_publish.py'), part, '--repo', str(d), '--data', str(kd)],
                              capture_output=True, text=True, env={**e, **env})
    return d, kd, run


def snapshot(d):
    return {f: (d / f).read_bytes() for f in ('ky-overlaps.geojson', 'KPC_KY_POTA_2fers_3fers.gpx', 'kpc-ky-hours.json', '.claude/build/fers/fers.json')}


def test_g10_everything_is_off_by_default(pub):
    d, kd, run = pub; s = snapshot(d)
    for part in ('layer', 'gpx', 'pdf', 'hours'):
        r = run(part); assert r.returncode == 0 and 'switch is off' in r.stdout
    assert snapshot(d) == s and not (d / 'preview').exists()


def test_g10_empty_reviewed_list_changes_nothing_even_when_on(pub):
    d, kd, run = pub; s = snapshot(d)
    assert json.loads((d / 'kpc-fers-reviewed.json').read_text())['reviewed'] == {}
    for part, sw in (('layer', 'KPC_FERS_LAYER'), ('gpx', 'KPC_FERS_GPX'), ('pdf', 'KPC_FERS_PDF')):
        r = run(part, **{sw: 'on'}); assert r.returncode == 0 and 'nothing reviewed' in r.stdout, r.stdout
    assert snapshot(d) == s


def review(d, kd, n=2):
    layer = json.loads((d / 'ky-overlaps.geojson').read_text())['features']
    have = {frozenset(r for r, _ in f['properties']['pota']) for f in layer}
    spots = [s for s in json.loads((kd / 'data/fers/US-KY.json').read_text())['spots'] if s['status'] == 'candidate' and frozenset(s['refs']) not in have]
    pick = spots[:1] + [s for s in spots if s['kind'] in ('river', 'trail')][:n - 1]
    r = json.loads((d / 'kpc-fers-reviewed.json').read_text()); r['reviewed'] = {s['id']: 'test' for s in pick}
    r['reviewed']['US-0000+US-9999@area@0,0'] = 'gone'
    (d / 'kpc-fers-reviewed.json').write_text(json.dumps(r)); return pick


def test_g10_layer_adds_only_reviewed_and_keeps_every_feature(pub):
    d, kd, run = pub; old = json.loads((d / 'ky-overlaps.geojson').read_text())['features']; pick = review(d, kd)
    r = run('layer', KPC_FERS_LAYER='preview'); assert r.returncode == 0 and 'no longer in KPC-Data' in r.stdout
    assert json.loads((d / 'ky-overlaps.geojson').read_text())['features'] == old   # preview: live file untouched
    new = json.loads((d / 'preview/ky-overlaps.geojson').read_text())['features']
    assert new[:len(old)] == old and len(new) == len(old) + len(pick)
    assert {f['properties']['spot_id'] for f in new[len(old):]} == {s['id'] for s in pick}
    assert {f['geometry']['type'] for f in new[len(old):]} <= {'Polygon', 'LineString'}
    run('layer', KPC_FERS_LAYER='on'); again = run('layer', KPC_FERS_LAYER='on')
    assert 'already on the map' in again.stdout   # never added twice


def test_g10_gpx_keeps_all_116_hand_pins(pub):
    d, kd, run = pub; old = (d / 'KPC_KY_POTA_2fers_3fers.gpx').read_text(); hand = json.loads((d / '.claude/build/fers/fers.json').read_text())
    assert old.count('<wpt ') == 116
    pick = review(d, kd)
    r = run('gpx', KPC_FERS_GPX='on'); assert r.returncode == 0, r.stdout + r.stderr
    new = (d / 'KPC_KY_POTA_2fers_3fers.gpx').read_text()
    assert new.count('<wpt ') > 116
    for w in re.findall(r'<wpt .*?</wpt>', old): assert w in new   # every hand pin, word for word (incl. KZ4CP field checks)
    h2 = json.loads((d / '.claude/build/fers/fers.json').read_text())
    assert h2['spots'][:len(hand['spots'])] == hand['spots'] and all(x['g10'].get('gpx') for x in h2['spots'][len(hand['spots']):])
    assert 'nothing reviewed' in run('gpx', KPC_FERS_GPX='on').stdout


def test_g10_pdf_builds_with_the_clubs_own_builder(pub):
    pytest.importorskip('reportlab')
    if not pathlib.Path('/usr/share/fonts/truetype/crosextra/Carlito-Regular.ttf').exists():
        pytest.skip('the PDF fonts (fonts-crosextra-carlito) are not installed on this box; the workflow installs them')
    d, kd, run = pub; review(d, kd)
    r = run('pdf', KPC_FERS_PDF='preview'); assert r.returncode == 0 and (d / 'preview/KPC_Kentucky_POTA_2fers_3fers_Guide.pdf').exists()


def test_g10_hours_never_touch_hand_rows_or_filled_fields(pub):
    d, kd, run = pub; old = json.loads((d / 'kpc-ky-hours.json').read_text())
    r = run('hours', KPC_HOURS_PUBLISH='preview'); assert r.returncode == 0
    assert json.loads((d / 'kpc-ky-hours.json').read_text()) == old
    new = json.loads((d / 'preview/kpc-ky-hours.json').read_text()); assert (d / 'preview/kpc-ky-hours.changes.md').exists()
    assert new['parks'].keys() == old['parks'].keys()
    changed = 0
    for ref, row in old['parks'].items():
        n = new['parks'][ref]
        if row.get('done'): assert n == row; continue
        for k, v in row.items(): assert n[k] == v, (ref, k)
        if n != row:
            changed += 1; assert n['src']['url'].startswith('http') and n['src']['read']
    assert changed > 0


def test_g10_workflow_defaults_off_and_previews_are_not_saved(tree):
    t = (tree['KPC-Links'] / '.github/workflows/kpc-fers-publish.yml').read_text(); y = yaml.safe_load(t)
    on = y.get(True) or y.get('on'); assert list(on) == ['workflow_dispatch']
    env = y['jobs']['publish']['env']
    assert all(v.endswith("|| 'off' }}") for v in env.values()) and len(env) == 4
    assert 'rm -rf preview' in t


# ---------- G11 restart as the missed schedule ----------
def test_g11_watchdog_sends_as_schedule_only_when_declared(tree):
    for repo in tree:
        wd = load(tree[repo] / '.github/scripts/kpc_watchdog.py', f'wd_{repo}')
        w = tree[repo] / '.github/workflows'
        if (w / 'kpc-helpers.yml').exists():
            assert wd.restart_inputs('kpc-helpers.yml', '23 10 * * *', w / 'kpc-helpers.yml') == {'jobs': 'match', 'as_schedule': '23 10 * * *'}
        plain = next(p for p in sorted(w.glob('*.yml')) if 'as_schedule' not in p.read_text() and p.name not in wd.WATCHDOG_INPUTS)
        assert 'as_schedule' not in wd.restart_inputs(plain.name, '1 1 * * *', plain)


def test_g11_every_schedule_test_knows_about_restarts(tree):
    skip = load(TOOLS / 'make_g11_restart.py', 'g11_t').SKIP
    for repo, d in tree.items():
        for n, t in workflows(d).items():
            y = yaml.safe_load(t); on = y.get(True) or y.get('on')
            if n in skip or not isinstance(on, dict) or 'schedule' not in on or 'workflow_dispatch' not in on: continue
            if not re.search(r'github\.event\.schedule|github\.event_name', t): continue
            ins = (on['workflow_dispatch'] or {}).get('inputs') or {}
            assert 'as_schedule' in ins and len(ins) <= 10, n
            for l in t.splitlines():
                for m in re.finditer(r'github\.event\.schedule(?!\s*\|\|\s*inputs\.as_schedule)', l): pytest.fail(f'{n}: {l.strip()}')


def test_g11_expression_rewrite():
    g = load(TOOLS / 'make_g11_restart.py', 'g11_t2')
    assert g.rewrite_line("    if: ${{ github.event.schedule != '49 9 * * *' }}") == "    if: ${{ (github.event.schedule || inputs.as_schedule) != '49 9 * * *' }}"
    assert g.rewrite_line("        if: github.event_name == 'schedule' || inputs.x") == "        if: (github.event_name == 'schedule' || inputs.as_schedule) || inputs.x"
    assert 'inputs.as_schedule && \'schedule\'' in g.rewrite_line('  if [ "${{ github.event_name }}" = schedule ]; then')
    assert g.rewrite_line('# github.event_name') == '# github.event_name'
