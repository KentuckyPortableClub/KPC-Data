"""Tests for the Nov 2 general-review patches (G1-G6). Each test applies the patch to the exact files it was made against
(orig/) in a temp folder, then checks the behaviour. Nothing here touches a repo or the network."""
import datetime as dt, importlib.util, json, os, pathlib, re, shutil, subprocess, sys

import pytest

HERE = pathlib.Path(__file__).resolve().parent.parent
ORIG, PATCHES, TOOLS = HERE / 'orig', HERE / 'patches', HERE / 'tools'
FRESH = pathlib.Path('/workspace/fresh_nov2')


def applied(tmp_path, repo, patch):
    dst = tmp_path / repo
    shutil.copytree(ORIG / repo, dst)
    subprocess.run(['git', 'init', '-q'], cwd=dst, check=True)
    r = subprocess.run(['git', 'apply', str(PATCHES / patch)], cwd=dst, capture_output=True, text=True)
    assert r.returncode == 0, r.stderr
    return dst


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path); m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m); return m


# ---------- G1 watchdog ----------
@pytest.mark.parametrize('repo', ['KPC-Data', 'KPC-Links'])
def test_g1_patch_applies_and_files_stay_identical(tmp_path, repo):
    d = applied(tmp_path, repo, f'G1-{repo}-watchdog-restart-inputs.patch')
    assert 'restart_inputs' in (d / '.github/scripts/kpc_watchdog.py').read_text()


@pytest.fixture
def wd(tmp_path):
    d = applied(tmp_path, 'KPC-Data', 'G1-KPC-Data-watchdog-restart-inputs.patch')
    return load(d / '.github/scripts/kpc_watchdog.py', 'wd_patched')


def test_g1_waiting_room_restart_releases(wd):
    assert wd.restart_inputs('kpc-waiting-room.yml', '43 */2 * * *') == {'mode': 'release-approved'}


def test_g1_closures_restart_is_not_a_ky_test(wd):
    i = wd.restart_inputs('kpc-closures.yml', '37 */6 * * *')
    assert i['test'] == 'no' and i['areas'] == '' and i['chunks'] == '5'


def test_g1_helpers_pick_inputs_by_cron(wd):
    assert wd.restart_inputs('kpc-helpers.yml', '37 5 * * 0') == {'jobs': 'linkfix sitecheck'}
    assert wd.restart_inputs('kpc-helpers.yml', '23 10 * * *') == {'jobs': 'match'}
    assert wd.restart_inputs('kpc-helpers.yml', '0 0 * * *') == {}


def test_g1_old_override_kept_and_unknown_is_empty(wd):
    assert wd.restart_inputs('kpc-new-refs.yml', 'x') == {'dry_run': 'false'}
    assert wd.restart_inputs('kpc-nothing.yml', 'x') == {}


def test_g1_approvals_restart_never_forces_an_email(wd):
    assert wd.restart_inputs('kpc-approvals.yml', '2 21 * * *') == {'send_now': 'false'}


def test_g1_posting_bots_are_skipped_not_restarted(wd):
    for n in ('kpc-youtube-comments.yml', 'kpc-social.yml', 'kpc-club-posts.yml', 'kpc-discord-relay.yml'):
        assert n in wd.WATCHDOG_SKIP


def _run_main(wd, tmp_path, monkeypatch, files):
    wf = tmp_path / 'run' / '.github' / 'workflows'; wf.mkdir(parents=True)
    for n, cron in files.items():
        (wf / n).write_text(f"on:\n  schedule:\n    - cron: '{cron}'\n  workflow_dispatch:\n", encoding='utf-8')
    monkeypatch.chdir(tmp_path / 'run')
    monkeypatch.setattr(wd, 'STATE', pathlib.Path('data/status/watchdog.json'))
    monkeypatch.setattr(wd, 'NOW', dt.datetime(2026, 11, 2, 13, 22, tzinfo=dt.timezone.utc))
    calls = []

    def gh(*a):
        calls.append(a)
        if a[0].endswith('/workflows') and '--paginate' in a:
            return 0, '\n'.join(f'.github/workflows/{n}\tactive\t{i}' for i, n in enumerate(files))
        if '/runs?' in a[0]: return 0, '0'
        return 0, ''
    monkeypatch.setattr(wd, 'gh', gh)
    wd.main()
    return calls, json.load(open('data/status/watchdog.json'))


def test_g1_main_sends_schedule_inputs(wd, tmp_path, monkeypatch):
    calls, st = _run_main(wd, tmp_path, monkeypatch, {'kpc-waiting-room.yml': '43 */2 * * *', 'kpc-helpers.yml': '23 10 * * *'})
    disp = [c for c in calls if c[0].endswith('/dispatches')]
    flat = [' '.join(c) for c in disp]
    assert any('inputs[mode]=release-approved' in f for f in flat)
    assert any('inputs[jobs]=match' in f for f in flat)
    assert len(disp) == 2


def test_g1_main_skips_posting_bot(wd, tmp_path, monkeypatch):
    calls, st = _run_main(wd, tmp_path, monkeypatch, {'kpc-youtube-comments.yml': '37 12 * * *'})
    assert not [c for c in calls if c[0].endswith('/dispatches')]
    assert any('skipped' in v for v in st['restarted'].values())
    assert 'NOT restarted' in ' '.join(st['last_restarted'])


# ---------- G2 honest User-Agent ----------
BROWSER = re.compile(r'(Chrome/\d|Safari/\d|AppleWebKit|Gecko\)|X11; Linux)')


def test_g2_patched_uas_are_honest(tmp_path):
    d = applied(tmp_path, 'KPC-Links', 'G2-KPC-Links-honest-user-agent.patch')
    for f in ('kpc_ky_maps.py', 'kpc_linkcheck.py'):
        ua = re.search(r"^UA = '([^']+)'", (d / '.github/scripts' / f).read_text(), re.M).group(1)
        assert 'KPC' in ua and not BROWSER.search(ua), ua


@pytest.mark.skipif(not FRESH.exists(), reason='fresh copies not on this box')
def test_g2_no_other_bot_pretends_to_be_a_browser():
    """Every crawler UA in both repos, except the two G2 fixes and the club's own site checker (it tests our pages as a phone)."""
    bad = []
    for repo in ('KPC-Links', 'KPC-Data'):
        for f in (FRESH / repo / '.github/scripts').rglob('*.py'):
            if f.name in ('kpc_ky_maps.py', 'kpc_linkcheck.py', 'kpc_site_check.py') or 'test' in f.name: continue
            for m in re.finditer(r"Mozilla/5\.0[^'\"]*", f.read_text(errors='ignore')):
                if BROWSER.search(m.group(0)): bad.append(f'{f.name}: {m.group(0)[:60]}')
    assert not bad, bad


# ---------- G3 keys inside saved map links ----------
SAMPLE = {'url': 'https://api-gb.one.network/embedded?options={"googleAPIKey"%3A"AIzaSyFAKEFAKEFAKEFAKEFAKEFAKEFAKE12345"%2C"x"%3A1}',
          'status': 'no working map link (tried: ok https://api-gb.one.network/embedded?options={"googleAPIKey"%3A"AIzaSyB',
          'arc': 'https://maps.example.gov/arcgis/rest/services/x/MapServer?f=json&token=abc.DEF-123&where=1',
          'photos': 'https://photos.google.com/share/AF1Qip?key=abcdef123', 'plain': 'https://fw.ky.gov/WMA/map.pdf'}


def test_g3_docs_bot_save_removes_keys(tmp_path):
    d = applied(tmp_path, 'KPC-Data', 'G3-KPC-Data-docs-bot-scrub-keys.patch')
    src = (d / '.github/scripts/kpc_docs_bot.py').read_text()
    ns = {}
    exec(compile('import re, json, pathlib\n' + src[src.index('KEY_RX = '):src.index('def host_of')], 'scrub', 'exec'), ns)
    out = tmp_path / 'o.json'; ns['save'](out, SAMPLE)
    t = out.read_text(); j = json.loads(t)
    assert 'AIza' not in t and 'abc.DEF' not in t
    assert j['plain'] == SAMPLE['plain'] and j['photos'] == SAMPLE['photos']   # album links and plain links untouched
    assert 'token=REMOVED&where=1' in j['arc']


def test_g3_cleanup_tool_dry_run_and_write(tmp_path):
    root = tmp_path / 'd'; (root / 'data/docs').mkdir(parents=True)
    (root / 'data/docs/W-GB.json').write_text(json.dumps({'x': SAMPLE}, indent=1))
    (root / 'data/docs/US-KY.json').write_text(json.dumps({'x': {'plain': SAMPLE['plain']}}))
    r = subprocess.run([sys.executable, str(TOOLS / 'scrub_docs_keys.py'), str(root)], capture_output=True, text=True)
    assert 'W-GB.json' in r.stdout and 'US-KY' not in r.stdout and 'AIza' in (root / 'data/docs/W-GB.json').read_text()
    subprocess.run([sys.executable, str(TOOLS / 'scrub_docs_keys.py'), str(root), '--write'], check=True, capture_output=True)
    t = (root / 'data/docs/W-GB.json').read_text(); json.loads(t)
    assert 'AIza' not in t


@pytest.mark.skipif(not (FRESH / 'KPC-Data/data/docs/W-GB.json').exists(), reason='fresh copy not on this box')
def test_g3_real_wgb_file_cleans_to_valid_json():
    sys.path.insert(0, str(TOOLS)); import scrub_docs_keys as s
    t = (FRESH / 'KPC-Data/data/docs/W-GB.json').read_text(encoding='utf-8')
    n = s.scrub(t)
    assert 'AIza' not in n and json.loads(n)
    assert len(n) < len(t) and abs(len(n) - len(t)) < 200


# ---------- G4 key doctor on every release run ----------
def test_g4_doctor_runs_on_every_scheduled_or_release_run(tmp_path):
    import yaml
    d = applied(tmp_path, 'KPC-Data', 'G4-KPC-Data-key-doctor-every-release-run.patch')
    y = yaml.safe_load((d / '.github/workflows/kpc-waiting-room.yml').read_text())
    steps = [s for j in y['jobs'].values() for s in j.get('steps', [])]
    doc = [s for s in steps if str(s.get('name', '')).startswith('KEY DOCTOR')]
    assert len(doc) == 1
    assert doc[0]['if'] == "${{ github.event_name == 'schedule' || inputs.mode == 'release-approved' }}"
    assert doc[0].get('continue-on-error') is True   # still report-only


# ---------- G5 docstring matches the defaults ----------
def test_g5_tidy_docstring_matches_code(tmp_path):
    d = applied(tmp_path, 'KPC-Data', 'G5-KPC-Data-waiting-tidy-docstring.patch')
    t = (d / '.github/scripts/kpc_waiting_room.py').read_text()
    doc = t[t.index('def mode_tidy'):t.index("if os.environ.get('WAITING_TIDY'")]
    assert 'default 1' in doc and 'default 2' in doc and 'default 0 = today' not in doc
    assert "os.environ.get('WAITING_TIDY', '1')" in t and "get('WAITING_KEEP_GENS') or 2" in t


# ---------- G6 (needs OK) the site never shows held keys through the fallback ----------
NODE = shutil.which('node')


def _shim(text):
    return re.search(r"dataUrl=KPC\.dataUrl\|\|(function\(p,o\)\{.*?\});</script>", text).group(1)


@pytest.mark.skipif(not NODE, reason='node not installed')
@pytest.mark.parametrize('path,expect', [('data/us-key/US-KY.json', 404), ('data/world-key/MX.json', 404),
                                         ('data/ca-key/CA-ON.json', 404), ('data/fers/US-KY.json', 200), ('kpc-ky-data.json', 200)])
def test_g6_shim_blocks_key_fallback_only(tmp_path, path, expect):
    sys.path.insert(0, str(TOOLS)); import make_g6_key_fallback as g
    page = (ORIG / 'g6' / 'index.html').read_text(encoding='utf-8')
    new, n = g.rewrite(page); assert n == 1
    js = f"""
const fetch = (u) => u.startsWith('https://kentuckyportableclub.github.io/KPC-Data/')
  ? Promise.resolve(new Response('', {{status: 404}}))          // KPC-Data has no copy
  : Promise.resolve(new Response('links copy', {{status: 200}})); // KPC-Links has one
globalThis.fetch = fetch;
const dataUrl = {_shim(new)};
dataUrl({json.dumps(path)}).then(r => console.log(r.status));
"""
    (tmp_path / 't.mjs').write_text(js)
    out = subprocess.run([NODE, str(tmp_path / 't.mjs')], capture_output=True, text=True)
    assert out.stdout.strip() == str(expect), out.stderr


def test_g6_patch_applies_and_counts(tmp_path):
    sys.path.insert(0, str(TOOLS)); import make_g6_key_fallback as g
    t = (PATCHES / 'G6-KPC-Links-NEEDS-OK-no-key-fallback.patch').read_text()
    assert t.count('\n+++ ') + t.startswith('+++ ') == 120
    assert g.rewrite('no shim here') == ('no shim here', 0)
