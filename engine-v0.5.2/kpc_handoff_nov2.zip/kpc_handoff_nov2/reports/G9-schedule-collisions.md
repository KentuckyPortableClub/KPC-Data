# G9: spreading the schedules (one week, Mon Nov 2 - Sun Nov 8 2026; times in CST)

A "shared minute" is a minute in which two or more workflows of the same repo are due to start. "Pairs" counts every two workflows that share a minute. Crons another line or script compares against are never moved.

| Repo | Crons | Moved | Shared minutes before | after | Pairs before | after |
|---|---|---|---|---|---|---|
| KPC-Data | 55 | 37 | 67 | 8 | 137 | 8 |
| KPC-Links | 58 | 22 | 389 | 0 | 638 | 0 |

## KPC-Data: moved crons

| Workflow | Before (UTC cron) | After |
|---|---|---|
| kpc-camp-layers.yml | `47 7 * * 6` | `49 7 * * 6` |
| kpc-cell.yml | `17 9 3 * *` | `16 9 3 * *` |
| kpc-closures.yml | `37 */6 * * *` | `38 */6 * * *` |
| kpc-collector.yml | `17 */2 * * *` | `16 */2 * * *` |
| kpc-copy-from-links.yml | `41 10 * * *` | `40 10 * * *` |
| kpc-copy-from-links.yml | `41 1 * * *` | `40 1 * * *` |
| kpc-detective.yml | `41 10 * * *` | `39 10 * * *` |
| kpc-discovery.yml | `29 9 * * 3` | `28 9 * * 3` |
| kpc-docs-merge.yml | `27 6 * * *` | `26 6 * * *` |
| kpc-engine.yml | `7 4 * * *` | `8 4 * * *` |
| kpc-eu-alerts.yml | `41 */6 * * *` | `40 */6 * * *` |
| kpc-fetch-files.yml | `41 10 * * *` | `38 10 * * *` |
| kpc-flow.yml | `47 */3 * * *` | `46 */3 * * *` |
| kpc-intake.yml | `41 8 * * *` | `40 8 * * *` |
| kpc-lookup-tidy.yml | `23 11 * * 0` | `24 11 * * 0` |
| kpc-map-links.yml | `11 5 2 * *` | `10 5 2 * *` |
| kpc-map-pictures.yml | `23 7 * * *` | `24 7 * * *` |
| kpc-parking-explorer.yml | `17 9 3 * *` | `18 9 3 * *` |
| kpc-picture-trace.yml | `47 6 * * 0` | `49 6 * * 0` |
| kpc-pota-activity.yml | `11 5 * * 0` | `10 5 * * 0` |
| kpc-retry-hosts.yml | `27 9 3 * *` | `26 9 3 * *` |
| kpc-scoreboard.yml | `23 7 * * *` | `21 7 * * *` |
| kpc-sota-land.yml | `23 9 3 * *` | `24 9 3 * *` |
| kpc-state-leaders.yml | `23 6 * * 3` | `21 6 * * 3` |
| kpc-state-links.yml | `41 8 * * 2` | `39 8 * * 2` |
| kpc-state-trails.yml | `29 7 4 * *` | `28 7 4 * *` |
| kpc-storage.yml | `7 9 * * 0` | `6 9 * * 0` |
| kpc-tile-index.yml | `47 7 * * *` | `46 7 * * *` |
| kpc-us-access.yml | `41 8 6 * *` | `39 8 6 * *` |
| kpc-us-trails.yml | `13 7 * * 1` | `12 7 * * 1` |
| kpc-waiting-room.yml | `43 */2 * * *` | `42 */2 * * *` |
| kpc-watchdog.yml | `7 */2 * * *` | `6 */2 * * *` |
| kpc-watchdog.yml | `37 */2 * * *` | `36 */2 * * *` |
| kpc-workshop.yml | `17 9 * * 0` | `16 9 * * 0` |
| kpc-world-finder.yml | `23 */6 * * *` | `24 */6 * * *` |
| kpc-wwff-dir.yml | `23 9 * * 0` | `24 9 * * 0` |
| kpc-youtube-comments.yml | `37 13 * * *` | `36 13 * * *` |

### KPC-Data: shared minutes before (first 40)

| When (CST) | Workflows |
|---|---|
| Sun 6:37 PM | kpc-closures.yml, kpc-engine.yml, kpc-watchdog.yml |
| Sun 10:07 PM | kpc-engine.yml, kpc-watchdog.yml |
| Sun 11:11 PM | kpc-copy-from-links.yml, kpc-map-links.yml |
| Mon 12:37 AM | kpc-closures.yml, kpc-engine.yml, kpc-watchdog.yml |
| Mon 1:13 AM | kpc-gis-hunter.yml, kpc-us-trails.yml |
| Mon 1:23 AM | kpc-map-pictures.yml, kpc-scoreboard.yml |
| Mon 4:23 AM | kpc-fers-pending.yml, kpc-helpers.yml |
| Mon 4:41 AM | kpc-copy-from-links.yml, kpc-detective.yml, kpc-fetch-files.yml |
| Mon 6:37 AM | kpc-closures.yml, kpc-engine.yml, kpc-watchdog.yml |
| Mon 12:37 PM | kpc-closures.yml, kpc-engine.yml, kpc-watchdog.yml |
| Mon 6:37 PM | kpc-closures.yml, kpc-engine.yml, kpc-watchdog.yml |
| Mon 10:07 PM | kpc-engine.yml, kpc-watchdog.yml |
| Tue 12:37 AM | kpc-closures.yml, kpc-engine.yml, kpc-watchdog.yml |
| Tue 1:23 AM | kpc-map-pictures.yml, kpc-scoreboard.yml |
| Tue 2:41 AM | kpc-intake.yml, kpc-state-links.yml |
| Tue 3:17 AM | kpc-cell.yml, kpc-parking-explorer.yml |
| Tue 4:23 AM | kpc-fers-pending.yml, kpc-helpers.yml |
| Tue 4:41 AM | kpc-copy-from-links.yml, kpc-detective.yml, kpc-fetch-files.yml |
| Tue 6:37 AM | kpc-closures.yml, kpc-engine.yml, kpc-watchdog.yml |
| Tue 12:37 PM | kpc-closures.yml, kpc-engine.yml, kpc-watchdog.yml |
| Tue 6:37 PM | kpc-closures.yml, kpc-engine.yml, kpc-watchdog.yml |
| Tue 10:07 PM | kpc-engine.yml, kpc-watchdog.yml |
| Wed 12:23 AM | kpc-state-leaders.yml, kpc-world-finder.yml |
| Wed 12:37 AM | kpc-closures.yml, kpc-engine.yml, kpc-watchdog.yml |
| Wed 1:23 AM | kpc-map-pictures.yml, kpc-scoreboard.yml |
| Wed 1:29 AM | kpc-camp-weekly.yml, kpc-state-trails.yml |
| Wed 4:23 AM | kpc-fers-pending.yml, kpc-helpers.yml |
| Wed 4:41 AM | kpc-copy-from-links.yml, kpc-detective.yml, kpc-fetch-files.yml |
| Wed 6:37 AM | kpc-closures.yml, kpc-engine.yml, kpc-watchdog.yml |
| Wed 12:37 PM | kpc-closures.yml, kpc-engine.yml, kpc-watchdog.yml |
| Wed 6:37 PM | kpc-closures.yml, kpc-engine.yml, kpc-watchdog.yml |
| Wed 10:07 PM | kpc-engine.yml, kpc-watchdog.yml |
| Thu 12:37 AM | kpc-closures.yml, kpc-engine.yml, kpc-watchdog.yml |
| Thu 1:23 AM | kpc-map-pictures.yml, kpc-scoreboard.yml |
| Thu 4:23 AM | kpc-fers-pending.yml, kpc-helpers.yml |
| Thu 4:41 AM | kpc-copy-from-links.yml, kpc-detective.yml, kpc-fetch-files.yml |
| Thu 6:37 AM | kpc-closures.yml, kpc-engine.yml, kpc-watchdog.yml |
| Thu 12:37 PM | kpc-closures.yml, kpc-engine.yml, kpc-watchdog.yml |
| Thu 6:37 PM | kpc-closures.yml, kpc-engine.yml, kpc-watchdog.yml |
| Thu 10:07 PM | kpc-engine.yml, kpc-watchdog.yml |

### KPC-Data: shared minutes after (first 40)

| When (CST) | Workflows |
|---|---|
| Mon 4:23 AM | kpc-fers-pending.yml, kpc-helpers.yml |
| Tue 4:23 AM | kpc-fers-pending.yml, kpc-helpers.yml |
| Wed 4:23 AM | kpc-fers-pending.yml, kpc-helpers.yml |
| Thu 4:23 AM | kpc-fers-pending.yml, kpc-helpers.yml |
| Fri 4:23 AM | kpc-fers-pending.yml, kpc-helpers.yml |
| Sat 4:23 AM | kpc-fers-pending.yml, kpc-helpers.yml |
| Sat 11:37 PM | kpc-helpers.yml, kpc-tool-trial.yml |
| Sun 4:23 AM | kpc-fers-pending.yml, kpc-helpers.yml |

## KPC-Links: moved crons

| Workflow | Before (UTC cron) | After |
|---|---|---|
| kpc-band-alerts.yml | `11,41 * * * *` | `18,48 * * * *` |
| kpc-boards.yml | `7,27,47 * * * *` | `14,34,54 * * * *` |
| kpc-bot-health.yml | `47 9 * * *` | `44 9 * * *` |
| kpc-bot-queue.yml | `23 * * * *` | `22 * * * *` |
| kpc-discord-relay.yml | `7,22,37,52 * * * *` | `5,20,35,50 * * * *` |
| kpc-discord-watch.yml | `48 * * * *` | `47 * * * *` |
| kpc-fb-comments.yml | `35 * * * *` | `32 * * * *` |
| kpc-geo-cache.yml | `17 9 3 * *` | `13 9 3 * *` |
| kpc-ky-key.yml | `11 8 * * 1` | `10 8 * * 1` |
| kpc-ky-maps.yml | `17 9 * * 2` | `21 9 * * 2` |
| kpc-link-check.yml | `41 10 * * 0` | `43 10 * * 0` |
| kpc-new-refs.yml | `41 12 * * *` | `39 12 * * *` |
| kpc-nwr.yml | `17 9 3 * *` | `12 9 3 * *` |
| kpc-park-alerts.yml | `5 11,14,17,20,23,2 * * *` | `3 11,14,17,20,23,2 * * *` |
| kpc-pota-discord.yml | `17 * * * *` | `19 * * * *` |
| kpc-ref-check.yml | `23 10 * * 1` | `24 10 * * 1` |
| kpc-top25.yml | `17 11 * * 1` | `16 11 * * 1` |
| kpc-us-key.yml | `19 9 * * *` | `17 9 * * *` |
| kpc-us-key.yml | `47 11 * * *` | `46 11 * * *` |
| kpc-watchdog.yml | `7 */2 * * *` | `4 */2 * * *` |
| kpc-watchdog.yml | `37 */2 * * *` | `33 */2 * * *` |
| kpc-world-cache.yml | `47 9 4 * *` | `43 9 4 * *` |

### KPC-Links: shared minutes before (first 40)

| When (CST) | Workflows |
|---|---|
| Sun 6:07 PM | kpc-boards.yml, kpc-discord-relay.yml, kpc-watchdog.yml |
| Sun 6:37 PM | kpc-discord-relay.yml, kpc-watchdog.yml |
| Sun 6:41 PM | kpc-band-alerts.yml, kpc-park-notes.yml |
| Sun 7:07 PM | kpc-boards.yml, kpc-discord-relay.yml |
| Sun 8:07 PM | kpc-boards.yml, kpc-discord-relay.yml, kpc-watchdog.yml |
| Sun 8:17 PM | kpc-community.yml, kpc-pota-discord.yml |
| Sun 8:37 PM | kpc-discord-relay.yml, kpc-watchdog.yml |
| Sun 9:07 PM | kpc-boards.yml, kpc-discord-relay.yml |
| Sun 10:07 PM | kpc-boards.yml, kpc-discord-relay.yml, kpc-watchdog.yml |
| Sun 10:37 PM | kpc-discord-relay.yml, kpc-watchdog.yml |
| Sun 11:07 PM | kpc-boards.yml, kpc-discord-relay.yml |
| Sun 11:23 PM | kpc-bot-queue.yml, kpc-research-helpers.yml |
| Mon 12:07 AM | kpc-boards.yml, kpc-discord-relay.yml, kpc-watchdog.yml |
| Mon 12:17 AM | kpc-pota-discord.yml, kpc-world-pota.yml |
| Mon 12:37 AM | kpc-discord-relay.yml, kpc-watchdog.yml |
| Mon 12:41 AM | kpc-band-alerts.yml, kpc-park-notes.yml |
| Mon 1:07 AM | kpc-boards.yml, kpc-discord-relay.yml |
| Mon 1:37 AM | kpc-boundary-check.yml, kpc-discord-relay.yml |
| Mon 2:07 AM | kpc-boards.yml, kpc-discord-relay.yml, kpc-watchdog.yml |
| Mon 2:11 AM | kpc-band-alerts.yml, kpc-ky-key.yml |
| Mon 2:17 AM | kpc-community.yml, kpc-pota-discord.yml |
| Mon 2:37 AM | kpc-discord-relay.yml, kpc-watchdog.yml |
| Mon 3:07 AM | kpc-boards.yml, kpc-discord-relay.yml |
| Mon 3:47 AM | kpc-boards.yml, kpc-bot-health.yml |
| Mon 4:07 AM | kpc-boards.yml, kpc-discord-relay.yml, kpc-watchdog.yml, kpc-world-key.yml |
| Mon 4:23 AM | kpc-bot-queue.yml, kpc-ref-check.yml |
| Mon 4:37 AM | kpc-discord-relay.yml, kpc-watchdog.yml |
| Mon 4:41 AM | kpc-band-alerts.yml, kpc-ses.yml |
| Mon 5:07 AM | kpc-boards.yml, kpc-discord-relay.yml |
| Mon 5:17 AM | kpc-events.yml, kpc-pota-discord.yml, kpc-top25.yml |
| Mon 5:23 AM | kpc-bot-queue.yml, kpc-youtube.yml |
| Mon 5:47 AM | kpc-boards.yml, kpc-us-key.yml |
| Mon 6:07 AM | kpc-boards.yml, kpc-discord-relay.yml, kpc-watchdog.yml |
| Mon 6:37 AM | kpc-discord-relay.yml, kpc-watchdog.yml |
| Mon 6:41 AM | kpc-band-alerts.yml, kpc-new-refs.yml, kpc-park-notes.yml |
| Mon 7:07 AM | kpc-boards.yml, kpc-discord-relay.yml, kpc-social.yml |
| Mon 7:23 AM | kpc-bot-queue.yml, kpc-research-helpers.yml |
| Mon 7:37 AM | kpc-discord-relay.yml, kpc-new-lands.yml |
| Mon 7:41 AM | kpc-band-alerts.yml, kpc-guide-pdf.yml |
| Mon 8:07 AM | kpc-boards.yml, kpc-discord-relay.yml, kpc-watchdog.yml |

### KPC-Links: shared minutes after (first 40)

| When (CST) | Workflows |
|---|---|
