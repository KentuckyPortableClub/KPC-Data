# G8 hidden-failure review: KPC-Data

| kind | why | count |
|---|---|---|
| KEPT | nothing to do is fine | 45 |
| KEPT | not a failure signal | 42 |
| KEPT | a pipeline (its exit status is the last command; follow-up: pipefail) | 30 |
| KEPT | a status-board line (reporting only) | 17 |
| KEPT | optional git step; the next step reports | 14 |
| KEPT | nothing to commit is fine | 6 |
| KEPT | an optional path may not exist | 4 |
| KEPT | nothing to put back is fine | 1 |
| KEPT-GREEN | step gets id kept_green_1; reported at the end of job run | 20 |
| KEPT-GREEN | step gets id kept_green_2; reported at the end of job run | 11 |
| KEPT-GREEN | step id r; reported at the end of job run | 7 |
| KEPT-GREEN | step gets id kept_green_1; reported at the end of job closures | 2 |
| KEPT-GREEN | step gets id kept_green_2; reported at the end of job closures | 2 |
| KEPT-GREEN | step id gap; reported at the end of job run | 2 |
| KEPT-GREEN | step id c; reported at the end of job run | 2 |
| KEPT-GREEN | step gets id kept_green_1; reported at the end of job copy | 2 |
| KEPT-GREEN | step gets id kept_green_2; reported at the end of job copy | 2 |
| KEPT-GREEN | step gets id kept_green_1; reported at the end of job fers | 2 |
| KEPT-GREEN | step gets id kept_green_2; reported at the end of job fers | 2 |
| KEPT-GREEN | step gets id kept_green_3; reported at the end of job fers | 2 |
| KEPT-GREEN | step gets id kept_green_4; reported at the end of job fers | 2 |
| KEPT-GREEN | step gets id kept_green_1; reported at the end of job watch | 2 |
| KEPT-GREEN | step gets id kept_green_3; reported at the end of job run | 2 |
| KEPT-GREEN | step gets id kept_green_4; reported at the end of job run | 2 |
| KEPT-GREEN | step gets id kept_green_1; reported at the end of job slice | 1 |
| KEPT-GREEN | step gets id kept_green_1; reported at the end of job campsites | 1 |
| KEPT-GREEN | step gets id kept_green_2; reported at the end of job campsites | 1 |
| KEPT-GREEN | step gets id kept_green_3; reported at the end of job campsites | 1 |
| KEPT-GREEN | step gets id kept_green_4; reported at the end of job campsites | 1 |
| KEPT-GREEN | step id gate; reported at the end of job closures | 1 |
| KEPT-GREEN | step gets id kept_green_3; reported at the end of job closures | 1 |
| KEPT-GREEN | step gets id kept_green_1; reported at the end of job collect | 1 |
| KEPT-GREEN | step gets id kept_green_2; reported at the end of job collect | 1 |
| KEPT-GREEN | step id fp; reported at the end of job collect | 1 |
| KEPT-GREEN | step gets id kept_green_3; reported at the end of job collect | 1 |
| KEPT-GREEN | step gets id kept_green_4; reported at the end of job collect | 1 |
| KEPT-GREEN | step gets id kept_green_3; reported at the end of job copy | 1 |
| KEPT-GREEN | step gets id kept_green_4; reported at the end of job copy | 1 |
| KEPT-GREEN | step gets id kept_green_5; reported at the end of job copy | 1 |
| KEPT-GREEN | step gets id kept_green_6; reported at the end of job copy | 1 |
| KEPT-GREEN | step gets id kept_green_7; reported at the end of job copy | 1 |
| KEPT-GREEN | step gets id kept_green_1; reported at the end of job detective | 1 |
| KEPT-GREEN | step id gate; reported at the end of job detective | 1 |
| KEPT-GREEN | step gets id kept_green_2; reported at the end of job detective | 1 |
| KEPT-GREEN | step gets id kept_green_3; reported at the end of job detective | 1 |
| KEPT-GREEN | step gets id kept_green_1; reported at the end of job discover | 1 |
| KEPT-GREEN | step gets id kept_green_2; reported at the end of job discover | 1 |
| KEPT-GREEN | step gets id kept_green_3; reported at the end of job discover | 1 |
| KEPT-GREEN | step id m; reported at the end of job merge | 1 |
| KEPT-GREEN | step gets id kept_green_1; reported at the end of job merge | 1 |
| KEPT-GREEN | step gets id kept_green_1; reported at the end of job docs | 1 |
| KEPT-GREEN | step gets id kept_green_2; reported at the end of job docs | 1 |
| KEPT-GREEN | step gets id kept_green_3; reported at the end of job docs | 1 |
| KEPT-GREEN | step gets id kept_green_4; reported at the end of job docs | 1 |
| KEPT-GREEN | step gets id kept_green_1; reported at the end of job crawl | 1 |
| KEPT-GREEN | step gets id kept_green_1; reported at the end of job fetcher | 1 |
| KEPT-GREEN | step gets id kept_green_2; reported at the end of job fetcher | 1 |
| KEPT-GREEN | step gets id kept_green_3; reported at the end of job fetcher | 1 |
| KEPT-GREEN | step gets id kept_green_4; reported at the end of job fetcher | 1 |
| KEPT-GREEN | step gets id kept_green_5; reported at the end of job fetcher | 1 |
| KEPT-GREEN | step gets id kept_green_6; reported at the end of job fetcher | 1 |
| KEPT-GREEN | step gets id kept_green_7; reported at the end of job worker | 1 |
| KEPT-GREEN | step gets id kept_green_8; reported at the end of job worker | 1 |
| KEPT-GREEN | step gets id kept_green_9; reported at the end of job worker | 1 |
| KEPT-GREEN | step gets id kept_green_10; reported at the end of job checker | 1 |
| KEPT-GREEN | step gets id kept_green_1; reported at the end of job again | 1 |
| KEPT-GREEN | step gets id kept_green_2; reported at the end of job again | 1 |
| KEPT-GREEN | step id p; reported at the end of job plan | 1 |
| KEPT-GREEN | step gets id kept_green_5; reported at the end of job observations | 1 |
| KEPT-GREEN | step gets id kept_green_6; reported at the end of job observations | 1 |
| KEPT-GREEN | step gets id kept_green_1; reported at the end of job water | 1 |
| KEPT-GREEN | step gets id kept_green_5; reported at the end of job fers | 1 |
| KEPT-GREEN | step gets id kept_green_1; reported at the end of job fetch | 1 |
| KEPT-GREEN | step gets id kept_green_1; reported at the end of job flow | 1 |
| KEPT-GREEN | step gets id kept_green_1; reported at the end of job handoff | 1 |
| KEPT-GREEN | step gets id kept_green_1; reported at the end of job hunt | 1 |
| KEPT-GREEN | step gets id kept_green_2; reported at the end of job hunt | 1 |
| KEPT-GREEN | step gets id kept_green_3; reported at the end of job hunt | 1 |
| KEPT-GREEN | step gets id kept_green_4; reported at the end of job hunt | 1 |
| KEPT-GREEN | step id m; reported at the end of job match | 1 |
| KEPT-GREEN | step gets id kept_green_1; reported at the end of job match | 1 |
| KEPT-GREEN | step gets id kept_green_2; reported at the end of job linkfix | 1 |
| KEPT-GREEN | step gets id kept_green_3; reported at the end of job sitecheck | 1 |
| KEPT-GREEN | step id gate; reported at the end of job intake | 1 |
| KEPT-GREEN | step gets id kept_green_1; reported at the end of job intake | 1 |
| KEPT-GREEN | step gets id kept_green_2; reported at the end of job intake | 1 |
| KEPT-GREEN | step gets id kept_green_3; reported at the end of job intake | 1 |
| KEPT-GREEN | step gets id kept_green_1; reported at the end of job tidy | 1 |
| KEPT-GREEN | step gets id kept_green_2; reported at the end of job picture-maps | 1 |
| KEPT-GREEN | step id x; reported at the end of job run | 1 |
| KEPT-GREEN | step id fers; reported at the end of job run | 1 |
| KEPT-GREEN | step id conv; reported at the end of job run | 1 |
| KEPT-GREEN | step id links; reported at the end of job run | 1 |
| KEPT-GREEN | step gets id kept_green_1; reported at the end of job explore | 1 |
| KEPT-GREEN | step gets id kept_green_2; reported at the end of job explore | 1 |
| KEPT-GREEN | step gets id kept_green_3; reported at the end of job explore | 1 |
| KEPT-GREEN | step gets id kept_green_1; reported at the end of job activity | 1 |
| KEPT-GREEN | step gets id kept_green_1; reported at the end of job retry | 1 |
| KEPT-GREEN | step gets id kept_green_1; reported at the end of job scoreboard | 1 |
| KEPT-GREEN | step gets id kept_green_2; reported at the end of job scoreboard | 1 |
| KEPT-GREEN | step gets id kept_green_3; reported at the end of job scoreboard | 1 |
| KEPT-GREEN | step gets id kept_green_4; reported at the end of job scoreboard | 1 |
| KEPT-GREEN | step gets id kept_green_1; reported at the end of job leaders | 1 |
| KEPT-GREEN | step gets id kept_green_2; reported at the end of job leaders | 1 |
| KEPT-GREEN | step gets id kept_green_3; reported at the end of job leaders | 1 |
| KEPT-GREEN | step gets id kept_green_4; reported at the end of job leaders | 1 |
| KEPT-GREEN | step gets id kept_green_1; reported at the end of job keep | 1 |
| KEPT-GREEN | step gets id kept_green_2; reported at the end of job keep | 1 |
| KEPT-GREEN | step gets id kept_green_3; reported at the end of job keep | 1 |
| KEPT-GREEN | step gets id kept_green_4; reported at the end of job keep | 1 |
| KEPT-GREEN | step gets id kept_green_1; reported at the end of job index | 1 |
| KEPT-GREEN | step gets id kept_green_2; reported at the end of job index | 1 |
| KEPT-GREEN | step gets id kept_green_1; reported at the end of job test | 1 |
| KEPT-GREEN | step gets id kept_green_1; reported at the end of job trial | 1 |
| KEPT-GREEN | step gets id kept_green_2; reported at the end of job trial | 1 |
| KEPT-GREEN | step gets id kept_green_3; reported at the end of job trial | 1 |
| KEPT-GREEN | step gets id kept_green_4; reported at the end of job trial | 1 |
| KEPT-GREEN | step gets id kept_green_5; reported at the end of job trial | 1 |
| KEPT-GREEN | step gets id kept_green_1; reported at the end of job waiting | 1 |
| KEPT-GREEN | step gets id kept_green_2; reported at the end of job waiting | 1 |
| KEPT-GREEN | step gets id kept_green_3; reported at the end of job waiting | 1 |
| KEPT-GREEN | step gets id kept_green_4; reported at the end of job waiting | 1 |
| KEPT-GREEN | step gets id kept_green_5; reported at the end of job waiting | 1 |
| KEPT-GREEN | step gets id kept_green_6; reported at the end of job waiting | 1 |
| KEPT-GREEN | step gets id kept_green_7; reported at the end of job waiting | 1 |
| KEPT-GREEN | step gets id kept_green_8; reported at the end of job waiting | 1 |
| KEPT-GREEN | step gets id kept_green_9; reported at the end of job waiting | 1 |
| KEPT-GREEN | step gets id kept_green_2; reported at the end of job watch | 1 |
| KEPT-GREEN | step gets id kept_green_3; reported at the end of job watch | 1 |
| KEPT-GREEN | step gets id kept_green_1; reported at the end of job look | 1 |
| KEPT-GREEN | step gets id kept_green_2; reported at the end of job look | 1 |
| KEPT-GREEN | step id b; reported at the end of job book | 1 |
| KEPT-GREEN | step gets id kept_green_1; reported at the end of job book | 1 |
| KEPT-GREEN | step id gate; reported at the end of job workshop | 1 |
| KEPT-GREEN | step gets id kept_green_1; reported at the end of job workshop | 1 |
| KEPT-GREEN | step gets id kept_green_2; reported at the end of job workshop | 1 |
| KEPT-GREEN | step gets id kept_green_3; reported at the end of job workshop | 1 |
| KEPT-GREEN | step gets id kept_green_4; reported at the end of job workshop | 1 |
| KEPT-GREEN | step gets id kept_green_1; reported at the end of job find | 1 |
| KEPT-GREEN | step gets id kept_green_2; reported at the end of job find | 1 |
| KEPT-GREEN | step gets id kept_green_1; reported at the end of job harvest | 1 |
| KEPT-GREEN | step gets id kept_green_2; reported at the end of job harvest | 1 |
| KEPT-GREEN | step gets id kept_green_3; reported at the end of job harvest | 1 |
| KEPT-GREEN | step gets id kept_green_4; reported at the end of job harvest | 1 |
| KEPT-GREEN | step gets id kept_green_1; reported at the end of job comments | 1 |
| KEPT-GREEN | step gets id kept_green_2; reported at the end of job comments | 1 |
| KEPT-GREEN | step gets id kept_green_3; reported at the end of job comments | 1 |
| LOUD | error | 228 |
| LOUD | warning | 49 |

| file | line | kind | why | line text |
|---|---|---|---|---|
| kpc-camp-layers.yml | 40 | KEPT | optional git step; the next step reports | git fetch -q origin tools-out:tools-out && git worktree add -q ../out tools-out \|\| true |
| kpc-camp-layers.yml | 41 | LOUD | error: kpc_intake_reader.py | python3 .github/scripts/kpc_intake_reader.py camping \|\| true |
| kpc-camp-layers.yml | 50 | KEPT | not a failure signal | python3 .github/scripts/kpc_status.py board 'Campground layers' green "$N state lists $(date -u +%F) (tools-out)" 'the c |
| kpc-camp-layers.yml | 51 | LOUD | error: git push | (cd ../out && rm -rf camp_layers/work/cache && git add -A camp_layers && git commit -qm "campground layers (run ${{ gith |
| kpc-camp-layers.yml | 58 | LOUD | error: start the next run | run: gh workflow run kpc-camp-layers.yml -R ${{ github.repository }} \|\| true |
| kpc-camp-layers.yml | 36 | KEPT-GREEN | step id r; reported at the end of job run | Run |
| kpc-camp-layers.yml | 55 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job run | Next run |
| kpc-camp-weekly.yml | 33 | LOUD | error: start the next run | gh api -X POST repos/${{ github.repository }}/actions/workflows/kpc-workshop.yml/dispatches -f ref=main -f 'inputs[bots] |
| kpc-camp-weekly.yml | 22 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job slice | Today's slice -> the workshop (campinfo only) |
| kpc-campsites.yml | 52 | LOUD | warning: download | gh release download boundary-cache -R KentuckyPortableClub/KPC-Links -p 'US-*.json.gz' -D kpcdata/cache/us --clobber \|\|  |
| kpc-campsites.yml | 58 | KEPT | a pipeline (its exit status is the last command; follow-up: pipefail) | cd kpcdata && git fetch -q origin tools-out && mkdir -p ../camplayers && git archive FETCH_HEAD camp_layers \| tar -x -C  |
| kpc-campsites.yml | 71 | KEPT | a pipeline (its exit status is the last command; follow-up: pipefail) | python3 .github/scripts/kpc_campsites_bot.py \| tee /tmp/campsites.log \|\| true |
| kpc-campsites.yml | 74 | KEPT | not a failure signal | bash ../links/.github/scripts/kpc_push_data.sh . "camp and activate bot: ${{ inputs.areas \|\| 'queue' }} (gate ${GATE:-no |
| kpc-campsites.yml | 81 | LOUD | error: start the next run | gh workflow run kpc-campsites.yml -R ${{ github.repository }} -f areas= -f chunks=${{ inputs.chunks }} -f chain=$C -f te |
| kpc-campsites.yml | 48 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job campsites | Saved official outlines for the other states (boundary cache release) |
| kpc-campsites.yml | 56 | KEPT-GREEN | step gets id kept_green_2; reported at the end of job campsites | Official campground layers (kpc_camp_layers output, branch tools-out) |
| kpc-campsites.yml | 61 | KEPT-GREEN | step gets id kept_green_3; reported at the end of job campsites | Run the bot area by area and save once per chunk |
| kpc-campsites.yml | 77 | KEPT-GREEN | step gets id kept_green_4; reported at the end of job campsites | Areas remain, so the next job starts itself |
| kpc-cell.yml | 46 | LOUD | warning: install | pip install -q requests h3 \|\| true |
| kpc-cell.yml | 47 | LOUD | error: kpc_cell_bot.py | python3 .github/scripts/kpc_cell_bot.py --states KY \|\| true |
| kpc-cell.yml | 48 | LOUD | error: kpc_waiting_room.py | LINKS=../links python3 .github/scripts/kpc_waiting_room.py divert data/cell \|\| true |
| kpc-cell.yml | 49 | KEPT | a status-board line (reporting only) | python3 .github/scripts/kpc_status.py board 'Cell coverage (FCC)' green "read $(date -u +%F): Kentucky + test parks, hel |
| kpc-cell.yml | 50 | KEPT | not a failure signal | bash ../links/.github/scripts/kpc_push_data.sh . "cell coverage (FCC; held in the waiting room)" data/cell data/waiting  |
| kpc-cell.yml | 51 | KEPT | not a failure signal | (cd ../out && git add -A cell 2>/dev/null && git commit -qm "cell work log (run ${{ github.run_id }})" && { for i in 1 2 |
| kpc-cell.yml | 35 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job run | Read the FCC files (held) |
| kpc-closures.yml | 72 | LOUD | warning: install | pip install -q --break-system-packages pypdf \|\| pip install -q pypdf \|\| true |
| kpc-closures.yml | 73 | LOUD | warning: install | if [ "${{ inputs.browser \|\| 'yes' }}" = yes ]; then pip install -q --break-system-packages playwright \|\| pip install -q  |
| kpc-closures.yml | 73 | LOUD | warning: install | if [ "${{ inputs.browser \|\| 'yes' }}" = yes ]; then pip install -q --break-system-packages playwright \|\| pip install -q  |
| kpc-closures.yml | 85 | KEPT | a pipeline (its exit status is the last command; follow-up: pipefail) | python3 .github/scripts/kpc_closures_bot.py --selftest \| tail -1 \|\| true |
| kpc-closures.yml | 89 | KEPT | a pipeline (its exit status is the last command; follow-up: pipefail) | python3 .github/scripts/kpc_closures_bot.py \| tee /tmp/closures.log \|\| true |
| kpc-closures.yml | 93 | LOUD | error: kpc_push_data.sh | bash ../links/.github/scripts/kpc_push_data.sh . "closures super-bot: chunk $i" data/closures data/status \|\| true |
| kpc-closures.yml | 103 | KEPT | not a failure signal | gh workflow run kpc-closures.yml -R ${{ github.repository }} -f areas="${{ inputs.areas }}" -f chunks=5 -f minutes="${{  |
| kpc-closures.yml | 56 | KEPT-GREEN | step id gate; reported at the end of job closures | Scheduled runs only once proven |
| kpc-closures.yml | 70 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job closures | Tools |
| kpc-closures.yml | 76 | KEPT-GREEN | step gets id kept_green_2; reported at the end of job closures | Read the sources chunk by chunk, one save per chunk |
| kpc-closures.yml | 99 | KEPT-GREEN | step gets id kept_green_3; reported at the end of job closures | Areas remain, so the next job starts itself |
| kpc-collector.yml | 51 | LOUD | error: kpc_intake_reader.py | cd kpcdata && (python3 .github/scripts/kpc_intake_reader.py portals \|\| true) && python3 .github/scripts/kpc_gis_finders. |
| kpc-collector.yml | 51 | LOUD | error: kpc_gis_finders.py | cd kpcdata && (python3 .github/scripts/kpc_intake_reader.py portals \|\| true) && python3 .github/scripts/kpc_gis_finders. |
| kpc-collector.yml | 52 | LOUD | error: kpc_push_data.sh | bash ../links/.github/scripts/kpc_push_data.sh . "GIS finders: map-viewer + portal layers (leads)" data/intake/found-lay |
| kpc-collector.yml | 71 | LOUD | error: kpc_intake_reader.py | python3 .github/scripts/kpc_intake_reader.py layers \|\| true   # pulls its own files from branch intake-files |
| kpc-collector.yml | 72 | LOUD | error: kpc_intake_reader.py | python3 .github/scripts/kpc_intake_reader.py files \|\| true    # Nov 1: hand-downloaded boundary files (file-<AREA>-*.geo |
| kpc-collector.yml | 73 | LOUD | error: kpc_layer_collector.py | timeout 100m python3 .github/scripts/kpc_layer_collector.py \|\| true |
| kpc-collector.yml | 74 | LOUD | error: kpc_q_gate.py | python3 .github/scripts/kpc_q_gate.py gate \|\| true   # Nov 2 (Brandon GO): no-shared-name / one-record-many-parks / worl |
| kpc-collector.yml | 76 | LOUD | error: kpc_week_numbers.py | python3 .github/scripts/kpc_week_numbers.py \|\| true   # the control panel's numbers, fresh after each collector run |
| kpc-collector.yml | 77 | KEPT | a status-board line (reporting only) | python3 .github/scripts/kpc_status.py board "Layer collector" green "LAYER lines + crawler layers pin-tested" "chat 11 a |
| kpc-collector.yml | 78 | LOUD | error: kpc_push_data.sh | bash ../links/.github/scripts/kpc_push_data.sh . "layer collector: LAYER lines + crawler layers (questions for chat 11)" |
| kpc-collector.yml | 86 | LOUD | error: start the next run | if [ "$LEFT" != 0 ]; then gh workflow run kpc-collector.yml -R ${{ github.repository }} --ref main \|\| true; fi |
| kpc-collector.yml | 39 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job collect | The map-format converter's answers (branch tools-out, convert/; HQ Oct 31 5:45 PM) |
| kpc-collector.yml | 46 | KEPT-GREEN | step gets id kept_green_2; reported at the end of job collect | The two GIS finders (map viewers we keep, open-data portals we know; Brandon Oct 30 10:44 AM) |
| kpc-collector.yml | 55 | KEPT-GREEN | step id fp; reported at the end of job collect | New work? (fingerprint of the Fable + atlas files + the layer files on branch intake-files) |
| kpc-collector.yml | 66 | KEPT-GREEN | step gets id kept_green_3; reported at the end of job collect | Collect + pin-test |
| kpc-collector.yml | 80 | KEPT-GREEN | step gets id kept_green_4; reported at the end of job collect | Straight through (Brandon Oct 30 7:43 PM) - outside-research pairs left = start the next run now |
| kpc-convert-layers.yml | 52 | KEPT | optional git step; the next step reports | git fetch -q origin tools-out:tools-out && git worktree add -q ../out tools-out \|\| true |
| kpc-convert-layers.yml | 59 | LOUD | warning: install | pip install -q -r .github/scripts/tools/kpc_convert_layers/requirements.txt \|\| true |
| kpc-convert-layers.yml | 60 | LOUD | error: kpc_intake_reader.py | python3 .github/scripts/kpc_intake_reader.py convert \|\| true   # pulls its own files from branch intake-files |
| kpc-convert-layers.yml | 61 | LOUD | error: kpc_tools_run.py | python3 .github/scripts/kpc_tools_run.py prep-convert no /tmp/leads.json \|\| true |
| kpc-convert-layers.yml | 62 | KEPT | a pipeline (its exit status is the last command; follow-up: pipefail) | python3 .github/scripts/tools/kpc_convert_layers/kpc_convert_layers.py --leads /tmp/leads.json --out ../out/convert --ca |
| kpc-convert-layers.yml | 66 | KEPT | nothing to do is fine | [ "$R" -lt "$N" ] && echo "more=yes" >> $GITHUB_OUTPUT \|\| true |
| kpc-convert-layers.yml | 67 | LOUD | error: git push | cd ../out && git add -A convert && git commit -qm "map-format converter (run ${{ github.run_id }})" && git push -q origi |
| kpc-convert-layers.yml | 73 | LOUD | error: start the next run | run: gh workflow run kpc-convert-layers.yml -R ${{ github.repository }} --ref main \|\| true |
| kpc-convert-layers.yml | 26 | KEPT-GREEN | step id gap; reported at the end of job run | Wait for HQ's stop-gap run to finish (same files) |
| kpc-convert-layers.yml | 48 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job run | The side branch for the converter's files (tools-out, never main) |
| kpc-convert-layers.yml | 56 | KEPT-GREEN | step id c; reported at the end of job run | Convert (resumes) |
| kpc-convert-layers.yml | 70 | KEPT-GREEN | step gets id kept_green_2; reported at the end of job run | Next run while leads are left |
| kpc-copy-from-links.yml | 100 | KEPT | a pipeline (its exit status is the last command; follow-up: pipefail) | echo "$KD" \| grep '^::' \|\| true |
| kpc-copy-from-links.yml | 104 | LOUD | error: inline Python | for k in $KDIRS; do python3 - "$k" "${{ needs.gate.outputs.fp }}" <<'PY' \|\| true |
| kpc-copy-from-links.yml | 116 | LOUD | error: kpc_waiting_room.py | (cd kpcdata && LINKS=../links python3 .github/scripts/kpc_waiting_room.py divert $KDIRS data/campstate) \|\| true |
| kpc-copy-from-links.yml | 118 | LOUD | error: kpc_key_summary.py | (cd kpcdata && LINKS=../links python3 .github/scripts/kpc_key_summary.py) \|\| true |
| kpc-copy-from-links.yml | 120 | LOUD | error: kpc_split_locations.py | [ -f links/locations.json ] && python3 kpcdata/.github/scripts/kpc_split_locations.py links/locations.json kpcdata \|\| tr |
| kpc-copy-from-links.yml | 126 | LOUD | error: kpc_hunter_trigger.py | (cd kpcdata && LINKS=../links python3 .github/scripts/kpc_hunter_trigger.py > /tmp/hunt.txt) \|\| true; cat /tmp/hunt.txt  |
| kpc-copy-from-links.yml | 126 | KEPT | nothing to do is fine | (cd kpcdata && LINKS=../links python3 .github/scripts/kpc_hunter_trigger.py > /tmp/hunt.txt) \|\| true; cat /tmp/hunt.txt  |
| kpc-copy-from-links.yml | 139 | LOUD | error: kpc_lookup.py | PIC_ROOT=. LINKS=../links python3 ../kpcdata/.github/scripts/kpc_lookup.py map-cleanup \|\| true |
| kpc-copy-from-links.yml | 156 | LOUD | error: kpc_new_park_flow.py | (cd kpcdata && LINKS=../links LOOKUP_ROOT=../lk python3 .github/scripts/kpc_new_park_flow.py > /tmp/newp.txt) \|\| true; c |
| kpc-copy-from-links.yml | 156 | KEPT | nothing to do is fine | (cd kpcdata && LINKS=../links LOOKUP_ROOT=../lk python3 .github/scripts/kpc_new_park_flow.py > /tmp/newp.txt) \|\| true; c |
| kpc-copy-from-links.yml | 157 | LOUD | error: kpc_push_data.sh | bash links/.github/scripts/kpc_push_data.sh kpcdata "new-park pipeline: handled list" data/gis-hunter/new-parks.json \|\|  |
| kpc-copy-from-links.yml | 158 | KEPT | not a failure signal | (cd lk && git config user.name 'github-actions[bot]' && git config user.email '41898282+github-actions[bot]@users.norepl |
| kpc-copy-from-links.yml | 161 | LOUD | error: start the next run | gh api -X POST repos/${{ github.repository }}/actions/workflows/kpc-gis-hunter.yml/dispatches -f ref=main -f "inputs[are |
| kpc-copy-from-links.yml | 170 | KEPT | not a failure signal | gh api -X POST repos/${{ github.repository }}/actions/workflows/kpc-gis-hunter.yml/dispatches -f ref=main -f "inputs[cou |
| kpc-copy-from-links.yml | 65 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job copy | Copy (folders mirrored, single files copied) |
| kpc-copy-from-links.yml | 123 | KEPT-GREEN | step gets id kept_green_2; reported at the end of job copy | Save (once) |
| kpc-copy-from-links.yml | 130 | KEPT-GREEN | step gets id kept_green_3; reported at the end of job copy | The picture-map branch (daily cleanup) |
| kpc-copy-from-links.yml | 136 | KEPT-GREEN | step gets id kept_green_4; reported at the end of job copy | A park with an OFFICIAL outline now loses its picture map (HQ Oct 30 8:45 AM (2); house rule Oct 29 11:10 PM) |
| kpc-copy-from-links.yml | 146 | KEPT-GREEN | step gets id kept_green_5; reported at the end of job copy | The look-up branch (the new-park pipeline files a page read there) |
| kpc-copy-from-links.yml | 152 | KEPT-GREEN | step gets id kept_green_6; reported at the end of job copy | New parks with no outline -> one hunter areas-run + one look-up read (HQ Oct 30 7:40 AM (b); never posts) |
| kpc-copy-from-links.yml | 164 | KEPT-GREEN | step gets id kept_green_7; reported at the end of job copy | The map key or the layer list changed, so the GIS hunter starts one full pass (Brandon Oct 29 11:50 PM) |
| kpc-detective.yml | 88 | KEPT | a pipeline (its exit status is the last command; follow-up: pipefail) | python3 .github/scripts/kpc_detective_bot.py \| tee /tmp/detective.log \|\| true |
| kpc-detective.yml | 91 | LOUD | error: kpc_push_data.sh | bash ../links/.github/scripts/kpc_push_data.sh . "park detective: chunk $i" data/detective data/intake data/status \|\| tr |
| kpc-detective.yml | 100 | LOUD | error: kpc_dig_bridge.py | python3 .github/scripts/kpc_dig_bridge.py out ../lk \|\| true |
| kpc-detective.yml | 101 | KEPT | not a failure signal | (cd ../lk && git config user.name 'github-actions[bot]' && git config user.email '41898282+github-actions[bot]@users.nor |
| kpc-detective.yml | 102 | KEPT | not a failure signal | python3 .github/scripts/kpc_status.py board 'park detective' green "answers in data/detective/answers.md, outline leads  |
| kpc-detective.yml | 103 | LOUD | error: kpc_push_data.sh | bash ../links/.github/scripts/kpc_push_data.sh . "park detective: status" data/detective data/intake data/status \|\| true |
| kpc-detective.yml | 110 | KEPT | not a failure signal | gh workflow run kpc-detective.yml -R ${{ github.repository }} -f areas= -f chunks=5 -f chain=$C -f jobs="${{ inputs.jobs |
| kpc-detective.yml | 52 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job detective | The look-up branch (dig questions in, answers out) |
| kpc-detective.yml | 59 | KEPT-GREEN | step id gate; reported at the end of job detective | Daily runs only when a dig question waits |
| kpc-detective.yml | 76 | KEPT-GREEN | step gets id kept_green_2; reported at the end of job detective | Work in chunks, one save per chunk |
| kpc-detective.yml | 106 | KEPT-GREEN | step gets id kept_green_3; reported at the end of job detective | Areas remain, so the next job starts itself |
| kpc-discovery.yml | 41 | KEPT | nothing to do is fine | mkdir -p data/discovery && cp -r kpcdata/data/discovery/. data/discovery/ 2>/dev/null \|\| true |
| kpc-discovery.yml | 42 | LOUD | warning: install | case "${{ env.I_STEPS }}" in *C*) pip install -q playwright && python3 -m playwright install --with-deps chromium >/dev/ |
| kpc-discovery.yml | 54 | LOUD | error: kpc_discovery.py | STATES="$S" python3 .github/scripts/kpc_discovery.py \|\| true |
| kpc-discovery.yml | 64 | KEPT | an optional path may not exist | git add data 2>/dev/null \|\| true |
| kpc-discovery.yml | 39 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job discover | Tools + the last lead list |
| kpc-discovery.yml | 44 | KEPT-GREEN | step gets id kept_green_2; reported at the end of job discover | Discover |
| kpc-discovery.yml | 57 | KEPT-GREEN | step gets id kept_green_3; reported at the end of job discover | Save (once) |
| kpc-docs-merge.yml | 38 | LOUD | warning: install | pip install -q --break-system-packages pypdf openpyxl \|\| pip install -q pypdf openpyxl \|\| true |
| kpc-docs-merge.yml | 39 | LOUD | error: kpc_intake_reader.py | python3 .github/scripts/kpc_intake_reader.py docs \|\| true   # HQ Oct 31 7:55 PM: the bot pulls its own files from branch |
| kpc-docs-merge.yml | 41 | LOUD | error: kpc_waiting_room.py | LINKS=../links python3 .github/scripts/kpc_waiting_room.py resume data/docs \|\| true |
| kpc-docs-merge.yml | 42 | KEPT | a pipeline (its exit status is the last command; follow-up: pipefail) | python3 .github/scripts/kpc_docs_merge.py \| tee /tmp/merge.txt \|\| true |
| kpc-docs-merge.yml | 43 | LOUD | error: kpc_waiting_room.py | LINKS=../links python3 .github/scripts/kpc_waiting_room.py divert data/docs \|\| true |
| kpc-docs-merge.yml | 46 | LOUD | error: kpc_push_data.sh | bash ../links/.github/scripts/kpc_push_data.sh . "outside documents merged (held in the waiting room)" data/docs data/in |
| kpc-docs-merge.yml | 54 | LOUD | error: start the next run | if [ -n "$L" ] && [ "$L" != 0 ]; then gh workflow run kpc-docs-merge.yml -R ${{ github.repository }} --ref main \|\| true; |
| kpc-docs-merge.yml | 31 | KEPT-GREEN | step id m; reported at the end of job merge | Merge (held in the waiting room) |
| kpc-docs-merge.yml | 49 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job merge | Straight through |
| kpc-docs.yml | 51 | LOUD | warning: install | pip install -q --break-system-packages pypdf \|\| pip install -q pypdf \|\| true |
| kpc-docs.yml | 52 | LOUD | warning: install | if [ "${{ inputs.browser }}" = yes ]; then pip install -q --break-system-packages playwright \|\| pip install -q playwrigh |
| kpc-docs.yml | 52 | LOUD | warning: install | if [ "${{ inputs.browser }}" = yes ]; then pip install -q --break-system-packages playwright \|\| pip install -q playwrigh |
| kpc-docs.yml | 63 | LOUD | error: kpc_waiting_room.py | LINKS=../links python3 .github/scripts/kpc_waiting_room.py resume data/docs \|\| true   # Brandon Oct 29 7:55 PM: work fro |
| kpc-docs.yml | 64 | LOUD | error: kpc_docs_bot.py | MINUTES=55 python3 .github/scripts/kpc_docs_bot.py \|\| true |
| kpc-docs.yml | 65 | LOUD | error: kpc_waiting_room.py | LINKS=../links python3 .github/scripts/kpc_waiting_room.py divert data/docs \|\| true   # changed area files wait in data/ |
| kpc-docs.yml | 66 | KEPT | not a failure signal | python3 .github/scripts/kpc_status.py grade-me "official documents bot" "$(python3 -c "import json;s=json.load(open('dat |
| kpc-docs.yml | 67 | KEPT | a status-board line (reporting only) | python3 .github/scripts/kpc_status.py board "official documents bot" green "chunk $i saved" "chat 8 grades review.md sam |
| kpc-docs.yml | 68 | LOUD | error: kpc_push_data.sh | bash ../links/.github/scripts/kpc_push_data.sh . "documents bot: chunk $i (held in the waiting room)" data/docs data/sta |
| kpc-docs.yml | 49 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job docs | Tools |
| kpc-docs.yml | 54 | KEPT-GREEN | step gets id kept_green_2; reported at the end of job docs | Read, in chunks, one save per chunk |
| kpc-docs.yml | 82 | KEPT-GREEN | step gets id kept_green_3; reported at the end of job docs | A passed test starts the queue |
| kpc-docs.yml | 101 | KEPT-GREEN | step gets id kept_green_4; reported at the end of job docs | Carry on in a new job when areas remain |
| kpc-engine-discover.yml | 72 | KEPT | not a failure signal | for i in 1 2 3; do git push -q origin HEAD:engine-registry && break; git pull -q --rebase origin engine-registry; sleep  |
| kpc-engine-discover.yml | 75 | KEPT | not a failure signal | python3 .github/scripts/kpc_status.py board 'Engine crawler' green "$done_n areas, $new_n layers $(date -u +%F)" 'the pa |
| kpc-engine-discover.yml | 76 | KEPT | not a failure signal | (for i in 1 2 3; do git add data/status && git commit -qm "board: engine crawler" && git pull -q --rebase --autostash or |
| kpc-engine-discover.yml | 39 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job crawl | Crawl |
| kpc-engine.yml | 67 | LOUD | error: kpc_intake_reader.py | for k in hardlook camping parking docs portals acres layers; do python3 .github/scripts/kpc_intake_reader.py $k >/dev/nu |
| kpc-engine.yml | 68 | LOUD | error: kpc_gps_prep.py | python3 .github/scripts/kpc_gps_prep.py ../links ../prep >/dev/null 2>&1 \|\| true   # Kentucky in the club shapes (pins,  |
| kpc-engine.yml | 75 | LOUD | error: inline Python | python3 - <<'PY' \|\| true |
| kpc-engine.yml | 86 | KEPT | a pipeline (its exit status is the last command; follow-up: pipefail) | git fetch -q origin +refs/heads/engine-registry:refs/remotes/origin/engine-registry && git archive origin/engine-registr |
| kpc-engine.yml | 87 | LOUD | error: kpc_engine_extra.py | python3 .github/scripts/kpc_engine_extra.py $D data/intake/queue.json \|\| true   # Brandon Nov 1 1:20 PM: the finders fee |
| kpc-engine.yml | 115 | KEPT | not a failure signal | python3 $P export --out ../out/engine --name engine > /dev/null 2>&1 \|\| true |
| kpc-engine.yml | 119 | LOUD | error: git push | (cd ../ib && git add -A && git commit -qm "engine finds (run ${{ github.run_id }}): handback for the readers -> waiting  |
| kpc-engine.yml | 123 | KEPT | a status-board line (reporting only) | python3 .github/scripts/kpc_status.py board 'Park-info engine' green "exit $E $(date -u +%F) ($A)" 'chat 11 grades tools |
| kpc-engine.yml | 125 | KEPT | nothing to do is fine | bash ../links/.github/scripts/kpc_push_data.sh . "board: engine" data/status data/engine && echo '::notice title=Engine  |
| kpc-engine.yml | 126 | KEPT | not a failure signal | cd ../out && find engine -size +40M -delete; echo "::notice title=Engine out::$(du -sh engine \| cut -f1), $(find engine  |
| kpc-engine.yml | 133 | LOUD | error: start the next run | run: gh workflow run kpc-engine.yml -R ${{ github.repository }} -f areas="${{ inputs.areas }}" \|\| true |
| kpc-engine.yml | 57 | KEPT-GREEN | step id r; reported at the end of job run | Run |
| kpc-engine.yml | 130 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job run | Next run |
| kpc-eu-alerts.yml | 32 | KEPT | nothing to do is fine | rsync -a kpcdata/data/ data/ 2>/dev/null \|\| true |
| kpc-eu-alerts.yml | 33 | KEPT | nothing to do is fine | cp kpcdata/locations.json kpcdata/locations-ky.json . 2>/dev/null \|\| true |
| kpc-eu-alerts.yml | 36 | LOUD | error: kpc_eu_alerts.py | run: python3 .github/scripts/kpc_eu_alerts.py \|\| true |
| kpc-eu-alerts.yml | 45 | LOUD | error: kpc_save_filter.py | python3 ../.github/scripts/kpc_save_filter.py data/alerts/eu.json \|\| true |
| kpc-eu-alerts.yml | 35 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job copy | Copy the warnings |
| kpc-eu-alerts.yml | 38 | KEPT-GREEN | step gets id kept_green_2; reported at the end of job copy | Save (once, only real changes) |
| kpc-fers-check.yml | 57 | LOUD | warning: install | pip install -q -r .github/scripts/tools/kpc_fers_check/requirements.txt \|\| true |
| kpc-fers-check.yml | 60 | KEPT | a pipeline (its exit status is the last command; follow-up: pipefail) | python3 .github/scripts/tools/kpc_fers_check/kpc_fers_check.py --areas $A $R --fers-dir data/fers --key-dir data --out d |
| kpc-fers-check.yml | 61 | KEPT | nothing to do is fine | grep -q 'rerun with --resume' /tmp/fers.log && echo "more=yes" >> $GITHUB_OUTPUT \|\| true |
| kpc-fers-check.yml | 62 | KEPT | nothing to do is fine | rm -rf data/fers-check/.cache \|\| true |
| kpc-fers-check.yml | 63 | KEPT | a pipeline (its exit status is the last command; follow-up: pipefail) | python3 .github/scripts/kpc_tools_run.py fers-alerts \| tee /tmp/al.txt \|\| true |
| kpc-fers-check.yml | 65 | KEPT | a status-board line (reporting only) | if [ "$N" != 0 ]; then python3 .github/scripts/kpc_status.py board "2-fer checker" amber "weekly re-test of live 2-fers" |
| kpc-fers-check.yml | 66 | KEPT | a status-board line (reporting only) | else python3 .github/scripts/kpc_status.py board "2-fer checker" green "weekly re-test of live 2-fers" "nothing shrank,  |
| kpc-fers-check.yml | 67 | LOUD | error: kpc_push_data.sh | bash ../links/.github/scripts/kpc_push_data.sh . "2-fer checker: weekly report (nothing changed in data/fers)" data/fers |
| kpc-fers-check.yml | 73 | LOUD | error: start the next run | run: gh workflow run kpc-fers-check.yml -R ${{ github.repository }} --ref main -f areas="${{ inputs.areas }}" \|\| true |
| kpc-fers-check.yml | 27 | KEPT-GREEN | step id gap; reported at the end of job run | Wait for HQ's stop-gap run to finish (same files) |
| kpc-fers-check.yml | 51 | KEPT-GREEN | step id c; reported at the end of job run | Check (resumes where the last run stopped) |
| kpc-fers-check.yml | 70 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job run | Next run while areas are left |
| kpc-fers-line.yml | 93 | LOUD | warning: install | pip install -q numpy opencv-python-headless \|\| true |
| kpc-fers-line.yml | 96 | LOUD | error: kpc_waiting_room.py | (cd kpcdata && LINKS=.. python3 .github/scripts/kpc_waiting_room.py resume data/fers) \|\| true   # Oct 29 (chat 2 + Brand |
| kpc-fers-line.yml | 100 | LOUD | warning: download | gh release download boundary-cache -R KentuckyPortableClub/KPC-Links -p 'US-*.json.gz' -D cache/us --clobber \|\| true |
| kpc-fers-line.yml | 101 | LOUD | warning: download | gh release download boundary-cache -R KentuckyPortableClub/KPC-Links -p 'CA-ALL.json.gz' -D cache/ca --clobber \|\| true |
| kpc-fers-line.yml | 103 | KEPT | nothing to do is fine | if gh release download fers-bundles -R "$REPO" -p "$BUNDLE" -D . --clobber 2>/dev/null; then tar xzf "$BUNDLE" bundle/ht |
| kpc-fers-line.yml | 105 | KEPT | nothing to do is fine | tar xzf "$BUNDLE" --wildcards 'data/fers/reuse-p*' 2>/dev/null \|\| true |
| kpc-fers-line.yml | 107 | KEPT | nothing to do is fine | find bundle/http -type f -mtime +60 -delete 2>/dev/null \|\| true   # B1 (Oct 30): 60 days (an older answer is re-read; th |
| kpc-fers-line.yml | 109 | KEPT | a pipeline (its exit status is the last command; follow-up: pipefail) | find bundle/http -type f -printf '%T@ %s %p\n' 2>/dev/null \| sort -n \| awk -v cap=$((300*1024*1024)) '{t+=$2; a[NR]=$3;  |
| kpc-fers-line.yml | 112 | KEPT | nothing to do is fine | if gh release download fers-bundles -R "$REPO" -p "$WATER_ASSET" -D . --clobber 2>/dev/null; then tar xzf "$WATER_ASSET" |
| kpc-fers-line.yml | 120 | LOUD | error: kpc_pota_pairs.py | run: python3 .github/scripts/kpc_pota_pairs.py \|\| true |
| kpc-fers-line.yml | 125 | LOUD | error: kpc_water_bulk.py | STATES="$STATES" WATER_STORE=bundle/water DATA=data/fers python3 .github/scripts/kpc_water_bulk.py \|\| true |
| kpc-fers-line.yml | 126 | LOUD | warning: install | pip install -q pyshp 2>/dev/null \|\| true; STATES="$STATES" WATER_STORE=bundle/water DATA=data/fers python3 .github/scrip |
| kpc-fers-line.yml | 126 | LOUD | error: kpc_water_ca.py | pip install -q pyshp 2>/dev/null \|\| true; STATES="$STATES" WATER_STORE=bundle/water DATA=data/fers python3 .github/scrip |
| kpc-fers-line.yml | 134 | LOUD | error: kpc_fers.py | PASS=1 MINUTES=$(( M / 3 )) python3 .github/scripts/kpc_fers.py \|\| true |
| kpc-fers-line.yml | 135 | LOUD | error: kpc_fers.py | PASS=2 MINUTES=$(( M * 2 / 3 )) python3 .github/scripts/kpc_fers.py \|\| true |
| kpc-fers-line.yml | 140 | LOUD | error: kpc_water_bulk.py | STATES="$STATES" WATER_STORE=bundle/water DATA=data/fers python3 .github/scripts/kpc_water_bulk.py \|\| true |
| kpc-fers-line.yml | 141 | LOUD | warning: install | pip install -q pyshp 2>/dev/null \|\| true; STATES="$STATES" WATER_STORE=bundle/water DATA=data/fers python3 .github/scrip |
| kpc-fers-line.yml | 141 | LOUD | error: kpc_water_ca.py | pip install -q pyshp 2>/dev/null \|\| true; STATES="$STATES" WATER_STORE=bundle/water DATA=data/fers python3 .github/scrip |
| kpc-fers-line.yml | 182 | LOUD | warning: install | pip install -q numpy opencv-python-headless \|\| true |
| kpc-fers-line.yml | 184 | LOUD | warning: download | gh release download boundary-cache -R KentuckyPortableClub/KPC-Links -p 'US-*.json.gz' -D cache/us --clobber \|\| true |
| kpc-fers-line.yml | 185 | LOUD | warning: download | gh release download boundary-cache -R KentuckyPortableClub/KPC-Links -p 'CA-ALL.json.gz' -D cache/ca --clobber \|\| true |
| kpc-fers-line.yml | 201 | LOUD | error: kpc_water_bulk.py | STATES="$STATES" WATER_STORE=bundle/water DATA=data/fers python3 .github/scripts/kpc_water_bulk.py \|\| true |
| kpc-fers-line.yml | 202 | LOUD | warning: install | pip install -q pyshp 2>/dev/null \|\| true; STATES="$STATES" WATER_STORE=bundle/water DATA=data/fers python3 .github/scrip |
| kpc-fers-line.yml | 202 | LOUD | error: kpc_water_ca.py | pip install -q pyshp 2>/dev/null \|\| true; STATES="$STATES" WATER_STORE=bundle/water DATA=data/fers python3 .github/scrip |
| kpc-fers-line.yml | 213 | LOUD | error: kpc_fers.py | echo "::notice title=2-fer line::rows still waiting for pass 2: finishing pass 2 in the worker"; PASS=2 MINUTES=$(( M /  |
| kpc-fers-line.yml | 215 | LOUD | error: kpc_fers.py | PASS=3 MINUTES=$(( M * 4 / 5 )) python3 .github/scripts/kpc_fers.py \|\| true |
| kpc-fers-line.yml | 216 | LOUD | error: kpc_fers.py | PASS=5 MINUTES=$(( M / 3 )) python3 .github/scripts/kpc_fers.py \|\| true |
| kpc-fers-line.yml | 219 | LOUD | error: kpc_water_bulk.py | run: REPORT=1 STATES="$STATES" WATER_STORE=bundle/water DATA=data/fers python3 .github/scripts/kpc_water_bulk.py \|\| true |
| kpc-fers-line.yml | 224 | KEPT | nothing to do is fine | find bundle/http -type f -mtime +60 -delete 2>/dev/null \|\| true   # B1 (Oct 30): 60 days (an older answer is re-read; th |
| kpc-fers-line.yml | 226 | KEPT | a pipeline (its exit status is the last command; follow-up: pipefail) | find bundle/http -type f -printf '%T@ %s %p\n' 2>/dev/null \| sort -n \| awk -v cap=$((300*1024*1024)) '{t+=$2; a[NR]=$3;  |
| kpc-fers-line.yml | 260 | KEPT | nothing to do is fine | if [ "$RUN_TAG" = ky ]; then [ -f data/fers/known-answers.json ] \|\| cp kpcdata/data/fers/known-answers.json data/fers/ 2 |
| kpc-fers-line.yml | 261 | KEPT | nothing to do is fine | else cp -f kpcdata/data/fers/known-answers.json data/fers/ 2>/dev/null \|\| true; fi |
| kpc-fers-line.yml | 268 | KEPT | nothing to do is fine | cp -f kpcdata/data/us-key/$st.json data/us-key/ 2>/dev/null \|\| true |
| kpc-fers-line.yml | 269 | LOUD | warning: download | gh release download boundary-cache -R KentuckyPortableClub/KPC-Links -p "$st.json.gz" -D cache/us --clobber \|\| true |
| kpc-fers-line.yml | 275 | LOUD | error: kpc_fers_known.py | if [ "$REGION" = ky ]; then python3 .github/scripts/kpc_fers_known.py \|\| true; AREA=ky python3 .github/scripts/kpc_fers_ |
| kpc-fers-line.yml | 275 | LOUD | error: kpc_fers_expected.py | if [ "$REGION" = ky ]; then python3 .github/scripts/kpc_fers_known.py \|\| true; AREA=ky python3 .github/scripts/kpc_fers_ |
| kpc-fers-line.yml | 276 | LOUD | error: kpc_fers_expected.py | else python3 .github/scripts/kpc_fers_expected.py \|\| true; fi |
| kpc-fers-line.yml | 277 | LOUD | error: kpc_fers_known.py | case " $STATES" in *" CA-"*) CANADA=1 python3 .github/scripts/kpc_fers_known.py \|\| true;; esac   # Canada's known answer |
| kpc-fers-line.yml | 278 | LOUD | error: kpc_fers_line_check.py | TAG=$RUN_TAG SINCE=$SINCE python3 .github/scripts/kpc_fers_line_check.py \|\| true |
| kpc-fers-line.yml | 280 | LOUD | error: kpc_fers_review.py | TAG=$RUN_TAG STATES="$STATES" DATA=data/fers OUT=data/fers python3 .github/scripts/kpc_fers_review.py \|\| true |
| kpc-fers-line.yml | 282 | LOUD | error: kpc_map_observations.py | OBS_RUN="2-fer line $RUN_TAG" OBS_FILE=kpcdata/data/observations/fers-line-$RUN_TAG.json OBS_DATA_DIR=kpcdata python3 .g |
| kpc-fers-line.yml | 294 | KEPT | not a failure signal | mkdir -p to/fers && cp "$f" to/fers/ && cd to && git add fers && git commit -qm "2-fer expected list ($RUN_TAG)" && for  |
| kpc-fers-line.yml | 299 | KEPT | optional git step; the next step reports | git -C kpcdata rm -q --cached --ignore-unmatch "data/fers/reuse-p1-$RUN_TAG.json" "data/fers/reuse-p2-$RUN_TAG.json" "da |
| kpc-fers-line.yml | 301 | KEPT | optional git step; the next step reports | git -C kpcdata rm -q --cached --ignore-unmatch "data/fers/expected-$RUN_TAG.json" "data/fers/expected-$RUN_TAG.json.gz"  |
| kpc-fers-line.yml | 309 | LOUD | error: inline Python | python3 - <<'PY' \|\| true |
| kpc-fers-line.yml | 330 | LOUD | error: kpc_waiting_room.py | (cd kpcdata && LINKS=.. python3 .github/scripts/kpc_waiting_room.py divert data/fers) \|\| true   # Oct 29 (chat 2 + Brand |
| kpc-fers-line.yml | 366 | LOUD | error: kpc_push_data.sh | bash .github/scripts/kpc_push_data.sh kpcdata "2-fer line ${{ inputs.tag }}: broke in the $STAGE" data \|\| true |
| kpc-fers-line.yml | 367 | LOUD | error: start the next run | if [ -s stop.flag ]; then echo "::error title=2-fer lines::two lines broke in a row ($RUN_TAG after an earlier one): eve |
| kpc-fers-line.yml | 91 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job fetcher | Tools + saved outlines + this area's last 2-fer files |
| kpc-fers-line.yml | 116 | KEPT-GREEN | step gets id kept_green_2; reported at the end of job fetcher | POTA same-day history |
| kpc-fers-line.yml | 122 | KEPT-GREEN | step gets id kept_green_3; reported at the end of job fetcher | USGS water from the bulk files BEFORE the line (tiles under last run's rows; Fable Oct 28 10:34 PM) |
| kpc-fers-line.yml | 128 | KEPT-GREEN | step gets id kept_green_4; reported at the end of job fetcher | Passes 1 + 2 |
| kpc-fers-line.yml | 137 | KEPT-GREEN | step gets id kept_green_5; reported at the end of job fetcher | USGS water from the BULK FILES up front (HU4 files on USGS's Amazon storage, never the live map; HQ Oct 28 6:57 PM) |
| kpc-fers-line.yml | 157 | KEPT-GREEN | step gets id kept_green_6; reported at the end of job fetcher | Start the next area (chained) |
| kpc-fers-line.yml | 198 | KEPT-GREEN | step gets id kept_green_7; reported at the end of job worker | USGS water from the bulk files (tiles under the spots with no saved copy; chat 8's first backup) |
| kpc-fers-line.yml | 204 | KEPT-GREEN | step gets id kept_green_8; reported at the end of job worker | Passes 3 + 5 |
| kpc-fers-line.yml | 218 | KEPT-GREEN | step gets id kept_green_9; reported at the end of job worker | Water report per state (tiles needed / saved / rows not checked; a 'not checked' row with every tile saved = the store w |
| kpc-fers-line.yml | 272 | KEPT-GREEN | step gets id kept_green_10; reported at the end of job checker | Check |
| kpc-fers-lines.yml | 129 | LOUD | error: kpc_fers_layered.py | NET=1 MINUTES=20 python3 links/.github/scripts/kpc_fers_layered.py data/fers data/parkinfo \|\| true |
| kpc-fers-lines.yml | 131 | LOUD | error: kpc_waiting_room.py | LINKS=links python3 .github/scripts/kpc_waiting_room.py divert data/fers \|\| true   # Oct 29: a changed US/CA 2-fer file  |
| kpc-fers-lines.yml | 132 | KEPT | nothing to commit is fine | git add data/fers data/waiting && git commit -qm "2-fer: far-spot check + layered-land list" \|\| true |
| kpc-fers-lines.yml | 133 | LOUD | warning: git fetch | git pull -q --rebase \|\| true; git push -q \|\| true |
| kpc-fers-lines.yml | 133 | LOUD | error: git push | git pull -q --rebase \|\| true; git push -q \|\| true |
| kpc-fers-lines.yml | 137 | LOUD | error: kpc_fers_review.py | COMBINE_ONLY=1 OUT=data/fers python3 links/.github/scripts/kpc_fers_review.py \|\| true |
| kpc-fers-lines.yml | 141 | KEPT | not a failure signal | mkdir -p ../to/fers && cp data/fers/review-all.json data/fers/review-all.md ../to/fers/ 2>/dev/null; cd ../to && git add |
| kpc-fers-lines.yml | 142 | KEPT | nothing to commit is fine | git rm -q --cached --ignore-unmatch data/fers/review-all.json data/fers/review-all.md && git commit -qm "2-fer review li |
| kpc-fers-lines.yml | 143 | LOUD | warning: git fetch | git pull -q --rebase \|\| true; git push -q \|\| true |
| kpc-fers-lines.yml | 143 | LOUD | error: git push | git pull -q --rebase \|\| true; git push -q \|\| true |
| kpc-fers-lines.yml | 125 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job again | Far-spot hold + parcel check + layered-land list (chat 2, Oct 29; Brandon 8:07 AM + chat 8) |
| kpc-fers-lines.yml | 135 | KEPT-GREEN | step gets id kept_green_2; reported at the end of job again | The one big 'needs a human look' list from every area's file |
| kpc-fers-pending.yml | 106 | LOUD | error: inline Python | python3 - <<'PY' \|\| true |
| kpc-fers-pending.yml | 138 | KEPT | nothing to commit is fine | git add data/fers/pending.json data/fers/key-seen.json data/fers/new-key-states.json && git commit -qm "2-fer small batc |
| kpc-fers-pending.yml | 139 | LOUD | warning: git fetch | git pull -q --rebase \|\| true; git push -q \|\| true |
| kpc-fers-pending.yml | 139 | LOUD | error: git push | git pull -q --rebase \|\| true; git push -q \|\| true |
| kpc-fers-regions.yml | 74 | LOUD | warning: install | pip install -q numpy opencv-python-headless \|\| true |
| kpc-fers-regions.yml | 78 | LOUD | warning: download | gh release download boundary-cache -R KentuckyPortableClub/KPC-Links -p 'US-*.json.gz' -D cache/us --clobber \|\| true |
| kpc-fers-regions.yml | 79 | LOUD | warning: download | gh release download boundary-cache -R KentuckyPortableClub/KPC-Links -p 'CA-ALL.json.gz' -D cache/ca --clobber \|\| true |
| kpc-fers-regions.yml | 86 | LOUD | error: kpc_pota_pairs.py | run: python3 .github/scripts/kpc_pota_pairs.py \|\| true |
| kpc-fers-regions.yml | 104 | LOUD | error: kpc_fers.py | PASS=$p MINUTES=$CAP python3 .github/scripts/kpc_fers.py \|\| true |
| kpc-fers-regions.yml | 106 | LOUD | error: kpc_fers.py | else python3 .github/scripts/kpc_fers.py \|\| true; fi |
| kpc-fers-regions.yml | 107 | LOUD | error: kpc_fers_expected.py | python3 .github/scripts/kpc_fers_expected.py \|\| true |
| kpc-fers-regions.yml | 142 | LOUD | error: kpc_map_observations.py | run: mkdir -p kpcdata/data/observations; python3 .github/scripts/kpc_map_observations.py \|\| true |
| kpc-fers-regions.yml | 31 | KEPT-GREEN | step id p; reported at the end of job plan |  |
| kpc-fers-regions.yml | 70 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job fers | Tools + saved outlines + the last 2-fer files |
| kpc-fers-regions.yml | 81 | KEPT-GREEN | step gets id kept_green_2; reported at the end of job fers | POTA activation history (pairs worked the same day, counts only) |
| kpc-fers-regions.yml | 88 | KEPT-GREEN | step gets id kept_green_3; reported at the end of job fers | Look for shared ground |
| kpc-fers-regions.yml | 110 | KEPT-GREEN | step gets id kept_green_4; reported at the end of job fers | Save (once, at the end) |
| kpc-fers-regions.yml | 137 | KEPT-GREEN | step gets id kept_green_5; reported at the end of job observations | Observations log (new possible overlaps) |
| kpc-fers-regions.yml | 144 | KEPT-GREEN | step gets id kept_green_6; reported at the end of job observations | Save |
| kpc-fers-water.yml | 70 | KEPT | nothing to do is fine | gh release download fers-bundles -R "$REPO" -p "$WATER_ASSET" -D . --clobber 2>/dev/null && tar xzf "$WATER_ASSET" bundl |
| kpc-fers-water.yml | 72 | LOUD | error: kpc_water_bulk.py | STATES="$STATES" WATER_STORE=bundle/water DATA=data/fers python3 links/.github/scripts/kpc_water_bulk.py \|\| true |
| kpc-fers-water.yml | 73 | LOUD | warning: install | pip install -q pyshp 2>/dev/null \|\| true; STATES="$STATES" WATER_STORE=bundle/water DATA=data/fers python3 links/.github |
| kpc-fers-water.yml | 73 | LOUD | error: kpc_water_ca.py | pip install -q pyshp 2>/dev/null \|\| true; STATES="$STATES" WATER_STORE=bundle/water DATA=data/fers python3 links/.github |
| kpc-fers-water.yml | 74 | LOUD | error: kpc_water_bulk.py | REPORT=1 STATES="$STATES" WATER_STORE=bundle/water DATA=data/fers python3 links/.github/scripts/kpc_water_bulk.py \|\| tru |
| kpc-fers-water.yml | 78 | LOUD | error: kpc_keep2.sh | bash .github/scripts/kpc_keep2.sh "$REPO" fers-bundles "$WATER_ASSET" \|\| true |
| kpc-fers-water.yml | 66 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job water | Fill the tiles ahead |
| kpc-fers.yml | 53 | LOUD | warning: install | pip install -q numpy opencv-python-headless \|\| true |
| kpc-fers.yml | 58 | LOUD | warning: download | gh release download boundary-cache -R KentuckyPortableClub/KPC-Links -p 'W-*.json.gz' -D cache/world --clobber \|\| true |
| kpc-fers.yml | 60 | LOUD | warning: download | gh release download boundary-cache -R KentuckyPortableClub/KPC-Links -p 'US-*.json.gz' -D cache/us --clobber \|\| true |
| kpc-fers.yml | 61 | LOUD | warning: download | gh release download boundary-cache -R KentuckyPortableClub/KPC-Links -p 'CA-ALL.json.gz' -D cache/ca --clobber \|\| true |
| kpc-fers.yml | 70 | LOUD | error: kpc_pota_pairs.py | run: python3 .github/scripts/kpc_pota_pairs.py \|\| true |
| kpc-fers.yml | 90 | LOUD | error: kpc_fers.py | PASS=$p MINUTES=$CAP python3 .github/scripts/kpc_fers.py \|\| true |
| kpc-fers.yml | 92 | LOUD | error: kpc_fers.py | else python3 .github/scripts/kpc_fers.py \|\| true; fi |
| kpc-fers.yml | 94 | LOUD | error: kpc_fers_known.py | if [ "$REGION" = ky ]; then python3 .github/scripts/kpc_fers_known.py \|\| true; fi |
| kpc-fers.yml | 96 | LOUD | error: kpc_fers_expected.py | if [ "$REGION" = ky ]; then AREA=ky python3 .github/scripts/kpc_fers_expected.py \|\| true |
| kpc-fers.yml | 97 | LOUD | error: kpc_fers_expected.py | elif [ -n "$STATES" ] && [ "$REGION" = na ]; then python3 .github/scripts/kpc_fers_expected.py \|\| true; fi |
| kpc-fers.yml | 105 | LOUD | error: kpc_map_observations.py | run: mkdir -p kpcdata/data/observations; python3 .github/scripts/kpc_map_observations.py \|\| true |
| kpc-fers.yml | 49 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job fers | Tools + saved outlines + the last 2-fer files |
| kpc-fers.yml | 65 | KEPT-GREEN | step gets id kept_green_2; reported at the end of job fers | POTA activation history (pairs worked the same day, counts only) |
| kpc-fers.yml | 72 | KEPT-GREEN | step gets id kept_green_3; reported at the end of job fers | Look for shared ground |
| kpc-fers.yml | 100 | KEPT-GREEN | step gets id kept_green_4; reported at the end of job fers | Observations log (new possible overlaps) |
| kpc-fers.yml | 108 | KEPT-GREEN | step gets id kept_green_5; reported at the end of job fers | Save (once, at the end) |
| kpc-fetch-files.yml | 44 | LOUD | error: kpc_fetch_files.py | python3 .github/scripts/kpc_fetch_files.py $L ../inf \|\| true |
| kpc-fetch-files.yml | 46 | KEPT | an optional path may not exist | git add -A file-*.geojson.gz 2>/dev/null \|\| true |
| kpc-fetch-files.yml | 48 | KEPT | nothing to commit is fine | git commit -qm "fetch files: boundary files by their link" \|\| true |
| kpc-fetch-files.yml | 49 | LOUD | warning: git fetch | for i in 1 2 3; do git push -q origin HEAD:intake-files && break; git pull -q --rebase origin intake-files \|\| true; slee |
| kpc-fetch-files.yml | 52 | LOUD | error: kpc_push_data.sh | bash ../links/.github/scripts/kpc_push_data.sh . "fetch files: seen list" data/intake/fetch-seen.json \|\| true |
| kpc-fetch-files.yml | 35 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job fetch | Fetch + convert |
| kpc-flow.yml | 27 | LOUD | error: kpc_flow.py | python3 .github/scripts/kpc_flow.py \|\| true |
| kpc-flow.yml | 28 | KEPT | not a failure signal | (for i in 1 2 3; do git add data/status/flow.json data/status/flow.md && git commit -qm "flow board" && git pull -q --re |
| kpc-flow.yml | 24 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job flow | Build the flow board |
| kpc-gapfill.yml | 31 | LOUD | error: start the next run | run: gh workflow run kpc-detective.yml -R ${{ github.repository }} -f areas="${{ inputs.areas }}" -f chunks="${{ inputs. |
| kpc-gapfill.yml | 30 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job handoff | Start the park detective with the same inputs |
| kpc-gis-hunter.yml | 74 | LOUD | error: kpc_keep_answers.py | python3 .github/scripts/kpc_keep_answers.py questions data/waiting/questions/gis-hunter.json \|\| true; python3 .github/sc |
| kpc-gis-hunter.yml | 74 | LOUD | error: kpc_keep_answers.py | python3 .github/scripts/kpc_keep_answers.py questions data/waiting/questions/gis-hunter.json \|\| true; python3 .github/sc |
| kpc-gis-hunter.yml | 75 | KEPT | a pipeline (its exit status is the last command; follow-up: pipefail) | MINUTES=55 python3 .github/scripts/kpc_gis_hunter.py \| tee /tmp/h.log \|\| true |
| kpc-gis-hunter.yml | 76 | KEPT | a status-board line (reporting only) | python3 .github/scripts/kpc_status.py board "GIS hunter" green "chunk $i: data/gis-hunter + questions" "chat 11 answers  |
| kpc-gis-hunter.yml | 77 | LOUD | error: kpc_keep_answers.py | python3 .github/scripts/kpc_keep_answers.py questions data/waiting/questions/gis-hunter.json \|\| true; python3 .github/sc |
| kpc-gis-hunter.yml | 77 | LOUD | error: kpc_keep_answers.py | python3 .github/scripts/kpc_keep_answers.py questions data/waiting/questions/gis-hunter.json \|\| true; python3 .github/sc |
| kpc-gis-hunter.yml | 78 | LOUD | error: kpc_push_data.sh | bash ../links/.github/scripts/kpc_push_data.sh . "GIS hunter: chunk $i (hidden)" data/gis-hunter data/intake/queue.json  |
| kpc-gis-hunter.yml | 90 | KEPT | a pipeline (its exit status is the last command; follow-up: pipefail) | python3 .github/scripts/kpc_after_hunt.py ${{ env.I_AREAS }} \| tee /tmp/after.txt \|\| true |
| kpc-gis-hunter.yml | 91 | LOUD | error: kpc_push_data.sh | bash ../links/.github/scripts/kpc_push_data.sh . "after-hunt: website-name reads (notes)" data/gis-hunter/name-reads.jso |
| kpc-gis-hunter.yml | 93 | LOUD | error: start the next run | [ -n "$A" ] && gh api -X POST repos/${{ github.repository }}/actions/workflows/kpc-docs.yml/dispatches -f ref=main -f "i |
| kpc-gis-hunter.yml | 101 | KEPT | not a failure signal | gh workflow run kpc-gis-hunter.yml -R ${{ github.repository }} -f country=${{ env.I_COUNTRY }} -f areas= -f chunks=5 -f  |
| kpc-gis-hunter.yml | 107 | KEPT | not a failure signal | run: gh workflow run kpc-gis-hunter.yml -R ${{ github.repository }} -f country=${{ env.I_THEN }} -f areas= -f chunks=5 - |
| kpc-gis-hunter.yml | 64 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job hunt | Hunt, one save per chunk |
| kpc-gis-hunter.yml | 84 | KEPT-GREEN | step gets id kept_green_2; reported at the end of job hunt | The pass is finished -> website-name reads + the documents bot for the parks still without a find (HQ Oct 30 7:50 AM (1) |
| kpc-gis-hunter.yml | 96 | KEPT-GREEN | step gets id kept_green_3; reported at the end of job hunt | Areas remain, so the next job starts itself |
| kpc-gis-hunter.yml | 104 | KEPT-GREEN | step gets id kept_green_4; reported at the end of job hunt | This country is finished, so the next country starts (then) |
| kpc-gps-packs.yml | 44 | LOUD | error: kpc_gps_prep.py | python3 .github/scripts/kpc_gps_prep.py ../links ../prep \|\| true |
| kpc-gps-packs.yml | 54 | KEPT | a status-board line (reporting only) | python3 .github/scripts/kpc_status.py board 'GPS packs' green "$N state packs built $(date -u +%F) (${MB:-0} MB, branch  |
| kpc-gps-packs.yml | 55 | LOUD | error: kpc_push_data.sh | bash ../links/.github/scripts/kpc_push_data.sh . "GPS packs status" data/status 2>/dev/null \|\| true |
| kpc-gps-packs.yml | 57 | LOUD | error: git push | && git push -q -f "https://x-access-token:${{ github.token }}@github.com/${{ github.repository }}" gps-packs \|\| true |
| kpc-gps-packs.yml | 38 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job run | Build |
| kpc-hardlook.yml | 40 | LOUD | error: kpc_intake_reader.py | python3 .github/scripts/kpc_intake_reader.py hardlook \|\| true |
| kpc-hardlook.yml | 42 | KEPT | a pipeline (its exit status is the last command; follow-up: pipefail) | python3 .github/scripts/kpc_hardlook.py \| tee /tmp/h.txt \|\| true |
| kpc-hardlook.yml | 45 | KEPT | a pipeline (its exit status is the last command; follow-up: pipefail) | python3 .github/scripts/kpc_status.py board 'Hard look reader' green "$(grep -o 'record found [0-9]*' /tmp/h.txt \| head  |
| kpc-hardlook.yml | 46 | LOUD | error: kpc_push_data.sh | bash ../links/.github/scripts/kpc_push_data.sh . "hard look reader (questions for chat 11)" data/waiting/questions data/ |
| kpc-hardlook.yml | 53 | LOUD | error: start the next run | run: gh workflow run kpc-hardlook.yml -R ${{ github.repository }} \|\| true |
| kpc-hardlook.yml | 34 | KEPT-GREEN | step id r; reported at the end of job run | Read |
| kpc-hardlook.yml | 50 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job run | Next run |
| kpc-helpers.yml | 60 | KEPT | optional git step; the next step reports | git fetch -q origin tools-out:tools-out && git worktree add -q ../out tools-out \|\| true |
| kpc-helpers.yml | 67 | LOUD | error: kpc_keep_answers.py | LINKS=../links MATCH_FILE=../out/map-match/map_match.json python3 .github/scripts/kpc_keep_answers.py questions >/dev/nu |
| kpc-helpers.yml | 68 | LOUD | error: kpc_auto_flow.py | LINKS=../links MATCH_FILE=../out/map-match/map_match.json python3 .github/scripts/kpc_auto_flow.py match \|\| true |
| kpc-helpers.yml | 69 | KEPT | a status-board line (reporting only) | python3 .github/scripts/kpc_status.py board "T1 map-match" green "open questions scored (STRONG = bot YES, 1 in 10 sampl |
| kpc-helpers.yml | 70 | LOUD | error: kpc_push_data.sh | bash ../links/.github/scripts/kpc_push_data.sh . "T1 map-match: STRONG -> bot YES, bands on the rest" data/waiting/quest |
| kpc-helpers.yml | 71 | LOUD | error: git push | (cd ../out && find map-match -name '*.jpg' -mtime +7 -delete; git add -A map-match && git commit -qm "T1 map-match (run  |
| kpc-helpers.yml | 78 | LOUD | error: start the next run | run: gh workflow run kpc-helpers.yml -R ${{ github.repository }} --ref main -f jobs=match \|\| true |
| kpc-helpers.yml | 100 | KEPT | a pipeline (its exit status is the last command; follow-up: pipefail) | python $D/kpc_link_fix.py --links /tmp/links.json --parkinfo data/parkinfo --docs data/docs/*.json --out /tmp/lf --max-m |
| kpc-helpers.yml | 102 | LOUD | error: git push | git fetch -q origin intake-files && git worktree add -q ../if FETCH_HEAD && cd ../if && git checkout -q -B intake-files  |
| kpc-helpers.yml | 128 | KEPT | optional git step; the next step reports | git fetch -q origin tools-out:tools-out && git worktree add -q ../out tools-out \|\| true |
| kpc-helpers.yml | 130 | LOUD | warning: install | pip install -q -r $D/requirements.txt; python -m playwright install --with-deps chromium >/dev/null 2>&1 \|\| true |
| kpc-helpers.yml | 132 | KEPT | a pipeline (its exit status is the last command; follow-up: pipefail) | rm -rf ../out/site-check; python $D/kpc_site_check.py --sample /tmp/sample.json --tools us_planner --out ../out/site-che |
| kpc-helpers.yml | 134 | KEPT | a status-board line (reporting only) | if [ "$F" = 0 ]; then python3 .github/scripts/kpc_status.py board "T5 site checker" green "40 parks x phone + desktop: a |
| kpc-helpers.yml | 135 | KEPT | a status-board line (reporting only) | else python3 .github/scripts/kpc_status.py board "T5 site checker" amber "$F checks failed (tools-out site-check/summary |
| kpc-helpers.yml | 136 | LOUD | error: kpc_push_data.sh | bash ../links/.github/scripts/kpc_push_data.sh . "T5 site checker: status" data/status \|\| true |
| kpc-helpers.yml | 137 | LOUD | error: git push | (cd ../out && git add -A site-check && git commit -qm "T5 site check (run ${{ github.run_id }})" && git push -q origin t |
| kpc-helpers.yml | 56 | KEPT-GREEN | step id m; reported at the end of job match | Score the open questions + bot YES on STRONG |
| kpc-helpers.yml | 75 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job match | Next run while questions are left |
| kpc-helpers.yml | 93 | KEPT-GREEN | step gets id kept_green_2; reported at the end of job linkfix | Fix dead links |
| kpc-helpers.yml | 124 | KEPT-GREEN | step gets id kept_green_3; reported at the end of job sitecheck | Check the live site as a guest |
| kpc-history-restart.yml | 41 | KEPT | not a failure signal | for b in $(git for-each-ref --format='%(refname:strip=3)' refs/remotes/origin \| grep -v '^HEAD$'); do git branch -f "$b" |
| kpc-history-restart.yml | 77 | KEPT | not a failure signal | gh api -X POST "repos/$R/actions/runs/$id/cancel" >/dev/null \|\| true; echo "cancelled $id" |
| kpc-history-restart.yml | 125 | LOUD | error: start the next run | gh api -X POST "repos/$R/actions/workflows/kpc-waiting-room.yml/dispatches" -f ref=main \|\| true |
| kpc-history-restart.yml | 126 | LOUD | error: start the next run | gh api -X POST "repos/$R/actions/workflows/kpc-collector.yml/dispatches" -f ref=main \|\| true |
| kpc-intake.yml | 96 | KEPT | a pipeline (its exit status is the last command; follow-up: pipefail) | python3 .github/scripts/kpc_intake_bot.py \| tee /tmp/intake.log \|\| true |
| kpc-intake.yml | 98 | LOUD | error: kpc_push_data.sh | bash ../links/.github/scripts/kpc_push_data.sh . "intake: probe chunk $i (${LEFT} rows left)" data/intake data/status \|\| |
| kpc-intake.yml | 102 | KEPT | a pipeline (its exit status is the last command; follow-up: pipefail) | grep -o '^GATE=[A-Z]*' /tmp/intake.log \| tail -1 >> "$GITHUB_ENV" \|\| true |
| kpc-intake.yml | 108 | KEPT | not a failure signal | python3 .github/scripts/kpc_status.py grade-me "layer intake" "queue" "data/intake/review.md" "READY rows first; chat 9  |
| kpc-intake.yml | 109 | KEPT | a status-board line (reporting only) | python3 .github/scripts/kpc_status.py board "layer intake" green "data/intake/ready.json + review.md" "chat 9 (approve R |
| kpc-intake.yml | 110 | LOUD | error: kpc_push_data.sh | bash ../links/.github/scripts/kpc_push_data.sh . "intake: status" data/status data/intake \|\| true |
| kpc-intake.yml | 117 | KEPT | not a failure signal | gh workflow run kpc-intake.yml -R ${{ github.repository }} -f rows= -f chunks="${{ inputs.chunks \|\| 2 }}" -f chain=$C \|\| |
| kpc-intake.yml | 49 | KEPT-GREEN | step id gate; reported at the end of job intake | Nightly runs only when the queue holds unprobed rows |
| kpc-intake.yml | 85 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job intake | Probe the queue in chunks, one save per chunk |
| kpc-intake.yml | 105 | KEPT-GREEN | step gets id kept_green_2; reported at the end of job intake | Status lines for the checkers and the board |
| kpc-intake.yml | 113 | KEPT-GREEN | step gets id kept_green_3; reported at the end of job intake | Rows remain, so the next job starts itself |
| kpc-live-chat.yml | 43 | LOUD | error: kpc_live_chat_watch.py | python3 .github/scripts/kpc_live_chat_watch.py \|\| true |
| kpc-live-chat.yml | 33 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job watch | Watch the live chats |
| kpc-lookup-tidy.yml | 31 | LOUD | error: kpc_lookup.py | LOOKUP_ROOT=. python3 ../code/.github/scripts/kpc_lookup.py tidy \|\| true |
| kpc-lookup-tidy.yml | 72 | LOUD | error: kpc_lookup.py | PIC_ROOT=. LINKS=../links python3 ../code/.github/scripts/kpc_lookup.py map-cleanup \|\| true |
| kpc-lookup-tidy.yml | 27 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job tidy | Tidy + squash when over 150 MB |
| kpc-lookup-tidy.yml | 68 | KEPT-GREEN | step gets id kept_green_2; reported at the end of job picture-maps | Delete the maps of parks with an official outline |
| kpc-map-links.yml | 45 | KEPT | optional git step; the next step reports | git fetch -q origin tools-out:tools-out && git worktree add -q ../out tools-out \|\| true |
| kpc-map-links.yml | 51 | LOUD | warning: install | pip install -q -r .github/scripts/tools/kpc_map_links/requirements.txt \|\| true |
| kpc-map-links.yml | 52 | LOUD | warning: install | python -m playwright install --with-deps chromium >/dev/null 2>&1 \|\| true |
| kpc-map-links.yml | 54 | LOUD | error: kpc_tools_run.py | python3 .github/scripts/kpc_tools_run.py prep-links "${{ inputs.test }}" $D-in \|\| true |
| kpc-map-links.yml | 58 | LOUD | error: kpc_tools_run.py | python3 .github/scripts/kpc_tools_run.py post-links $D \|\| true |
| kpc-map-links.yml | 59 | LOUD | error: git push | cd ../out && git add -A && git commit -qm "map links (run ${{ github.run_id }})" && git push -q origin tools-out \|\| true |
| kpc-map-links.yml | 60 | LOUD | error: kpc_push_data.sh | cd ../kpcdata && bash ../links/.github/scripts/kpc_push_data.sh . "map-page link extractor: finds (merged through the wa |
| kpc-map-links.yml | 66 | LOUD | error: start the next run | if [ "${{ steps.x.outputs.more }}" = yes ]; then gh workflow run kpc-map-links.yml -R ${{ github.repository }} --ref mai |
| kpc-map-links.yml | 67 | LOUD | error: start the next run | else gh workflow run kpc-docs-merge.yml -R ${{ github.repository }} --ref main \|\| true; fi |
| kpc-map-links.yml | 41 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job run | The side branch (resume state, tools-out links/) |
| kpc-map-links.yml | 48 | KEPT-GREEN | step id x; reported at the end of job run | Extract |
| kpc-map-links.yml | 62 | KEPT-GREEN | step gets id kept_green_2; reported at the end of job run | Merge what it found / next run |
| kpc-map-pictures.yml | 50 | KEPT | optional git step; the next step reports | git fetch -q origin tools-out:tools-out && git worktree add -q ../out tools-out \|\| true |
| kpc-map-pictures.yml | 55 | LOUD | error: kpc_q_gate.py | python3 .github/scripts/kpc_q_gate.py gate \|\| true |
| kpc-map-pictures.yml | 56 | LOUD | error: kpc_q_gate.py | python3 .github/scripts/kpc_q_gate.py todo /tmp/pics-todo.json \|\| true |
| kpc-map-pictures.yml | 58 | LOUD | error: kpc_q_gate.py | python3 .github/scripts/kpc_q_gate.py second-look ../out/pictures https://raw.githubusercontent.com/KentuckyPortableClub |
| kpc-map-pictures.yml | 62 | KEPT | not a failure signal | python $D/kpc_map_pictures.py --out ../out/pictures --clean-older-than 14 >/dev/null 2>&1 \|\| true |
| kpc-map-pictures.yml | 64 | KEPT | not a failure signal | python3 .github/scripts/kpc_status.py board 'Map pictures (second look)' green "$(date -u +%F): $N pictures; rows back t |
| kpc-map-pictures.yml | 65 | LOUD | error: kpc_push_data.sh | bash ../links/.github/scripts/kpc_push_data.sh . "second look: rows back to chat 11 with a map picture" data/waiting/que |
| kpc-map-pictures.yml | 66 | LOUD | error: git push | cd ../out && git add -A pictures && git commit -qm "map pictures (run ${{ github.run_id }})" && git push -q origin tools |
| kpc-map-pictures.yml | 46 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job run | Pictures |
| kpc-no-recheck.yml | 38 | KEPT | optional git step; the next step reports | git fetch -q origin tools-out:tools-out && git worktree add -q ../out tools-out \|\| true |
| kpc-no-recheck.yml | 53 | KEPT | a status-board line (reporting only) | python3 .github/scripts/kpc_status.py board "NO rechecker" green "NO answers re-tested (tools-out no-recheck/summary.md) |
| kpc-no-recheck.yml | 54 | LOUD | error: kpc_push_data.sh | bash ../links/.github/scripts/kpc_push_data.sh . "NO rechecker: flags for chat 11" data/waiting/questions/no-recheck.jso |
| kpc-no-recheck.yml | 55 | LOUD | error: git push | (cd ../out && git add -A no-recheck && git commit -qm "NO rechecker (run ${{ github.run_id }})" && git push -q origin to |
| kpc-no-recheck.yml | 62 | LOUD | error: start the next run | run: gh workflow run kpc-no-recheck.yml -R ${{ github.repository }} --ref main \|\| true |
| kpc-no-recheck.yml | 34 | KEPT-GREEN | step id r; reported at the end of job run | Recheck (resumes) |
| kpc-no-recheck.yml | 59 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job run | Next run while rows are left |
| kpc-outside-tools.yml | 60 | LOUD | warning: install | pip install -q -r $DR/kpc_fers_check/requirements.txt -r $DR/kpc_convert_layers/requirements.txt -r $DR/kpc_map_links/re |
| kpc-outside-tools.yml | 61 | LOUD | warning: install | case "$T" in *links*) python -m playwright install --with-deps chromium >/dev/null 2>&1 \|\| true;; esac |
| kpc-outside-tools.yml | 78 | KEPT | a pipeline (its exit status is the last command; follow-up: pipefail) | python3 $DR/kpc_fers_check/kpc_fers_check.py --areas $A --resume --fers-dir data/fers --key-dir data --out data/fers-che |
| kpc-outside-tools.yml | 79 | KEPT | nothing to do is fine | grep -q 'rerun with --resume' /tmp/fers.log && echo "more=yes" >> $GITHUB_OUTPUT \|\| true |
| kpc-outside-tools.yml | 80 | KEPT | nothing to do is fine | rm -rf data/fers-check/.cache \|\| true |
| kpc-outside-tools.yml | 88 | LOUD | error: kpc_outside_tools.py | python3 .github/scripts/kpc_outside_tools.py prep-convert "$TEST" /tmp/leads.json \|\| true |
| kpc-outside-tools.yml | 89 | KEPT | a pipeline (its exit status is the last command; follow-up: pipefail) | python3 $DR/kpc_convert_layers/kpc_convert_layers.py --leads /tmp/leads.json --out ../out/convert --cache .kpc_cache --m |
| kpc-outside-tools.yml | 93 | KEPT | nothing to do is fine | [ "$R" -lt "$N" ] && echo "more=yes" >> $GITHUB_OUTPUT \|\| true |
| kpc-outside-tools.yml | 101 | LOUD | error: kpc_outside_tools.py | python3 .github/scripts/kpc_outside_tools.py prep-links "$TEST" ../out/links-in \|\| true |
| kpc-outside-tools.yml | 105 | LOUD | error: kpc_outside_tools.py | python3 .github/scripts/kpc_outside_tools.py post-links ../out/links \|\| true |
| kpc-outside-tools.yml | 110 | LOUD | error: kpc_outside_tools.py | ln -sfn ../out out 2>/dev/null; python3 .github/scripts/kpc_outside_tools.py summary \|\| true; rm -f out |
| kpc-outside-tools.yml | 111 | LOUD | error: git push | cd ../out && git add -A && git commit -qm "outside tools: outputs (run ${{ github.run_id }})" && git push -q origin tool |
| kpc-outside-tools.yml | 112 | LOUD | error: kpc_push_data.sh | cd ../kpcdata && bash ../links/.github/scripts/kpc_push_data.sh . "outside tools (review only): 2-fer check / converter  |
| kpc-outside-tools.yml | 120 | LOUD | error: start the next run | gh workflow run kpc-outside-tools.yml -f tools="$T" -f test="$TEST" -f chain=$(( ${{ github.event.inputs.chain }} - 1 )) |
| kpc-outside-tools.yml | 57 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job run | Install the tools' packages |
| kpc-outside-tools.yml | 63 | KEPT-GREEN | step gets id kept_green_2; reported at the end of job run | The side branch for big outputs (tools-out, never main) |
| kpc-outside-tools.yml | 72 | KEPT-GREEN | step id fers; reported at the end of job run | 2-fer checker (KY first, then US + Canada) |
| kpc-outside-tools.yml | 84 | KEPT-GREEN | step id conv; reported at the end of job run | Map-format converter (US + Canada leads first) |
| kpc-outside-tools.yml | 97 | KEPT-GREEN | step id links; reported at the end of job run | Map-page link extractor (US agency index pages) |
| kpc-outside-tools.yml | 107 | KEPT-GREEN | step gets id kept_green_3; reported at the end of job run | Save (review files on main, big outputs on tools-out) |
| kpc-outside-tools.yml | 114 | KEPT-GREEN | step gets id kept_green_4; reported at the end of job run | Next run while work is left |
| kpc-parking-explorer.yml | 70 | LOUD | error: kpc_parking_explorer.py | run: python3 .github/scripts/kpc_parking_explorer.py \|\| true |
| kpc-parking-explorer.yml | 77 | LOUD | error: kpc_outline_lead_test.py | run: python3 .github/scripts/kpc_outline_lead_test.py \|\| true |
| kpc-parking-explorer.yml | 62 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job explore | Look for parking layers |
| kpc-parking-explorer.yml | 73 | KEPT-GREEN | step gets id kept_green_2; reported at the end of job explore | Test the outline leads (outline kind, one job only) |
| kpc-parking-explorer.yml | 80 | KEPT-GREEN | step gets id kept_green_3; reported at the end of job explore | Save |
| kpc-picture-trace.yml | 56 | LOUD | error: kpc_picture_prep.py | python3 .github/scripts/kpc_picture_prep.py ../pm ../links \|\| true |
| kpc-picture-trace.yml | 58 | KEPT | not a failure signal | sudo apt-get install -y -qq poppler-utils >/dev/null 2>&1 \|\| true   # Nov 2: pdftoppm (the sharp page) is not on GitHub' |
| kpc-picture-trace.yml | 60 | LOUD | error: kpc_picture_geo.py | python3 .github/scripts/draft/kpc_picture_geo.py ../pm /tmp/kpc-pdf \|\| true   # Nov 2 review: the sharp page (this run o |
| kpc-picture-trace.yml | 68 | KEPT | a status-board line (reporting only) | python3 .github/scripts/kpc_status.py board 'Picture-map tracer (draft)' green "$(date -u +%F): $S" 'chat 11 grades tool |
| kpc-picture-trace.yml | 69 | KEPT | not a failure signal | (for i in 1 2 3; do git add data/status && git commit -qm "board: picture tracer" && git pull -q --rebase origin main && |
| kpc-picture-trace.yml | 70 | KEPT | not a failure signal | cd ../out && find picture-trace -size +20M -delete; git add -A picture-trace && git commit -qm "picture tracer (run ${{  |
| kpc-picture-trace.yml | 77 | LOUD | error: start the next run | run: gh workflow run kpc-picture-trace.yml -R ${{ github.repository }} \|\| true |
| kpc-picture-trace.yml | 46 | KEPT-GREEN | step id r; reported at the end of job run | Trace |
| kpc-picture-trace.yml | 74 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job run | Next run |
| kpc-pota-activity.yml | 24 | KEPT | nothing to do is fine | mkdir -p ../out/pota && cp ../out/pota/activity.json data/pota/activity.json 2>/dev/null \|\| true |
| kpc-pota-activity.yml | 25 | LOUD | error: kpc_pota_activity.py | python3 .github/scripts/kpc_pota_activity.py \|\| true |
| kpc-pota-activity.yml | 27 | KEPT | not a failure signal | cd ../out && git add pota/activity.json && git commit -qm "POTA activity $(date -u +%F)" && { for i in 1 2 3 4 5; do git |
| kpc-pota-activity.yml | 20 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job activity | Activations per park |
| kpc-retry-hosts.yml | 37 | LOUD | error: kpc_retry_hosts.py | python3 .github/scripts/kpc_retry_hosts.py \|\| true |
| kpc-retry-hosts.yml | 38 | KEPT | not a failure signal | python3 .github/scripts/kpc_status.py board 'Retry list (GitHub try)' green "$(python3 -c "import json;d=json.load(open( |
| kpc-retry-hosts.yml | 39 | LOUD | error: kpc_push_data.sh | bash ../links/.github/scripts/kpc_push_data.sh . "retry list: one try from GitHub" data/intake/retry-github.json data/in |
| kpc-retry-hosts.yml | 34 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job retry | One honest try per address |
| kpc-scoreboard.yml | 38 | LOUD | error: kpc_scoreboard_bot.py | python3 .github/scripts/kpc_scoreboard_bot.py \|\| true |
| kpc-scoreboard.yml | 43 | KEPT | a status-board line (reporting only) | python3 .github/scripts/kpc_status.py board scoreboard green "scoreboard.json + scoreboard-parks.json + scoreboard-check |
| kpc-scoreboard.yml | 44 | LOUD | error: kpc_push_data.sh | bash ../links/.github/scripts/kpc_push_data.sh . "scoreboard: nightly counts" data/review data/status \|\| true |
| kpc-scoreboard.yml | 56 | KEPT | nothing to do is fine | grep -v '^FILES=' /tmp/ka.txt \|\| true |
| kpc-scoreboard.yml | 57 | LOUD | error: kpc_waiting_room.py | [ -n "$F" ] && python3 .github/scripts/kpc_waiting_room.py divert $F \|\| true |
| kpc-scoreboard.yml | 58 | LOUD | error: kpc_push_data.sh | bash ../links/.github/scripts/kpc_push_data.sh . "key join by record number: approved world parks (held for chat 11)" da |
| kpc-scoreboard.yml | 69 | KEPT | optional git step; the next step reports | git fetch -q origin +refs/heads/tools-out:refs/remotes/origin/tools-out && git show origin/tools-out:pota/activity.json  |
| kpc-scoreboard.yml | 70 | LOUD | error: kpc_missing_lists.py | python3 .github/scripts/kpc_missing_lists.py \|\| true |
| kpc-scoreboard.yml | 71 | LOUD | error: kpc_approved_list.py | APPROVED_OUT=../ml/approved python3 .github/scripts/kpc_approved_list.py \|\| true   # Nov 2: chat 11 YES answers whose ke |
| kpc-scoreboard.yml | 75 | KEPT | nothing to do is fine | && git push -q -f "https://x-access-token:${GH_TOKEN}@github.com/${{ github.repository }}.git" HEAD:missing-lists && ech |
| kpc-scoreboard.yml | 32 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job scoreboard | Count what is on file |
| kpc-scoreboard.yml | 40 | KEPT-GREEN | step gets id kept_green_2; reported at the end of job scoreboard | Save the scoreboard and tell the status board |
| kpc-scoreboard.yml | 49 | KEPT-GREEN | step gets id kept_green_3; reported at the end of job scoreboard | Join by record number (chat 11 YES answers -> the world keys; held for chat 11's file YES) |
| kpc-scoreboard.yml | 63 | KEPT-GREEN | step gets id kept_green_4; reported at the end of job scoreboard | Parks still missing a boundary, one list per country, most activated first (branch missing-lists, replaced each night) |
| kpc-sharpen.yml | 50 | KEPT | optional git step; the next step reports | git fetch -q origin tools-out:tools-out && git worktree add -q ../out tools-out \|\| true |
| kpc-sharpen.yml | 74 | LOUD | error: git push | cd ../out && rm -rf sharpen/*/work && git add -A sharpen && git commit -qm "sharpen ${{ inputs.tool }} (run ${{ github.r |
| kpc-sharpen.yml | 81 | LOUD | error: start the next run | run: gh workflow run kpc-sharpen.yml -R ${{ github.repository }} --ref main -f tool=${{ inputs.tool }} \|\| true |
| kpc-sharpen.yml | 46 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job run | Side branch |
| kpc-sharpen.yml | 53 | KEPT-GREEN | step id r; reported at the end of job run | Run |
| kpc-sharpen.yml | 78 | KEPT-GREEN | step gets id kept_green_2; reported at the end of job run | Next run |
| kpc-sota-land.yml | 32 | LOUD | error: kpc_sota_land.py | run: python3 .github/scripts/kpc_sota_land.py \|\| true |
| kpc-sota-land.yml | 37 | KEPT | nothing to do is fine | mkdir -p kpcdata/data/sota-land/ && rm -rf kpcdata/data/sota-land/ && cp -a data/sota-land kpcdata/data/sota-land 2>/dev |
| kpc-sota-land.yml | 31 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job run | Check summits |
| kpc-sota-land.yml | 35 | KEPT-GREEN | step gets id kept_green_2; reported at the end of job run | Save (once) |
| kpc-state-leaders.yml | 37 | KEPT | nothing to do is fine | rsync -a kpcdata/data/ data/ 2>/dev/null \|\| true |
| kpc-state-leaders.yml | 38 | KEPT | nothing to do is fine | cp kpcdata/locations.json kpcdata/locations-ky.json . 2>/dev/null \|\| true |
| kpc-state-leaders.yml | 50 | LOUD | error: kpc_state_leaders.py | run: python3 .github/scripts/kpc_state_leaders.py \|\| true |
| kpc-state-leaders.yml | 65 | LOUD | error: kpc_save_filter.py | python3 ../.github/scripts/kpc_save_filter.py $(git diff --name-only -- data/leaders) \|\| true |
| kpc-state-leaders.yml | 40 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job leaders |  |
| kpc-state-leaders.yml | 46 | KEPT-GREEN | step gets id kept_green_2; reported at the end of job leaders | Count |
| kpc-state-leaders.yml | 53 | KEPT-GREEN | step gets id kept_green_3; reported at the end of job leaders |  |
| kpc-state-leaders.yml | 58 | KEPT-GREEN | step gets id kept_green_4; reported at the end of job leaders | Save (once, only real changes) |
| kpc-state-links.yml | 47 | LOUD | error: kpc_state_links.py | run: python3 .github/scripts/kpc_state_links.py \|\| true |
| kpc-state-links.yml | 52 | KEPT | nothing to do is fine | mkdir -p kpcdata/data/parkinfo/ && rm -rf kpcdata/data/parkinfo/ && cp -a data/parkinfo kpcdata/data/parkinfo 2>/dev/nul |
| kpc-state-links.yml | 42 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job run | Build the state files |
| kpc-state-links.yml | 50 | KEPT-GREEN | step gets id kept_green_2; reported at the end of job run | Save (once) |
| kpc-state-trails.yml | 37 | LOUD | error: kpc_waiting_room.py | run: touch /tmp/kpc-start; (cd kpcdata && LINKS=.. python3 .github/scripts/kpc_waiting_room.py resume data/trails) \|\| tr |
| kpc-state-trails.yml | 49 | KEPT | nothing to do is fine | mkdir -p kpcdata/data/trails/ && rm -rf kpcdata/data/trails/ && cp -a data/trails kpcdata/data/trails 2>/dev/null \|\| tru |
| kpc-state-trails.yml | 55 | LOUD | error: kpc_waiting_room.py | (cd kpcdata && LINKS=.. python3 .github/scripts/kpc_waiting_room.py divert data/trails) \|\| true   # Oct 29 (chat 2 8:20  |
| kpc-state-trails.yml | 39 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job run | Build trail lines |
| kpc-state-trails.yml | 47 | KEPT-GREEN | step gets id kept_green_2; reported at the end of job run | Save (once) |
| kpc-storage.yml | 31 | KEPT | not a failure signal | if [ "$MB" -gt "$LIM" ]; then git checkout -q --orphan fresh && git add -A && git commit -qm "$b squashed $(date -u +%F) |
| kpc-storage.yml | 39 | KEPT | a pipeline (its exit status is the last command; follow-up: pipefail) | python3 .github/scripts/kpc_storage_keeper.py measure \| tee /tmp/m.txt \|\| true |
| kpc-storage.yml | 42 | KEPT | not a failure signal | python3 .github/scripts/kpc_status.py board "Storage keeper (weekly)" "$C" "$L" "HQ: over the line = decide (squash / mo |
| kpc-storage.yml | 48 | LOUD | error: kpc_storage_keeper.py | run: python3 .github/scripts/kpc_storage_keeper.py clean \|\| true |
| kpc-storage.yml | 23 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job keep | The orphan branches (measure, squash when over) |
| kpc-storage.yml | 34 | KEPT-GREEN | step gets id kept_green_2; reported at the end of job keep | Measure + board line + history |
| kpc-storage.yml | 44 | KEPT-GREEN | step gets id kept_green_3; reported at the end of job keep | Clean this repo (old artifacts, caches, stale bot branches) |
| kpc-storage.yml | 50 | KEPT-GREEN | step gets id kept_green_4; reported at the end of job keep | Save (status only) |
| kpc-tile-index.yml | 34 | KEPT | an optional path may not exist | git add --sparse data/pota/tiles.json data/sota/tiles.json data/wwff/tiles.json 2>/dev/null \|\| true |
| kpc-tile-index.yml | 18 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job index |  |
| kpc-tile-index.yml | 27 | KEPT-GREEN | step gets id kept_green_2; reported at the end of job index | Build the three indexes and save |
| kpc-tool-tests.yml | 28 | LOUD | warning: install | pip install -q -r $d/requirements.txt pytest >/dev/null 2>&1 \|\| true |
| kpc-tool-tests.yml | 31 | LOUD | warning: install | case "$t" in *site_check*) pip install -q playwright >/dev/null 2>&1; python -m playwright install --with-deps chromium  |
| kpc-tool-tests.yml | 22 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job test | Tests |
| kpc-tool-trial.yml | 71 | KEPT | optional git step; the next step reports | git fetch -q origin tools-out:tools-out && git worktree add -q ../out tools-out \|\| true |
| kpc-tool-trial.yml | 74 | KEPT | nothing to do is fine | cp ../links/data/ky-answer-key.json ../club/ 2>/dev/null \|\| true |
| kpc-tool-trial.yml | 75 | KEPT | nothing to do is fine | cp ../links/ky-*.geojson ../kyo/ 2>/dev/null \|\| true |
| kpc-tool-trial.yml | 76 | LOUD | error: kpc_gps_prep.py | python3 .github/scripts/kpc_gps_prep.py ../links ../prep \|\| true   # KY in the club shapes (pins, parking, official outl |
| kpc-tool-trial.yml | 94 | LOUD | error: kpc_intake_reader.py | acres)    F=kpc_acres; python3 .github/scripts/kpc_intake_reader.py acres >/dev/null \|\| true; IN=data/intake/_in/acres/m |
| kpc-tool-trial.yml | 97 | LOUD | error: kpc_intake_reader.py | python3 .github/scripts/kpc_intake_reader.py hardlook >/dev/null \|\| true; python3 .github/scripts/kpc_trace_prep.py ../t |
| kpc-tool-trial.yml | 97 | LOUD | error: kpc_trace_prep.py | python3 .github/scripts/kpc_intake_reader.py hardlook >/dev/null \|\| true; python3 .github/scripts/kpc_trace_prep.py ../t |
| kpc-tool-trial.yml | 111 | LOUD | error: kpc_waiting_room.py | if [ "$T" = acres ] && [ -s $O/acres.json ]; then cp $O/acres.json data/acres.json; LINKS=../links python3 .github/scrip |
| kpc-tool-trial.yml | 111 | KEPT | nothing to commit is fine | if [ "$T" = acres ] && [ -s $O/acres.json ]; then cp $O/acres.json data/acres.json; LINKS=../links python3 .github/scrip |
| kpc-tool-trial.yml | 113 | KEPT | not a failure signal | python3 .github/scripts/kpc_status.py board "Tool trial: $T" $C_ "exit $E $(date -u +%F): $(tail -1 $O/run-log.txt \| cut |
| kpc-tool-trial.yml | 114 | KEPT | not a failure signal | (for i in 1 2 3; do git add data/status && git commit -qm "board: tool trial $T" && git pull -q --rebase origin main &&  |
| kpc-tool-trial.yml | 115 | KEPT | nothing to commit is fine | cd ../out && find $T -size +40M -delete; git add -A $T && git commit -qm "tool trial $T (run ${{ github.run_id }})" \|\| t |
| kpc-tool-trial.yml | 123 | LOUD | error: start the next run | run: gh workflow run kpc-tool-trial.yml -R ${{ github.repository }} -f tools=${{ matrix.tool }} \|\| true |
| kpc-tool-trial.yml | 67 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job run | Side branch + club folder |
| kpc-tool-trial.yml | 81 | KEPT-GREEN | step id r; reported at the end of job run | Run |
| kpc-tool-trial.yml | 120 | KEPT-GREEN | step gets id kept_green_2; reported at the end of job run | Next run |
| kpc-trial-outside-ky.yml | 43 | LOUD | error: kpc_overlay.sh | bash .github/scripts/kpc_overlay.sh kpcdata \|\| true |
| kpc-trial-outside-ky.yml | 44 | KEPT | nothing to do is fine | rsync -a kpcdata/data/ data/ 2>/dev/null \|\| true |
| kpc-trial-outside-ky.yml | 45 | KEPT | nothing to do is fine | cp kpcdata/locations.json kpcdata/locations-ky.json . 2>/dev/null \|\| true |
| kpc-trial-outside-ky.yml | 66 | LOUD | error: kpc_intake_reader.py | (cd kpcdata && python3 .github/scripts/kpc_intake_reader.py hours) \|\| true   # Nov 1: the outside hours / fees workbooks |
| kpc-trial-outside-ky.yml | 67 | KEPT | a pipeline (its exit status is the last command; follow-up: pipefail) | cd kpcdata && AREAS="$AREAS" OUT=../trial/hours LINKS=.. HOURS_WB=data/intake/_in/hours python3 .github/scripts/kpc_hour |
| kpc-trial-outside-ky.yml | 73 | KEPT | a pipeline (its exit status is the last command; follow-up: pipefail) | FORCE_RUN=1 python3 .github/scripts/kpc_us_closures.py 2>&1 \| tail -5 \|\| true |
| kpc-trial-outside-ky.yml | 74 | KEPT | nothing to do is fine | mkdir -p trial/closures; [ -s data/alerts/us-parks.json ] && cp data/alerts/us-parks.json trial/closures/us-parks-$(date |
| kpc-trial-outside-ky.yml | 75 | KEPT | nothing to put back is fine | git checkout -- data/alerts 2>/dev/null \|\| true   # nothing of the trial stays in a main working file |
| kpc-trial-outside-ky.yml | 85 | LOUD | error: git push | (cd trial && git add -A && git commit -qm "outside-KY trial $(date -u +%F)" && git push -q origin trial-outside-ky) \|\| t |
| kpc-trial-outside-ky.yml | 86 | KEPT | not a failure signal | cd kpcdata && python3 .github/scripts/kpc_status.py board "outside-KY trial (hours / closures, saved only)" green "$H; $ |
| kpc-trial-outside-ky.yml | 87 | LOUD | error: kpc_push_data.sh | bash ../.github/scripts/kpc_push_data.sh . "outside-KY trial: status line" data/status \|\| true |
| kpc-trial-outside-ky.yml | 41 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job trial | Lay KPC-Data's data over the checkout |
| kpc-trial-outside-ky.yml | 48 | KEPT-GREEN | step gets id kept_green_2; reported at the end of job trial | The trial branch (never main) |
| kpc-trial-outside-ky.yml | 56 | KEPT-GREEN | step gets id kept_green_3; reported at the end of job trial | Hours / fees / permits (a slice of states a day) |
| kpc-trial-outside-ky.yml | 70 | KEPT-GREEN | step gets id kept_green_4; reported at the end of job trial | Closures (state agencies' feeds, whole US) |
| kpc-trial-outside-ky.yml | 78 | KEPT-GREEN | step gets id kept_green_5; reported at the end of job trial | Save to the trial branch + one status line |
| kpc-us-access.yml | 44 | LOUD | warning: download | gh release download boundary-cache -R KentuckyPortableClub/KPC-Links -p 'US-*.json.gz' -D cache/us --clobber \|\| true |
| kpc-us-access.yml | 45 | LOUD | warning: download | gh release download boundary-cache -R KentuckyPortableClub/KPC-Links -p 'CA-ALL.json.gz' -D cache/ca --clobber \|\| true |
| kpc-us-access.yml | 49 | LOUD | error: kpc_intake_reader.py | (cd kpcdata && python3 .github/scripts/kpc_intake_reader.py parking && python3 .github/scripts/kpc_intake_reader.py park |
| kpc-us-access.yml | 56 | LOUD | error: kpc_us_access.py | run: python3 .github/scripts/kpc_us_access.py \|\| true |
| kpc-us-access.yml | 67 | LOUD | error: kpc_waiting_room.py | (cd kpcdata && LINKS=.. NET=1 WAITING_ON=1 PROMOTE_KINDS=access,info python3 .github/scripts/kpc_waiting_room.py check - |
| kpc-us-access.yml | 39 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job run | Fetch the saved park outlines |
| kpc-us-access.yml | 47 | KEPT-GREEN | step gets id kept_green_2; reported at the end of job run | Outside research parking files (branch intake-files; HQ Oct 31 7:55 PM, the bot pulls them itself) |
| kpc-us-access.yml | 51 | KEPT-GREEN | step gets id kept_green_3; reported at the end of job run | Build the access points |
| kpc-us-access.yml | 59 | KEPT-GREEN | step gets id kept_green_4; reported at the end of job run | Save (once) |
| kpc-us-closures.yml | 32 | KEPT | nothing to do is fine | rsync -a kpcdata/data/ data/ 2>/dev/null \|\| true |
| kpc-us-closures.yml | 33 | KEPT | nothing to do is fine | cp kpcdata/locations.json kpcdata/locations-ky.json . 2>/dev/null \|\| true |
| kpc-us-closures.yml | 37 | LOUD | error: kpc_us_closures.py | run: python3 .github/scripts/kpc_us_closures.py \|\| true |
| kpc-us-closures.yml | 44 | KEPT | nothing to do is fine | cp data/status/kpc_us_closures.json kpcdata/data/status/ 2>/dev/null \|\| true |
| kpc-us-closures.yml | 48 | LOUD | error: kpc_save_filter.py | python3 ../.github/scripts/kpc_save_filter.py data/alerts/us-parks.json data/status/kpc_us_closures.json \|\| true |
| kpc-us-closures.yml | 35 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job closures | Read the closure feeds |
| kpc-us-closures.yml | 39 | KEPT-GREEN | step gets id kept_green_2; reported at the end of job closures | Save (once, only real changes) |
| kpc-us-trails.yml | 29 | LOUD | error: kpc_waiting_room.py | run: touch /tmp/kpc-start; (cd kpcdata && LINKS=.. python3 .github/scripts/kpc_waiting_room.py resume data/trails) \|\| tr |
| kpc-us-trails.yml | 38 | LOUD | error: kpc_finds_lines.py | DATA=kpcdata python3 .github/scripts/kpc_finds_lines.py /tmp/finds-lines.json \|\| true |
| kpc-us-trails.yml | 39 | LOUD | error: kpc_us_trails.py | python3 .github/scripts/kpc_us_trails.py \|\| true |
| kpc-us-trails.yml | 47 | KEPT | nothing to do is fine | mkdir -p kpcdata/data/trails/ && rm -rf kpcdata/data/trails/ && cp -a data/trails kpcdata/data/trails 2>/dev/null \|\| tru |
| kpc-us-trails.yml | 53 | LOUD | error: kpc_waiting_room.py | (cd kpcdata && LINKS=.. python3 .github/scripts/kpc_waiting_room.py divert data/trails) \|\| true   # Oct 29 (chat 2 8:20  |
| kpc-us-trails.yml | 31 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job run | Download and simplify the trail lines |
| kpc-us-trails.yml | 45 | KEPT-GREEN | step gets id kept_green_2; reported at the end of job run | Save (once) |
| kpc-waiting-room.yml | 81 | KEPT | optional git step; the next step reports | git fetch -q origin picture-maps 2>/dev/null && git show FETCH_HEAD:index.json > /tmp/pic-index.json 2>/dev/null \|\| true |
| kpc-waiting-room.yml | 82 | LOUD | error: kpc_auto_flow.py | python3 .github/scripts/kpc_auto_flow.py recheck layers maps \|\| true |
| kpc-waiting-room.yml | 88 | LOUD | error: start the next run | gh workflow run kpc-lookup.yml -R ${{ github.repository }} --ref lookup \|\| true   # a bot push starts nothing by itself: |
| kpc-waiting-room.yml | 96 | LOUD | error: kpc_engine.py | python3 .github/scripts/draft/tools/kpc_engine/kpc_engine.py doctor --links ../links --data . --out /tmp/kd > /tmp/kd.tx |
| kpc-waiting-room.yml | 99 | KEPT | nothing to do is fine | cp /tmp/kd/key-doctor/summary.json /tmp/kd/key-doctor/nos.json /tmp/kd/key-doctor/release.json /tmp/kd/key-doctor/stuck- |
| kpc-waiting-room.yml | 100 | KEPT | nothing to do is fine | cp /tmp/kd/key-doctor/resources.json /tmp/kd/key-doctor/resources.md data/status/key-doctor/ 2>/dev/null \|\| true   # eng |
| kpc-waiting-room.yml | 103 | KEPT | not a failure signal | python3 .github/scripts/kpc_status.py board key-doctor $C "${S:-no result}" "chat 10 (came-back NOs / stuck areas); per- |
| kpc-waiting-room.yml | 106 | LOUD | error: kpc_intake_reader.py | run: cd kpcdata && python3 .github/scripts/kpc_intake_reader.py questions && python3 .github/scripts/kpc_intake_reader.p |
| kpc-waiting-room.yml | 111 | LOUD | error: kpc_week_numbers.py | run: cd kpcdata && python3 .github/scripts/kpc_week_numbers.py \|\| true |
| kpc-waiting-room.yml | 114 | LOUD | error: kpc_waiting_today.py | run: cd kpcdata && python3 .github/scripts/kpc_waiting_today.py \|\| true |
| kpc-waiting-room.yml | 121 | KEPT | not a failure signal | bash ../links/.github/scripts/kpc_push_data.sh . "waiting room: ${{ inputs.mode \|\| 'release-approved (nightly)' }} ${{ i |
| kpc-waiting-room.yml | 129 | LOUD | error: start the next run | gh api -X POST repos/${{ github.repository }}/actions/workflows/kpc-fers-pending.yml/dispatches -f ref=main -f 'inputs[f |
| kpc-waiting-room.yml | 46 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job waiting | Run the waiting room |
| kpc-waiting-room.yml | 66 | KEPT-GREEN | step gets id kept_green_2; reported at the end of job waiting | The look-up branch (AUTO-3 files save-map requests there) |
| kpc-waiting-room.yml | 73 | KEPT-GREEN | step gets id kept_green_3; reported at the end of job waiting | Work the bots do themselves (AUTO-1 recheck of SURE rows, AUTO-2 strong layers, AUTO-3 picture maps; Brandon Oct 30 6:17 |
| kpc-waiting-room.yml | 93 | KEPT-GREEN | step gets id kept_green_4; reported at the end of job waiting | KEY DOCTOR after the build (report only; outside review Nov 2, Brandon OK 6:34 AM) -> data/status/key-doctor/ + the boar |
| kpc-waiting-room.yml | 105 | KEPT-GREEN | step gets id kept_green_5; reported at the end of job waiting | Intake files for the chats (questions for chat 2 / 11, hours-fees saved only; HQ Oct 31 7:55 PM) |
| kpc-waiting-room.yml | 108 | KEPT-GREEN | step gets id kept_green_6; reported at the end of job waiting | The week's numbers + the control panel's data (data/status/week-review.md, panel.json; Brandon Oct 30 11:01 AM) |
| kpc-waiting-room.yml | 113 | KEPT-GREEN | step gets id kept_green_7; reported at the end of job waiting | The morning list for chat 11 (data/waiting/today.md; Brandon Oct 29 11:50 PM) |
| kpc-waiting-room.yml | 116 | KEPT-GREEN | step gets id kept_green_8; reported at the end of job waiting | Save (data/waiting + data/status, plus the live files an undo / release / promotion changed) |
| kpc-waiting-room.yml | 124 | KEPT-GREEN | step gets id kept_green_9; reported at the end of job waiting | A key went live -> the 2-fers rerun for those states (chat 2 BOT E reads data/waiting/released-key.json) |
| kpc-watch.yml | 38 | LOUD | warning: download | gh release download boundary-cache -R KentuckyPortableClub/KPC-Links -p 'US-*.json.gz' -D cache/us --clobber \|\| true |
| kpc-watch.yml | 39 | LOUD | warning: download | gh release download boundary-cache -R KentuckyPortableClub/KPC-Links -p 'CA-ALL.json.gz' -D cache/ca --clobber \|\| true |
| kpc-watch.yml | 41 | LOUD | error: kpc_near_miss.py | python3 .github/scripts/kpc_near_miss.py \|\| true |
| kpc-watch.yml | 43 | KEPT | nothing to do is fine | [ -f data/outline-leads/near-miss.json ] && cp data/outline-leads/near-miss.json kpcdata/data/outline-leads/ \|\| true |
| kpc-watch.yml | 47 | LOUD | warning: git fetch | git fetch -q --shallow-since="2 days ago" origin HEAD \|\| true |
| kpc-watch.yml | 51 | KEPT | nothing to do is fine | cp kpcdata/data/outline-leads/near-miss.json data/outline-leads/near-miss.json 2>/dev/null \|\| true |
| kpc-watch.yml | 52 | KEPT | optional git step; the next step reports | git -C kpcdata fetch -q --shallow-since="2 days ago" origin HEAD \|\| true |
| kpc-watch.yml | 54 | LOUD | error: kpc_map_observations.py | OBS_DATA_BASE=$DBASE OBS_BASE=$BASE OBS_DATA_DIR=kpcdata OBS_FILE=kpcdata/data/map-observations.json OBS_RUN='daily watc |
| kpc-watch.yml | 62 | KEPT | an optional path may not exist | git add data 2>/dev/null \|\| true |
| kpc-watch.yml | 33 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job watch | Near misses |
| kpc-watch.yml | 45 | KEPT-GREEN | step gets id kept_green_2; reported at the end of job watch | Observations log (the last day's changes) |
| kpc-watch.yml | 57 | KEPT-GREEN | step gets id kept_green_3; reported at the end of job watch | Save (once) |
| kpc-watchdog.yml | 23 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job look | Start what GitHub skipped |
| kpc-watchdog.yml | 28 | KEPT-GREEN | step gets id kept_green_2; reported at the end of job look | Save |
| kpc-wdpa-phonebook.yml | 44 | KEPT | a pipeline (its exit status is the last command; follow-up: pipefail) | python3 .github/scripts/kpc_wdpa_phonebook.py \| tee /tmp/pb.txt \|\| true |
| kpc-wdpa-phonebook.yml | 45 | KEPT | a pipeline (its exit status is the last command; follow-up: pipefail) | python3 .github/scripts/kpc_status.py board 'WDPA phone book' green "$(grep -o '[0-9]* parks looked up[^;]*' /tmp/pb.txt |
| kpc-wdpa-phonebook.yml | 46 | LOUD | error: kpc_push_data.sh | bash ../links/.github/scripts/kpc_push_data.sh . "WDPA phone book (leads: who runs the parks we still miss)" data/intake |
| kpc-wdpa-phonebook.yml | 53 | LOUD | error: start the next run | run: gh workflow run kpc-wdpa-phonebook.yml -R ${{ github.repository }} \|\| true |
| kpc-wdpa-phonebook.yml | 41 | KEPT-GREEN | step id b; reported at the end of job book | Look up the parks we still miss |
| kpc-wdpa-phonebook.yml | 50 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job book | Next run while parks are left |
| kpc-workshop.yml | 81 | LOUD | warning: install | pip install -q --break-system-packages pypdf \|\| pip install -q pypdf \|\| true |
| kpc-workshop.yml | 82 | LOUD | warning: install | if [ "${{ inputs.browser \|\| 'yes' }}" = yes ]; then pip install -q --break-system-packages playwright \|\| pip install -q  |
| kpc-workshop.yml | 82 | LOUD | warning: install | if [ "${{ inputs.browser \|\| 'yes' }}" = yes ]; then pip install -q --break-system-packages playwright \|\| pip install -q  |
| kpc-workshop.yml | 100 | LOUD | error: kpc_intake_reader.py | python3 .github/scripts/kpc_intake_reader.py camping \|\| true   # HQ Oct 31 7:55 PM: the camp bot pulls its own files fro |
| kpc-workshop.yml | 101 | KEPT | a pipeline (its exit status is the last command; follow-up: pipefail) | python3 .github/scripts/kpc_workshop.py \| tee /tmp/workshop.log \|\| true |
| kpc-workshop.yml | 104 | LOUD | error: inline Python | python3 - <<'PY' \|\| true |
| kpc-workshop.yml | 126 | LOUD | error: kpc_push_data.sh | bash ../links/.github/scripts/kpc_push_data.sh . "keyed fill: KY federal campgrounds (waiting)" data/waiting \|\| true |
| kpc-workshop.yml | 130 | LOUD | error: kpc_push_data.sh | bash ../links/.github/scripts/kpc_push_data.sh . "workshop: status" data/status data/truth data/hours data/campinfo \|\| t |
| kpc-workshop.yml | 136 | KEPT | not a failure signal | gh workflow run kpc-workshop.yml -R ${{ github.repository }} -f bots="${{ inputs.bots }}" -f areas= -f minutes=300 -f ch |
| kpc-workshop.yml | 143 | KEPT | not a failure signal | gh workflow run kpc-workshop.yml -R ${{ github.repository }} -f bots="${{ inputs.bots }}" -f areas= -f minutes=300 -f ch |
| kpc-workshop.yml | 63 | KEPT-GREEN | step id gate; reported at the end of job workshop | Weekly runs only once proven |
| kpc-workshop.yml | 79 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job workshop | Tools |
| kpc-workshop.yml | 85 | KEPT-GREEN | step gets id kept_green_2; reported at the end of job workshop | Run the bots one at a time, one save per batch |
| kpc-workshop.yml | 133 | KEPT-GREEN | step gets id kept_green_3; reported at the end of job workshop | Passed Kentucky gates start the queue |
| kpc-workshop.yml | 139 | KEPT-GREEN | step gets id kept_green_4; reported at the end of job workshop | Areas remain, so the next job starts itself |
| kpc-world-finder.yml | 58 | LOUD | error: kpc_keep_answers.py | python3 .github/scripts/kpc_keep_answers.py questions data/waiting/questions/world-finder.json \|\| true; python3 .github/ |
| kpc-world-finder.yml | 58 | LOUD | error: kpc_keep_answers.py | python3 .github/scripts/kpc_keep_answers.py questions data/waiting/questions/world-finder.json \|\| true; python3 .github/ |
| kpc-world-finder.yml | 59 | KEPT | a pipeline (its exit status is the last command; follow-up: pipefail) | MINUTES=55 python3 .github/scripts/kpc_world_finder.py \| tee /tmp/w.log \|\| true |
| kpc-world-finder.yml | 60 | KEPT | a status-board line (reporting only) | python3 .github/scripts/kpc_status.py board "world finder v2" green "chunk $i: data/world-finder + questions" "chat 11 a |
| kpc-world-finder.yml | 61 | LOUD | error: kpc_keep_answers.py | python3 .github/scripts/kpc_keep_answers.py questions data/waiting/questions/world-finder.json \|\| true; python3 .github/ |
| kpc-world-finder.yml | 61 | LOUD | error: kpc_keep_answers.py | python3 .github/scripts/kpc_keep_answers.py questions data/waiting/questions/world-finder.json \|\| true; python3 .github/ |
| kpc-world-finder.yml | 62 | LOUD | error: kpc_push_data.sh | bash ../links/.github/scripts/kpc_push_data.sh . "world finder v2: chunk $i (hidden)" data/world-finder data/harvest dat |
| kpc-world-finder.yml | 74 | LOUD | error: start the next run | gh workflow run kpc-world-finder.yml -R ${{ github.repository }} -f countries= -f chunks=5 -f chain=$C -f stop_at="${{ i |
| kpc-world-finder.yml | 49 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job find | Find, one save per chunk |
| kpc-world-finder.yml | 68 | KEPT-GREEN | step gets id kept_green_2; reported at the end of job find | Countries remain, so the next job starts itself (until the stop time) |
| kpc-world-harvest.yml | 58 | LOUD | error: kpc_world_seed.py | run: cd kpcdata && LINKS=../links python3 .github/scripts/kpc_world_seed.py \|\| true |
| kpc-world-harvest.yml | 68 | LOUD | error: kpc_world_harvest.py | FRESH=$F LINKS=../links MINUTES=55 python3 .github/scripts/kpc_world_harvest.py \|\| true |
| kpc-world-harvest.yml | 69 | KEPT | not a failure signal | python3 .github/scripts/kpc_status.py grade-me "world harvester" "$(python3 -c "import json;s=json.load(open('data/harve |
| kpc-world-harvest.yml | 70 | KEPT | a status-board line (reporting only) | python3 .github/scripts/kpc_status.py board "world harvester" green "chunk $i saved" "chat 8 grades the leads" \|\| true |
| kpc-world-harvest.yml | 71 | LOUD | error: kpc_push_data.sh | bash ../links/.github/scripts/kpc_push_data.sh . "world harvester: chunk $i (hidden leads)" data/harvest data/status \|\|  |
| kpc-world-harvest.yml | 57 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job harvest | Seed the country list from the scouting |
| kpc-world-harvest.yml | 60 | KEPT-GREEN | step gets id kept_green_2; reported at the end of job harvest | Harvest in chunks, one save per chunk |
| kpc-world-harvest.yml | 82 | KEPT-GREEN | step gets id kept_green_3; reported at the end of job harvest | A passed test country starts the queue |
| kpc-world-harvest.yml | 100 | KEPT-GREEN | step gets id kept_green_4; reported at the end of job harvest | Carry on in a new job when countries remain |
| kpc-wwff-dir.yml | 29 | LOUD | error: kpc_waiting_room.py | run: touch /tmp/kpc-start; (cd kpcdata && LINKS=.. python3 .github/scripts/kpc_waiting_room.py resume data/wwff) \|\| true |
| kpc-wwff-dir.yml | 33 | LOUD | error: kpc_wwff_dir.py | python3 .github/scripts/kpc_wwff_dir.py \|\| true |
| kpc-wwff-dir.yml | 34 | LOUD | error: kpc_sota_dir.py | python3 .github/scripts/kpc_sota_dir.py \|\| true |
| kpc-wwff-dir.yml | 35 | LOUD | error: kpc_name_index.py | python3 .github/scripts/kpc_name_index.py \|\| true   # Oct 24: world WWFF + SOTA name search (data/names) |
| kpc-wwff-dir.yml | 40 | KEPT | nothing to do is fine | mkdir -p kpcdata/data/wwff/ && rm -rf kpcdata/data/wwff/ && cp -a data/wwff kpcdata/data/wwff 2>/dev/null \|\| true |
| kpc-wwff-dir.yml | 41 | KEPT | nothing to do is fine | mkdir -p kpcdata/data/sota/ && rm -rf kpcdata/data/sota/ && cp -a data/sota kpcdata/data/sota 2>/dev/null \|\| true |
| kpc-wwff-dir.yml | 42 | KEPT | nothing to do is fine | mkdir -p kpcdata/data/names/ && rm -rf kpcdata/data/names/ && cp -a data/names kpcdata/data/names 2>/dev/null \|\| true |
| kpc-wwff-dir.yml | 44 | LOUD | error: kpc_waiting_room.py | (cd kpcdata && LINKS=.. python3 .github/scripts/kpc_waiting_room.py divert data/wwff) \|\| true   # Oct 29 (chat 2 8:20 PM |
| kpc-wwff-dir.yml | 31 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job run | Directories |
| kpc-wwff-dir.yml | 38 | KEPT-GREEN | step gets id kept_green_2; reported at the end of job run | Save (once) |
| kpc-youtube-comments.yml | 38 | LOUD | error: kpc_youtube_comments.py | run: python3 .github/scripts/kpc_youtube_comments.py \|\| true |
| kpc-youtube-comments.yml | 50 | LOUD | error: kc.py | && python3 "$RUNNER_TEMP/kc.py" \|\| true |
| kpc-youtube-comments.yml | 32 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job comments | Read comments, post to the staff room |
| kpc-youtube-comments.yml | 40 | KEPT-GREEN | step gets id kept_green_2; reported at the end of job comments | Keys answer (KPC-Data's secrets; a key is never printed) |
| kpc-youtube-comments.yml | 52 | KEPT-GREEN | step gets id kept_green_3; reported at the end of job comments | Save the memory (only when something was sent) |
