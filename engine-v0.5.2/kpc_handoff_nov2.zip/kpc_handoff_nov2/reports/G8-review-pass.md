# G8 review pass (Nov 2, 2026): what the second look changed

The first G8 pass (make_g8_loud.py) gave every `|| true` a reason. On a line-by-line check, 45 of those reasons were
wrong: they said "not a failure signal" on lines that ARE failures (a save that did not land, the next run of a chain that
did not start). Other lines were missed (multi-line python, pipelines, case arms, lines that already had a note).
make_g8_review.py fixes these and is folded into the two G8 patches. The patch file names are unchanged.

| What | KPC-Data | KPC-Links |
|---|---|---|
| `|| true` made loud (was unmarked; pipelines now report the script, not `tee`) | 28 | 11 |
| "not a failure signal" corrected (saves, chain restarts, releases, squash) | 14 | 5 |
| save loops that ended green after every try failed: they now say so | 28 | 20 |
| `|| true` kept, with a corrected reason | 35 | 12 |

Rules used (the loud ones are notices, NOT red, per the Oct 22 "no failure emails for a lost race" rule):
- A save that never lands: `::error title=Save::... NOT saved` (shows on the run page, the run stays green).
- A chain that cannot start its next run: `::error title=Next run::... the chain stops here`.
- A script in a pipeline (`python3 x.py | tee log`): its own exit status is checked (`PIPESTATUS`). Before, a crash was hidden
  because a pipeline's status is `tee`'s. Example: **kpc-boundary-check.yml** rebuilt US key states with
  `kpc_us_key.py | tee` and a crash never showed (a chat-10 lead for the held build-id question). The same applies to
  **kpc-us-key.yml**'s build-id stamp (`kpc_key_freeze.py stamp`).
- Retry loops: `{ saved=0; for ...; do pull && push && { saved=1; break; }; sleep; done; [ "$saved" = 1 ] || echo ::error ...; }`.
  The braces keep the loop one command inside an `&&` chain, so it still runs only when there was something to commit.
- Kept on purpose (each line says why): status-board lines (reporting only), optional files/paths, `git rebase --abort`
  (there may be no rebase), `gh run cancel` (the run may have finished), grep/find/awk pipelines with no match.

Follow-ups (not done here): `set -o pipefail` in every step (a bigger change; 10 grep/find pipelines keep `|| true`); moving
the KPC-Data save loops onto one shared helper (they are loud now, but each still has its own loop).
