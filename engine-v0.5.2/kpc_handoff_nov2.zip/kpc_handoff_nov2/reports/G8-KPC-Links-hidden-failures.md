# G8 hidden-failure review: KPC-Links

| kind | why | count |
|---|---|---|
| KEPT | an optional path may not exist | 31 |
| KEPT | not a failure signal | 10 |
| KEPT | a pipeline (its exit status is the last command; follow-up: pipefail) | 10 |
| KEPT | nothing to do is fine | 6 |
| KEPT | optional git step; the next step reports | 5 |
| KEPT | there may be no rebase to stop | 3 |
| KEPT | nothing to put back is fine | 1 |
| KEPT | inside $( ): the value is used, so the text must not change | 1 |
| KEPT-GREEN | step gets id kept_green_1; reported at the end of job run | 5 |
| KEPT-GREEN | step gets id kept_green_1; reported at the end of job watch | 4 |
| KEPT-GREEN | step gets id kept_green_2; reported at the end of job watch | 4 |
| KEPT-GREEN | step gets id kept_green_1; reported at the end of job probe | 3 |
| KEPT-GREEN | step gets id kept_green_2; reported at the end of job probe | 3 |
| KEPT-GREEN | step gets id kept_green_1; reported at the end of job check | 2 |
| KEPT-GREEN | step gets id kept_green_2; reported at the end of job check | 2 |
| KEPT-GREEN | step gets id kept_green_3; reported at the end of job check | 2 |
| KEPT-GREEN | step gets id kept_green_4; reported at the end of job check | 2 |
| KEPT-GREEN | step gets id kept_green_5; reported at the end of job check | 2 |
| KEPT-GREEN | step gets id kept_green_6; reported at the end of job check | 2 |
| KEPT-GREEN | step gets id kept_green_2; reported at the end of job run | 2 |
| KEPT-GREEN | step gets id kept_green_1; reported at the end of job post | 2 |
| KEPT-GREEN | step gets id kept_green_2; reported at the end of job post | 2 |
| KEPT-GREEN | step gets id kept_green_1; reported at the end of job camps | 2 |
| KEPT-GREEN | step gets id kept_green_1; reported at the end of job prepare | 2 |
| KEPT-GREEN | step gets id kept_green_2; reported at the end of job fetch | 2 |
| KEPT-GREEN | step gets id kept_green_3; reported at the end of job fetch | 2 |
| KEPT-GREEN | step gets id kept_green_3; reported at the end of job probe | 1 |
| KEPT-GREEN | step gets id kept_green_7; reported at the end of job check | 1 |
| KEPT-GREEN | step gets id kept_green_8; reported at the end of job check | 1 |
| KEPT-GREEN | step gets id kept_green_9; reported at the end of job check | 1 |
| KEPT-GREEN | step gets id kept_green_10; reported at the end of job check | 1 |
| KEPT-GREEN | step id save; reported at the end of job run | 1 |
| KEPT-GREEN | step id pick; reported at the end of job check | 1 |
| KEPT-GREEN | step gets id kept_green_3; reported at the end of job run | 1 |
| KEPT-GREEN | step gets id kept_green_4; reported at the end of job run | 1 |
| KEPT-GREEN | step gets id kept_green_5; reported at the end of job run | 1 |
| KEPT-GREEN | step gets id kept_green_1; reported at the end of job bounds | 1 |
| KEPT-GREEN | step gets id kept_green_1; reported at the end of job find | 1 |
| KEPT-GREEN | step gets id kept_green_2; reported at the end of job find | 1 |
| KEPT-GREEN | step gets id kept_green_3; reported at the end of job find | 1 |
| KEPT-GREEN | step gets id kept_green_1; reported at the end of job chain | 1 |
| KEPT-GREEN | step gets id kept_green_1; reported at the end of job mod | 1 |
| KEPT-GREEN | step gets id kept_green_1; reported at the end of job relay | 1 |
| KEPT-GREEN | step gets id kept_green_2; reported at the end of job relay | 1 |
| KEPT-GREEN | step gets id kept_green_3; reported at the end of job relay | 1 |
| KEPT-GREEN | step gets id kept_green_1; reported at the end of job count | 1 |
| KEPT-GREEN | step gets id kept_green_2; reported at the end of job count | 1 |
| KEPT-GREEN | step gets id kept_green_3; reported at the end of job count | 1 |
| KEPT-GREEN | step gets id kept_green_4; reported at the end of job count | 1 |
| KEPT-GREEN | step gets id kept_green_1; reported at the end of job measure | 1 |
| KEPT-GREEN | step gets id kept_green_2; reported at the end of job measure | 1 |
| KEPT-GREEN | step gets id kept_green_3; reported at the end of job measure | 1 |
| KEPT-GREEN | step gets id kept_green_4; reported at the end of job measure | 1 |
| KEPT-GREEN | step gets id kept_green_1; reported at the end of job harvest | 1 |
| KEPT-GREEN | step gets id kept_green_2; reported at the end of job harvest | 1 |
| KEPT-GREEN | step gets id kept_green_3; reported at the end of job maps | 1 |
| KEPT-GREEN | step gets id kept_green_4; reported at the end of job maps | 1 |
| KEPT-GREEN | step gets id kept_green_5; reported at the end of job linkcheck | 1 |
| KEPT-GREEN | step gets id kept_green_6; reported at the end of job linkcheck | 1 |
| KEPT-GREEN | step gets id kept_green_1; reported at the end of job owned | 1 |
| KEPT-GREEN | step gets id kept_green_2; reported at the end of job owned | 1 |
| KEPT-GREEN | step gets id kept_green_1; reported at the end of job spot | 1 |
| KEPT-GREEN | step gets id kept_green_2; reported at the end of job spot | 1 |
| KEPT-GREEN | step gets id kept_green_1; reported at the end of job refs | 1 |
| KEPT-GREEN | step gets id kept_green_1; reported at the end of job helpers | 1 |
| KEPT-GREEN | step gets id kept_green_2; reported at the end of job helpers | 1 |
| KEPT-GREEN | step gets id kept_green_1; reported at the end of job merge | 1 |
| KEPT-GREEN | step gets id kept_green_2; reported at the end of job merge | 1 |
| KEPT-GREEN | step gets id kept_green_1; reported at the end of job build | 1 |
| KEPT-GREEN | step gets id kept_green_2; reported at the end of job join | 1 |
| KEPT-GREEN | step gets id kept_green_3; reported at the end of job join | 1 |
| KEPT-GREEN | step gets id kept_green_1; reported at the end of job look | 1 |
| KEPT-GREEN | step gets id kept_green_2; reported at the end of job look | 1 |
| KEPT-GREEN | step gets id kept_green_3; reported at the end of job watch | 1 |
| LOUD | error | 67 |
| LOUD | warning | 25 |

| file | line | kind | why | line text |
|---|---|---|---|---|
| kpc-adds-probe.yml | 22 | LOUD | warning: install | run: pip install -q playwright && python3 -m playwright install --with-deps chromium >/dev/null 2>&1 \|\| true |
| kpc-adds-probe.yml | 23 | LOUD | error: kpc_adds_probe.py | - run: python3 .github/scripts/kpc_adds_probe.py \|\| true |
| kpc-adds-probe.yml | 21 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job probe | Browser for look-ups (round 7+) |
| kpc-adds-probe.yml | 24 | KEPT-GREEN | step gets id kept_green_2; reported at the end of job probe |  |
| kpc-adds-probe.yml | 30 | KEPT-GREEN | step gets id kept_green_3; reported at the end of job probe | Save |
| kpc-bot-health.yml | 59 | LOUD | error: kpc_checkup.py | run: python3 .github/scripts/kpc_checkup.py guard \|\| true |
| kpc-bot-health.yml | 66 | LOUD | error: kpc_key_check.py | run: python3 .github/scripts/kpc_key_check.py \|\| true |
| kpc-bot-health.yml | 70 | LOUD | error: kpc_checkup.py | run: python3 .github/scripts/kpc_checkup.py refs \|\| true |
| kpc-bot-health.yml | 77 | LOUD | error: kpc_checkup.py | run: python3 .github/scripts/kpc_checkup.py links \|\| true |
| kpc-bot-health.yml | 88 | LOUD | warning: install | npm install --no-save --no-package-lock playwright@1.56.0 >/dev/null 2>&1 \|\| true |
| kpc-bot-health.yml | 89 | LOUD | warning: install | npx playwright install --with-deps chromium >/dev/null 2>&1 \|\| true |
| kpc-bot-health.yml | 91 | LOUD | error: kpc_site_test.js | MEMBER_PASS=1 node .github/scripts/kpc_site_test.js https://kentuckyportableclub.github.io/KPC-Links/ checkup-out/site.j |
| kpc-bot-health.yml | 98 | LOUD | error: kpc_site_test.js | node .github/scripts/kpc_site_test.js http://127.0.0.1:8765/KPC-Links/ checkup-out/site.json \|\| true |
| kpc-bot-health.yml | 104 | LOUD | error: kpc_bot_health.py | run: python3 .github/scripts/kpc_bot_health.py \|\| true |
| kpc-bot-health.yml | 113 | KEPT | nothing to do is fine | (cd $W/kd && zip -qr -9 $W/KPC-Data-data-$D.zip data) \|\| true |
| kpc-bot-health.yml | 115 | KEPT | optional git step; the next step reports | git archive --format=zip -9 -o $W/KPC-Links-data-notes-$D.zip HEAD data .claude/notes \|\| true |
| kpc-bot-health.yml | 121 | KEPT | not a failure signal | \| while read id; do gh api -X DELETE "repos/$R/releases/$id" >/dev/null && echo "old backup $id removed"; done \|\| true |
| kpc-bot-health.yml | 127 | LOUD | error: kpc_save_filter.py | python3 .github/scripts/kpc_save_filter.py data/bot-health.json \|\| true |
| kpc-bot-health.yml | 45 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job check | KPC-Data's bot files (read-only), so moved bots are checked too |
| kpc-bot-health.yml | 58 | KEPT-GREEN | step gets id kept_green_2; reported at the end of job check | Public-list guard (daily) |
| kpc-bot-health.yml | 61 | KEPT-GREEN | step gets id kept_green_3; reported at the end of job check | Keys and tokens answer (daily; a key is never printed) |
| kpc-bot-health.yml | 69 | KEPT-GREEN | step gets id kept_green_4; reported at the end of job check | Reference check, every state (Sunday) |
| kpc-bot-health.yml | 73 | KEPT-GREEN | step gets id kept_green_5; reported at the end of job check | Data link check (Sunday) |
| kpc-bot-health.yml | 80 | KEPT-GREEN | step gets id kept_green_6; reported at the end of job check |  |
| kpc-bot-health.yml | 85 | KEPT-GREEN | step gets id kept_green_7; reported at the end of job check | Site test as a guest (Sunday) / guest + member on the live site (release) |
| kpc-bot-health.yml | 100 | KEPT-GREEN | step gets id kept_green_8; reported at the end of job check | Bot check + one report grouped by chat |
| kpc-bot-health.yml | 107 | KEPT-GREEN | step gets id kept_green_9; reported at the end of job check | Weekly backup snapshot (Sunday) as a DRAFT release, last 8 kept |
| kpc-bot-health.yml | 123 | KEPT-GREEN | step gets id kept_green_10; reported at the end of job check | Save |
| kpc-bot-queue.yml | 28 | LOUD | error: kpc_bot_queue.py | run: python3 .github/scripts/kpc_bot_queue.py pick \|\| true |
| kpc-bot-queue.yml | 40 | KEPT | there may be no rebase to stop | git rebase --abort 2>/dev/null \|\| true |
| kpc-bot-queue.yml | 51 | LOUD | error: kpc_bot_queue.py | python3 .github/scripts/kpc_bot_queue.py start \|\| true |
| kpc-bot-queue.yml | 24 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job run | Pick the next job |
| kpc-bot-queue.yml | 31 | KEPT-GREEN | step id save; reported at the end of job run | Save the queue before starting anything |
| kpc-bot-queue.yml | 46 | KEPT-GREEN | step gets id kept_green_2; reported at the end of job run | Start it |
| kpc-boundary-check.yml | 81 | LOUD | warning: download | gh release download boundary-cache -R "$GITHUB_REPOSITORY" -p 'US-*.json.gz' -D cache/us --clobber \|\| true |
| kpc-boundary-check.yml | 94 | LOUD | warning: install | pip install --quiet --break-system-packages pyshp pyproj \|\| true   # Oct 28: zipped-shapefile layers (Mississippi) |
| kpc-boundary-check.yml | 95 | KEPT | a pipeline (its exit status is the last command; follow-up: pipefail) | if [ -n "$STATES" ]; then echo "::notice title=Boundary check::rebuilding $STATES"; python3 .github/scripts/kpc_us_key.p |
| kpc-boundary-check.yml | 99 | KEPT | a pipeline (its exit status is the last command; follow-up: pipefail) | STATES="$REFRESH" GEO_CACHE_MODE=refresh python3 .github/scripts/kpc_us_key.py 2>&1 \| tee -a us-key.log \|\| true |
| kpc-boundary-check.yml | 100 | LOUD | error: inline Python | python3 - <<'PY' \|\| true |
| kpc-boundary-check.yml | 118 | LOUD | warning: download | gh release create boundary-cache -R "$GITHUB_REPOSITORY" --prerelease --title 'Saved park outlines' --notes 'Saved outli |
| kpc-boundary-check.yml | 119 | LOUD | warning: download | ls cache/us/*.json.gz >/dev/null 2>&1 && gh release upload boundary-cache cache/us/*.json.gz -R "$GITHUB_REPOSITORY" --c |
| kpc-boundary-check.yml | 127 | LOUD | warning: download | ls cache/us/US-*.json.gz >/dev/null 2>&1 \|\| gh release download boundary-cache -R "$GITHUB_REPOSITORY" -p 'US-*.json.gz' |
| kpc-boundary-check.yml | 128 | LOUD | error: kpc_outline_score.py | python3 .github/scripts/kpc_outline_score.py \|\| true |
| kpc-boundary-check.yml | 133 | LOUD | error: kpc_boundary_report.py | run: python3 .github/scripts/kpc_boundary_report.py \|\| true |
| kpc-boundary-check.yml | 139 | KEPT | an optional path may not exist | git add data/us-key data/boundary-report.json data/boundary-score.json 2>/dev/null \|\| true |
| kpc-boundary-check.yml | 140 | KEPT | an optional path may not exist | git add data/status 2>/dev/null \|\| true   # Oct 25 storage plan: when each file last changed |
| kpc-boundary-check.yml | 36 | KEPT-GREEN | step id pick; reported at the end of job check | Pick the states that have not been checked yet |
| kpc-boundary-check.yml | 76 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job check | Fetch the saved outlines |
| kpc-boundary-check.yml | 84 | KEPT-GREEN | step gets id kept_green_2; reported at the end of job check | Rebuild those keys with the check |
| kpc-boundary-check.yml | 113 | KEPT-GREEN | step gets id kept_green_3; reported at the end of job check | Keep any newly saved outlines |
| kpc-boundary-check.yml | 121 | KEPT-GREEN | step gets id kept_green_4; reported at the end of job check | Second witness (how sure is each outline?) |
| kpc-boundary-check.yml | 130 | KEPT-GREEN | step gets id kept_green_5; reported at the end of job check | Write up what it found |
| kpc-boundary-check.yml | 135 | KEPT-GREEN | step gets id kept_green_6; reported at the end of job check | Save |
| kpc-ca-key.yml | 33 | LOUD | error: kpc_key_freeze.py | python3 .github/scripts/kpc_key_freeze.py check ca-key \|\| true |
| kpc-ca-key.yml | 53 | LOUD | warning: install | pip install --quiet --break-system-packages pyshp pyproj \|\| pip install --quiet pyshp pyproj \|\| true |
| kpc-ca-key.yml | 55 | LOUD | warning: download | if [ "$GEO_CACHE_MODE" = use ]; then mkdir -p cache/ca; gh release download boundary-cache -R "$GITHUB_REPOSITORY" -p 'C |
| kpc-ca-key.yml | 57 | LOUD | error: kpc_ca_hardlook.py | git clone -q --depth 1 --filter=blob:none --no-checkout https://github.com/KentuckyPortableClub/KPC-Data .hl 2>/dev/null |
| kpc-ca-key.yml | 61 | KEPT | a pipeline (its exit status is the last command; follow-up: pipefail) | grep '^::notice' ca-key.log \| grep -v 'title=CPCAD layer::' \| tail -n 9 \| cut -c1-900 \|\| true |
| kpc-ca-key.yml | 69 | LOUD | warning: download | if [ -f cache/ca/CA-ALL.json.gz ] && ! grep -q 'stopped early\\|GATE FAIL' ca-key.log 2>/dev/null; then gh release upload |
| kpc-ca-key.yml | 73 | LOUD | error: kpc_ca_fill_bounds.py | run: python3 .github/scripts/kpc_ca_fill_bounds.py \|\| true |
| kpc-ca-key.yml | 77 | LOUD | error: kpc_ca_whynot.py | run: python3 .github/scripts/kpc_ca_whynot.py \|\| true |
| kpc-ca-key.yml | 86 | LOUD | error: kpc_key_freeze.py | run: python3 .github/scripts/kpc_key_freeze.py stamp ca-key \|\| true |
| kpc-ca-key.yml | 51 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job run | Build the Canada answer key |
| kpc-ca-key.yml | 64 | KEPT-GREEN | step gets id kept_green_2; reported at the end of job run | Keep the saved copy current (a full read that finished) |
| kpc-ca-key.yml | 72 | KEPT-GREEN | step gets id kept_green_3; reported at the end of job run | Save outline files for joined parks that have none (never overwrites) |
| kpc-ca-key.yml | 76 | KEPT-GREEN | step gets id kept_green_4; reported at the end of job run | Why-not tags for parks with no outline (R-GC8) |
| kpc-ca-key.yml | 80 | KEPT-GREEN | step gets id kept_green_5; reported at the end of job run | Review issue |
| kpc-campground-notes.yml | 32 | LOUD | error: kpc_light_guard.py | python3 .github/scripts/kpc_light_guard.py kpc-campground-notes.json \|\| true   # Oct 30 (Brandon 6:07 AM GO, HQ step C): |
| kpc-campground-notes.yml | 33 | KEPT | an optional path may not exist | git add .claude/inbox/chat-11.md 2>/dev/null \|\| true |
| kpc-canada-bounds.yml | 36 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job bounds | Find the outlines |
| kpc-canada.yml | 27 | KEPT | an optional path may not exist | git add data/status 2>/dev/null \|\| true   # Oct 25 storage plan: when each file last changed |
| kpc-candidates.yml | 24 | LOUD | warning: download | gh release download boundary-cache -R "$GITHUB_REPOSITORY" -p 'US-*.json.gz' -D cache/us --clobber \|\| true |
| kpc-candidates.yml | 25 | LOUD | warning: download | gh release download boundary-cache -R "$GITHUB_REPOSITORY" -p 'CA-ALL.json.gz' -D cache/ca --clobber \|\| true |
| kpc-candidates.yml | 26 | KEPT | nothing to do is fine | rm -f cache/us/prev-* \|\| true |
| kpc-candidates.yml | 28 | LOUD | warning: download | mkdir -p data/parkinfo && curl -fsSL https://raw.githubusercontent.com/KentuckyPortableClub/KPC-Data/main/data/parkinfo/ |
| kpc-candidates.yml | 29 | LOUD | error: kpc_candidates.py | - run: python3 .github/scripts/kpc_candidates.py \|\| true |
| kpc-candidates.yml | 19 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job find | Saved copies |
| kpc-candidates.yml | 30 | KEPT-GREEN | step gets id kept_green_2; reported at the end of job find |  |
| kpc-candidates.yml | 36 | KEPT-GREEN | step gets id kept_green_3; reported at the end of job find | Save |
| kpc-chain.yml | 22 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job chain | Next jobs, one after another |
| kpc-club-posts.yml | 47 | LOUD | error: kpc_club_posts.py | python3 .github/scripts/kpc_club_posts.py \|\| true |
| kpc-club-posts.yml | 53 | KEPT | an optional path may not exist | git add data/kpc-club-posts-state.json 2>/dev/null \|\| true |
| kpc-club-posts.yml | 34 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job post | Write the posts |
| kpc-club-posts.yml | 49 | KEPT-GREEN | step gets id kept_green_2; reported at the end of job post | Remember what went out |
| kpc-discord-mod.yml | 64 | LOUD | error: kpc_discord_mod.py | python3 .github/scripts/kpc_discord_mod.py \|\| true |
| kpc-discord-mod.yml | 50 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job mod | Do it |
| kpc-discord-relay.yml | 52 | LOUD | error: kpc_discord_ask.py | run: python3 .github/scripts/kpc_discord_ask.py \|\| true |
| kpc-discord-relay.yml | 61 | LOUD | error: kpc_discord_mod.py | run: python3 .github/scripts/kpc_discord_mod.py \|\| true |
| kpc-discord-relay.yml | 70 | LOUD | error: kpc_discord_mod.py | run: python3 .github/scripts/kpc_discord_mod.py \|\| true |
| kpc-discord-relay.yml | 76 | LOUD | error: kpc_save_filter.py | python3 .github/scripts/kpc_save_filter.py kpc-relay-state.json kpc-conditions.json data/discord-ask-state.json data/dis |
| kpc-discord-relay.yml | 78 | KEPT | an optional path may not exist | git add -A photos/announce 2>/dev/null \|\| true |
| kpc-discord-relay.yml | 48 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job relay | Answer what we can in the club rooms |
| kpc-discord-relay.yml | 54 | KEPT-GREEN | step gets id kept_green_2; reported at the end of job relay | Keep an eye on the rooms |
| kpc-discord-relay.yml | 63 | KEPT-GREEN | step gets id kept_green_3; reported at the end of job relay | Do anything asked for in the staff room |
| kpc-discord-watch.yml | 54 | LOUD | error: kpc_discord_watch.py | python3 .github/scripts/kpc_discord_watch.py \|\| true |
| kpc-discord-watch.yml | 61 | LOUD | error: kpc_save_filter.py | python3 .github/scripts/kpc_save_filter.py data/discord-watch-state.json \|\| true |
| kpc-discord-watch.yml | 62 | KEPT | an optional path may not exist | git add data/discord-watch-state.json 2>/dev/null \|\| true |
| kpc-discord-watch.yml | 38 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job watch | Look at the rooms |
| kpc-discord-watch.yml | 56 | KEPT-GREEN | step gets id kept_green_2; reported at the end of job watch | Remember what was flagged |
| kpc-events.yml | 40 | LOUD | error: kpc_light_guard.py | python3 .github/scripts/kpc_light_guard.py kpc-events-auto.json \|\| true   # Oct 30 (Brandon 6:07 AM GO, HQ step C): shra |
| kpc-events.yml | 41 | KEPT | an optional path may not exist | git add .claude/inbox/chat-11.md 2>/dev/null \|\| true |
| kpc-fb-comments.yml | 36 | LOUD | error: kpc_fb_comments.py | run: python3 .github/scripts/kpc_fb_comments.py \|\| true |
| kpc-fb-comments.yml | 43 | LOUD | error: kpc_save_filter.py | python3 .github/scripts/kpc_save_filter.py data/fb-comments-state.json \|\| true |
| kpc-fb-comments.yml | 44 | KEPT | an optional path may not exist | git add data/fb-comments-state.json 2>/dev/null \|\| true |
| kpc-fb-comments.yml | 29 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job watch | Look for new comments |
| kpc-fb-comments.yml | 38 | KEPT-GREEN | step gets id kept_green_2; reported at the end of job watch | Remember what was sent |
| kpc-fed-camps.yml | 26 | LOUD | error: kpc_fed_camps.py | run: python3 .github/scripts/kpc_fed_camps.py \|\| true |
| kpc-fed-camps.yml | 25 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job camps | Fetch campgrounds |
| kpc-geo-cache.yml | 33 | KEPT | not a failure signal | --notes 'Official land outlines saved by the KPC saved shapes workflow, for the boundary answer keys. Not a release of a |
| kpc-geo-cache.yml | 69 | LOUD | warning: install | pip install --quiet --break-system-packages pyshp pyproj \|\| true   # Oct 28: zipped-shapefile layers (Mississippi) |
| kpc-geo-cache.yml | 70 | LOUD | error: kpc_us_key.py | python3 .github/scripts/kpc_us_key.py \|\| true |
| kpc-geo-cache.yml | 77 | LOUD | warning: download | gh release upload boundary-cache cache/us/*.json.gz -R "$GITHUB_REPOSITORY" --clobber \|\| true |
| kpc-geo-cache.yml | 27 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job prepare | Make sure the release exists |
| kpc-geo-cache.yml | 60 | KEPT-GREEN | step gets id kept_green_2; reported at the end of job fetch | Download and save these states |
| kpc-geo-cache.yml | 72 | KEPT-GREEN | step gets id kept_green_3; reported at the end of job fetch | Put them on the release |
| kpc-hunters.yml | 42 | LOUD | error: kpc_hunters.py | run: python3 .github/scripts/kpc_hunters.py collect build \|\| true |
| kpc-hunters.yml | 60 | LOUD | error: kpc_hunters.py | run: python3 .github/scripts/kpc_hunters.py post \|\| true |
| kpc-hunters.yml | 69 | KEPT | an optional path may not exist | git add data/hunters/buckets.json kpc-hunters.json app/hunters.json 2>/dev/null \|\| git add data/hunters/buckets.json kpc |
| kpc-hunters.yml | 33 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job count | Bring back the open hour |
| kpc-hunters.yml | 45 | KEPT-GREEN | step gets id kept_green_2; reported at the end of job count | Keep the open hour |
| kpc-hunters.yml | 54 | KEPT-GREEN | step gets id kept_green_3; reported at the end of job count | Weekly post |
| kpc-hunters.yml | 62 | KEPT-GREEN | step gets id kept_green_4; reported at the end of job count | Save |
| kpc-key-measure.yml | 43 | LOUD | warning: download | world) gh release download boundary-cache -R "$GITHUB_REPOSITORY" -p 'W-*.json.gz' -D cache/world --clobber \|\| true ;; |
| kpc-key-measure.yml | 44 | LOUD | warning: download | ca)    gh release download boundary-cache -R "$GITHUB_REPOSITORY" -p 'CA-ALL.json.gz' -D cache/ca --clobber \|\| true ;; |
| kpc-key-measure.yml | 45 | LOUD | warning: download | *)     gh release download boundary-cache -R "$GITHUB_REPOSITORY" -p 'US-*.json.gz' -D cache/us --clobber \|\| true ;; |
| kpc-key-measure.yml | 59 | LOUD | warning: install | pip install --quiet --break-system-packages pykakasi pyshp pyproj \|\| true |
| kpc-key-measure.yml | 63 | LOUD | error: kpc_world_key.py | for c in $ALL; do COUNTRIES=$c python3 .github/scripts/kpc_world_key.py \|\| true; done ;; |
| kpc-key-measure.yml | 64 | LOUD | error: kpc_ca_key.py | ca) python3 .github/scripts/kpc_ca_key.py \|\| true ;; |
| kpc-key-measure.yml | 65 | LOUD | error: kpc_us_key.py | *)  python3 .github/scripts/kpc_us_key.py \|\| true ;; |
| kpc-key-measure.yml | 37 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job measure | Fetch the saved outlines |
| kpc-key-measure.yml | 54 | KEPT-GREEN | step gets id kept_green_2; reported at the end of job measure | Rebuild from the saved outlines only |
| kpc-key-measure.yml | 68 | KEPT-GREEN | step gets id kept_green_3; reported at the end of job measure | What changed |
| kpc-key-measure.yml | 96 | KEPT-GREEN | step gets id kept_green_4; reported at the end of job measure | Keep them (only if asked) |
| kpc-ky-key.yml | 23 | LOUD | error: kpc_overlay.sh | run: bash .github/scripts/kpc_overlay.sh \|\| true |
| kpc-ky-key.yml | 22 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job run | Read the moved data from KPC-Data (the trail lines, Oct 31) |
| kpc-ky-usace.yml | 28 | KEPT | there may be no rebase to stop | for i in 1 2 3; do git pull --rebase -X theirs --autostash && git push && break; git rebase --abort 2>/dev/null \|\| true; |
| kpc-new-refs.yml | 43 | LOUD | error: kpc_new_fable_rows.py | python3 .github/scripts/kpc_new_fable_rows.py \|\| true |
| kpc-new-refs.yml | 45 | LOUD | error: inline Python | python3 - <<'PY' \|\| true |
| kpc-new-refs.yml | 59 | KEPT | an optional path may not exist | git add .claude/build/research/fable 2>/dev/null \|\| true |
| kpc-new-refs.yml | 61 | KEPT | an optional path may not exist | git add data/retired-refs.json 2>/dev/null \|\| true |
| kpc-new-refs.yml | 62 | KEPT | an optional path may not exist | git add data/status 2>/dev/null \|\| true   # Oct 25 storage plan: when each file last changed |
| kpc-new-refs.yml | 63 | KEPT | an optional path may not exist | git add -A kpc-ky-data.json kpc-guide-*-data.json wwff-unmapped.json ky-*.geojson app/packs KPC_Kentucky_*.kml KPC_Kentu |
| kpc-new-refs.yml | 73 | LOUD | error: start the next run | if [ -f /tmp/kpc-reprint ]; then gh api -X POST repos/${{ github.repository }}/actions/workflows/kpc-guide-pdf.yml/dispa |
| kpc-new-refs.yml | 69 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job run | Reprint the guide PDFs when a Kentucky park was retired |
| kpc-nwr.yml | 22 | KEPT | an optional path may not exist | git add kpc-nwr.json 2>/dev/null \|\| true |
| kpc-nwr.yml | 23 | KEPT | an optional path may not exist | git add data/nwr 2>/dev/null \|\| true |
| kpc-official-links.yml | 39 | LOUD | error: kpc_link_harvest.py | run: python3 .github/scripts/kpc_link_harvest.py \|\| true |
| kpc-official-links.yml | 46 | KEPT | an optional path may not exist | git add data/parkinfo-web.json 2>/dev/null \|\| true |
| kpc-official-links.yml | 63 | LOUD | error: kpc_map_finder.py | run: python3 .github/scripts/kpc_map_finder.py \|\| true |
| kpc-official-links.yml | 70 | KEPT | an optional path may not exist | git add data/map-leads.json 2>/dev/null \|\| true |
| kpc-official-links.yml | 89 | LOUD | warning: git fetch | git pull -q \|\| true |
| kpc-official-links.yml | 90 | LOUD | error: kpc_map_linkcheck.py | python3 .github/scripts/kpc_map_linkcheck.py \|\| true |
| kpc-official-links.yml | 97 | KEPT | an optional path may not exist | git add data/parkinfo-web.json 2>/dev/null \|\| true |
| kpc-official-links.yml | 32 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job harvest | Harvest official links |
| kpc-official-links.yml | 42 | KEPT-GREEN | step gets id kept_green_2; reported at the end of job harvest | Save |
| kpc-official-links.yml | 58 | KEPT-GREEN | step gets id kept_green_3; reported at the end of job maps | Look for official maps on the park pages |
| kpc-official-links.yml | 66 | KEPT-GREEN | step gets id kept_green_4; reported at the end of job maps | Save |
| kpc-official-links.yml | 84 | KEPT-GREEN | step gets id kept_green_5; reported at the end of job linkcheck | Check every map link loads |
| kpc-official-links.yml | 93 | KEPT-GREEN | step gets id kept_green_6; reported at the end of job linkcheck | Save |
| kpc-owned.yml | 23 | LOUD | error: kpc_owned.py | run: python3 .github/scripts/kpc_owned.py ky \|\| true |
| kpc-owned.yml | 30 | KEPT | an optional path may not exist | git add ky-dbnf-owned.geojson 2>/dev/null \|\| true |
| kpc-owned.yml | 33 | KEPT | not a failure signal | for i in 1 2 3; do git pull --rebase -q && git push -q && break; sleep 5; done \|\| true |
| kpc-owned.yml | 21 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job owned | Read the ownership maps |
| kpc-owned.yml | 26 | KEPT-GREEN | step gets id kept_green_2; reported at the end of job owned | Save |
| kpc-park-alerts.yml | 43 | LOUD | error: kpc_park_alerts.py | run: python3 .github/scripts/kpc_park_alerts.py \|\| true |
| kpc-park-alerts.yml | 50 | LOUD | error: kpc_save_filter.py | python3 .github/scripts/kpc_save_filter.py data/park-alerts-state.json kpc-conditions.json \|\| true |
| kpc-park-alerts.yml | 51 | KEPT | an optional path may not exist | git add data/park-alerts-state.json kpc-conditions.json 2>/dev/null \|\| true |
| kpc-park-alerts.yml | 33 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job watch | Check the park alerts |
| kpc-park-alerts.yml | 45 | KEPT-GREEN | step gets id kept_green_2; reported at the end of job watch | Save what it saw |
| kpc-park-notes.yml | 31 | LOUD | error: kpc_light_guard.py | python3 .github/scripts/kpc_light_guard.py kpc-park-notes.json kpc-park-notes-us.json \|\| true   # Oct 30 (Brandon 6:07 A |
| kpc-park-notes.yml | 32 | KEPT | an optional path may not exist | git add .claude/inbox/chat-11.md 2>/dev/null \|\| true |
| kpc-pdf-release.yml | 62 | KEPT | there may be no rebase to stop | git rebase --abort 2>/dev/null \|\| true; sleep $((i * 15))   # ok: there may be no rebase to stop |
| kpc-pota-discord.yml | 27 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job spot | Check POTA 12 times, 5 minutes apart, and notify Discord |
| kpc-pota-discord.yml | 43 | KEPT-GREEN | step gets id kept_green_2; reported at the end of job spot | Save sent spot IDs (once, only if changed) |
| kpc-ref-check.yml | 33 | LOUD | error: kpc_refcheck_guard.py | python3 .github/scripts/kpc_refcheck_guard.py \|\| true   # Nov 2 (chat 5's WRONG list): a park lost that POTA did not ret |
| kpc-ref-check.yml | 34 | KEPT | an optional path may not exist | git add -A kpc-ky-data.json locations-ky.json locations.json kpc-guide-*-data.json wwff-unmapped.json ky-*.geojson app/p |
| kpc-ref-check.yml | 37 | KEPT | not a failure signal | for i in 1 2 3; do git pull -q --rebase origin main && git push -q origin HEAD:main && break; sleep 10; done \|\| true |
| kpc-ref-check.yml | 29 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job refs | Save what was taken off |
| kpc-reports.yml | 36 | KEPT | an optional path may not exist | git add -A photos/members 2>/dev/null \|\| true |
| kpc-research-helpers.yml | 56 | KEPT | a pipeline (its exit status is the last command; follow-up: pipefail) | case "$M" in daily\|weekly\|solve) timeout 20m python3 $R solve ${{ inputs.areas }} \|\| true ;; esac |
| kpc-research-helpers.yml | 57 | KEPT | a pipeline (its exit status is the last command; follow-up: pipefail) | case "$M" in daily\|weekly\|packets\|both) timeout 120m python3 $R packets ${{ inputs.areas }} \|\| true ;; esac |
| kpc-research-helpers.yml | 58 | KEPT | a pipeline (its exit status is the last command; follow-up: pipefail) | case "$M" in weekly\|atlas\|both) timeout 90m python3 $R atlas ${{ inputs.areas }} \|\| true ;; esac |
| kpc-research-helpers.yml | 59 | KEPT | not a failure signal | case "$M" in atlas-new) timeout 90m python3 $R atlas-new \|\| true ;; esac |
| kpc-research-helpers.yml | 60 | KEPT | a pipeline (its exit status is the last command; follow-up: pipefail) | case "$M" in weekly\|links) timeout 250m python3 $R links \|\| true ;; esac |
| kpc-research-helpers.yml | 61 | KEPT | not a failure signal | case "$M" in inbox) python3 $R inbox ${{ inputs.areas }} \|\| true ;; esac |
| kpc-research-helpers.yml | 64 | KEPT | not a failure signal | GH_TOKEN=${{ github.token }} REPO=${{ github.repository }} python3 $K clean \|\| true |
| kpc-research-helpers.yml | 65 | KEPT | not a failure signal | GH_TOKEN=${{ github.token }} REPO=${{ github.repository }} HIST=/tmp/storage.json python3 $K measure > /tmp/m.txt \|\| tru |
| kpc-research-helpers.yml | 66 | KEPT | a pipeline (its exit status is the last command; follow-up: pipefail) | LINE="$(grep '^LINE=' /tmp/m.txt \| cut -d= -f2-)" python3 $K warn \|\| true ;; |
| kpc-research-helpers.yml | 72 | KEPT | an optional path may not exist | git add .claude/build/research/fable .claude/build/research/agency-atlas .claude/build/research/dead-links.md .claude/in |
| kpc-research-helpers.yml | 49 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job helpers | Fill the sheets |
| kpc-research-helpers.yml | 69 | KEPT-GREEN | step gets id kept_green_2; reported at the end of job helpers | Save, notes only |
| kpc-se-probe.yml | 16 | LOUD | error: kpc_se_probe.py | - run: python3 .github/scripts/kpc_se_probe.py \|\| true |
| kpc-se-probe.yml | 17 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job probe |  |
| kpc-se-probe.yml | 19 | KEPT-GREEN | step gets id kept_green_2; reported at the end of job probe | Save |
| kpc-ses.yml | 29 | LOUD | error: kpc_light_guard.py | python3 .github/scripts/kpc_light_guard.py kpc-special-events.json kpc-contests.json \|\| true   # Oct 30 (Brandon 6:07 AM |
| kpc-ses.yml | 30 | KEPT | an optional path may not exist | git add .claude/inbox/chat-11.md 2>/dev/null \|\| true |
| kpc-state-camps-probe.yml | 26 | LOUD | error: kpc_state_camps_probe.py | run: python3 .github/scripts/kpc_state_camps_probe.py \|\| true |
| kpc-state-camps-probe.yml | 32 | KEPT | an optional path may not exist | git add data/campstate/probe.json 2>/dev/null \|\| true |
| kpc-state-camps-probe.yml | 23 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job probe | Probe |
| kpc-state-camps-probe.yml | 28 | KEPT-GREEN | step gets id kept_green_2; reported at the end of job probe | Save |
| kpc-state-camps.yml | 38 | LOUD | error: kpc_state_camps.py | run: python3 .github/scripts/kpc_state_camps.py \|\| true |
| kpc-state-camps.yml | 46 | LOUD | error: kpc_light_guard.py | python3 .github/scripts/kpc_light_guard.py data/campstate/*.json \|\| true   # Nov 2 (chat 5's WRONG: a state emptied when |
| kpc-state-camps.yml | 33 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job camps | Read the state GIS servers |
| kpc-state-gis.yml | 25 | LOUD | error: kpc_state_gis.py | run: python3 .github/scripts/kpc_state_gis.py ${{ inputs.states }} \|\| true |
| kpc-state-gis.yml | 30 | KEPT | an optional path may not exist | git add data/state-gis-found.json data/state-gis-proposed.json data/state-gis.json \|\| true |
| kpc-state-gis.yml | 31 | KEPT | an optional path may not exist | git add data/status 2>/dev/null \|\| true   # Oct 25 storage plan: when each file last changed |
| kpc-us-closures.yml | 29 | LOUD | error: kpc_us_closures.py | python3 .github/scripts/kpc_us_closures.py --merge \|\| true |
| kpc-us-closures.yml | 30 | KEPT | nothing to put back is fine | git checkout -- data/alerts 2>/dev/null \|\| true      # the file itself lives in KPC-Data now; only kpc-conditions.json i |
| kpc-us-closures.yml | 36 | LOUD | error: kpc_save_filter.py | python3 .github/scripts/kpc_save_filter.py kpc-conditions.json \|\| true |
| kpc-us-closures.yml | 23 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job merge | Merge KPC-Data's closures into kpc-conditions.json |
| kpc-us-closures.yml | 32 | KEPT-GREEN | step gets id kept_green_2; reported at the end of job merge | Save (once, only real changes) |
| kpc-us-key.yml | 44 | KEPT | optional git step; the next step reports | && git -C kpcdata sparse-checkout set --no-cone data/waiting/questions data/intake 2>/dev/null && git -C kpcdata checkou |
| kpc-us-key.yml | 64 | LOUD | error: kpc_key_freeze.py | run: python3 .github/scripts/kpc_key_freeze.py check us-key \|\| true |
| kpc-us-key.yml | 112 | KEPT | optional git step; the next step reports | && git -C .ridb sparse-checkout set --no-cone data/access-leads/keyed-pull-raw.json.gz 2>/dev/null && git -C .ridb check |
| kpc-us-key.yml | 113 | KEPT | nothing to do is fine | mkdir -p data/access-leads && cp -f .ridb/data/access-leads/keyed-pull-raw.json.gz data/access-leads/ 2>/dev/null \|\| tru |
| kpc-us-key.yml | 120 | LOUD | warning: install | pip install --quiet --break-system-packages pyshp pyproj shapely \|\| true   # Oct 28: zipped-shapefile layers (Mississipp |
| kpc-us-key.yml | 124 | KEPT | nothing to do is fine | cp data/us-key/index.json part/index.json; cp data/us-key/layers.json part/layers.json 2>/dev/null \|\| true |
| kpc-us-key.yml | 125 | KEPT | nothing to do is fine | cp data/us-key/zip-*.json part/ 2>/dev/null \|\| true |
| kpc-us-key.yml | 186 | KEPT | nothing to do is fine | cat us-key-*.log > us-key.log 2>/dev/null \|\| true |
| kpc-us-key.yml | 191 | KEPT | optional git step; the next step reports | && git -C .lf sparse-checkout set --no-cone data/intake/external-results.json 'data/waiting/questions/*.json' 2>/dev/nul |
| kpc-us-key.yml | 192 | LOUD | error: kpc_lost_finds.py | DATA=.lf python3 .github/scripts/kpc_lost_finds.py \|\| true |
| kpc-us-key.yml | 199 | KEPT | a pipeline (its exit status is the last command; follow-up: pipefail) | run: python3 .github/scripts/kpc_key_freeze.py stamp us-key \| tail -1 > /tmp/build-id.txt \|\| true |
| kpc-us-key.yml | 204 | KEPT | optional git step; the next step reports | && git -C live sparse-checkout set --no-cone data/us-key 2>/dev/null && git -C live checkout -q 2>/dev/null \|\| true |
| kpc-us-key.yml | 205 | LOUD | error: inline Python | python3 - <<'PY' \|\| true |
| kpc-us-key.yml | 262 | KEPT | not a failure signal | done \|\| true |
| kpc-us-key.yml | 109 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job build | The Recreation.gov saved copy (the one keyed pull, read only; HQ Oct 29 8:50 PM) |
| kpc-us-key.yml | 188 | KEPT-GREEN | step gets id kept_green_2; reported at the end of job join | Lost finds check (chat 2, Nov 1; Brandon 'we are finding stuff but it never makes it in') |
| kpc-us-key.yml | 201 | KEPT-GREEN | step gets id kept_green_3; reported at the end of job join | BOT C line for chat 11 (HQ Oct 30) - this build vs the LIVE key, one line in its inbox |
| kpc-watchdog.yml | 23 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job look | Start what GitHub skipped |
| kpc-watchdog.yml | 28 | KEPT-GREEN | step gets id kept_green_2; reported at the end of job look | Save |
| kpc-watcher.yml | 35 | LOUD | error: kpc_watcher.py | python3 .github/scripts/kpc_watcher.py /tmp/old-state.json /tmp/watcher-state.json /tmp/watcher-report.md \|\| true |
| kpc-watcher.yml | 25 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job watch | Last week's memory (bot-state branch) |
| kpc-watcher.yml | 30 | KEPT-GREEN | step gets id kept_green_2; reported at the end of job watch | Watch |
| kpc-watcher.yml | 38 | KEPT-GREEN | step gets id kept_green_3; reported at the end of job watch | Save memory + report to the bot-state branch (replaces last week's, no history kept) |
| kpc-whats-new.yml | 35 | LOUD | error: kpc_whats_new.py | run: python3 .github/scripts/kpc_whats_new.py \|\| true |
| kpc-whats-new.yml | 41 | KEPT | an optional path may not exist | git add data/kpc-whats-new.json 2>/dev/null \|\| true |
| kpc-whats-new.yml | 28 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job post | Post anything new |
| kpc-whats-new.yml | 37 | KEPT-GREEN | step gets id kept_green_2; reported at the end of job post | Remember what went out |
| kpc-world-cache.yml | 34 | KEPT | not a failure signal | --notes 'Official land outlines saved for the boundary answer keys. Not a release of anything.' \|\| true |
| kpc-world-cache.yml | 67 | LOUD | warning: install | pip install --quiet --break-system-packages pykakasi pyshp \|\| pip install --quiet pykakasi pyshp \|\| true |
| kpc-world-cache.yml | 80 | LOUD | warning: download | gh release upload boundary-cache "$f" -R "$GITHUB_REPOSITORY" --clobber \|\| true |
| kpc-world-cache.yml | 28 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job prepare | Make sure the release exists |
| kpc-world-cache.yml | 60 | KEPT-GREEN | step gets id kept_green_2; reported at the end of job fetch | Download and save ${{ matrix.cc }} |
| kpc-world-cache.yml | 74 | KEPT-GREEN | step gets id kept_green_3; reported at the end of job fetch | Put it on the release |
| kpc-world-key.yml | 34 | LOUD | error: kpc_key_freeze.py | python3 .github/scripts/kpc_key_freeze.py check world-key \|\| true |
| kpc-world-key.yml | 54 | LOUD | warning: install | pip install --quiet --break-system-packages pykakasi pyshp \|\| pip install --quiet pykakasi pyshp \|\| true |
| kpc-world-key.yml | 57 | KEPT | inside $( ): the value is used, so the text must not change | SHEETC=$(jq -r '.countries\|keys\|join(" ")' data/world-key/sheet-countries.json 2>/dev/null \|\| true)   # Nov 1: Brandon's |
| kpc-world-key.yml | 62 | LOUD | error: kpc_key_freeze.py | run: python3 .github/scripts/kpc_key_freeze.py stamp world-key \|\| true |
| kpc-world-key.yml | 70 | KEPT | an optional path may not exist | git add data/status 2>/dev/null \|\| true   # Oct 25 storage plan: when each file last changed |
| kpc-world-key.yml | 80 | KEPT | a pipeline (its exit status is the last command; follow-up: pipefail) | git fetch -q origin world-bounds 2>/dev/null && git archive FETCH_HEAD \| tar -x -C $B \|\| true    # what the branch holds |
| kpc-world-key.yml | 76 | KEPT-GREEN | step gets id kept_green_1; reported at the end of job run | Saved outlines to the branch world-bounds (one commit, replaced each time; Brandon Oct 31 7:24 PM) |
| kpc-world-probe.yml | 13 | LOUD | error: kpc_world_probe.py | - run: python3 .github/scripts/kpc_world_probe.py \|\| true |
